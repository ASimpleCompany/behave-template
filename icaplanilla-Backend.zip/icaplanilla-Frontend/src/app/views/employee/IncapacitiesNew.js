import React, { Component, useState } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';
import moment from 'moment';
import DatePicker from "react-datepicker/es";

export class IncapacitiesNew extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id_empleado: 0,
      id_contrato: 0,
      listacontratos: [],
      listapayroll: [],
      listaano: [],
      fecha_incapacidad: '',
      fecha_culmina: '',
      codigo_incapacidad: '',
      descripcion: '',
      id_codigoplanilla: 0,
      ano: 0
    }
    this.create = this.create.bind(this);
  }

  componentDidMount() {
    let { id_empleado } = this.props.location.state;
    this.setState({ id_empleado: id_empleado });
    this.getdata(id_empleado)
  }

  async getdata(id) {
    try {
      let listaano = [{ 'ano': moment().year() }, { 'ano': moment().year() - 1 }];

      this.setState({ issubmitting: true });
      let constactlist = await RequestService.get('employee/constractlist/' + id, null);
      let availablepayroll = await RequestService.get('payroll/available/1', null);
      this.setState({ id_contrato: constactlist.data[0].id_contrato, id_codigoplanilla: availablepayroll.data[0].id_codigoplanilla });
      this.setState({ ano: moment().year(), listaano: listaano, listacontratos: constactlist.data, issubmitting: false, listapayroll: availablepayroll.data });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }


  getdatedif() {
    try {
      let a=moment(this.state.fecha_incapacidad);
      let b=moment(this.state.fecha_culmina);
      let cantidaddias = b.diff(a, 'days') + 1;
      if (cantidaddias === 0) {
        cantidaddias = 1;
      } else if (cantidaddias <= 0) {
        cantidaddias = 0;
      }
      this.setState({ cantidaddias: cantidaddias });
    } catch (e) {
      this.setState({ cantidaddias: 0 });
    }
  }

  async create(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('id_empleado', this.state.id_empleado);
        data.append('id_contrato', this.state.id_contrato);
        data.append('fecha_incapacidad', moment(this.state.fecha_incapacidad).format("YYYY-MM-DD"));
        data.append('fecha_culmina', moment(this.state.fecha_culmina).format("YYYY-MM-DD"));
        data.append('codigo_incapacidad',this.state.codigo_incapacidad);
        data.append('descripcion', this.state.descripcion);
        data.append('id_codigoplanilla', this.state.id_codigoplanilla);
        data.append('ano', this.state.ano);
        await RequestService.post('incapacities/', data);
        toastr.success('Incapacidad Creada');
        this.props.history.push('/employee/' + this.state.id_empleado);
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }


  listacontrato() {
    let data = this.state.listacontratos.map((value, index) => {
      return <option value={value.id_contrato}>{value.descripcion}</option>
    });
    return data;
  }


  listaanos() {
    let data = this.state.listaano.map((value, index) => {
      return <option value={value.ano}>{value.ano}</option>
    });
    return data;
  }

  listapayroll() {
    let data = this.state.listapayroll.map((value, index) => {
      if (parseInt(this.state.ano) === parseInt(value.ano)) {
        return <option value={value.id_codigoplanilla}>{value.descripcion}</option>
      }
    });
    return data;
  }


  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title"> Agregar Incapacidad</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to={'/employee/' + this.state.id_empleado}
                  role="button">Incapacidades
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Agregar</li>
            </ol>
          </nav>
        </div>
        <form className="forms-sample">
          <div className="row">
            {Utils.loading(this.state.issubmitting)}
            <div className="col-md-6 grid-margin stretch-card">
              <div className="card">
                <div className="card-body">

                  <Form.Group>
                    <label htmlFor="fecha_incapacidad">Fecha inicio de incapacidad:</label>
                    <br/>
                    <DatePicker
                        dateFormat="dd/MM/yyyy"
                        selected={this.state.fecha_incapacidad}
                        onChange={async (date) => {
                          await this.setState({ fecha_incapacidad: date });
                          this.getdatedif();
                        }}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_incapacidad')}
                        size="lg"
                    />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="fecha_culmina">Ultimo día de incapacidad:</label>
                    <br/>
                    <DatePicker
                        dateFormat="dd/MM/yyyy"
                        selected={this.state.fecha_culmina}
                        onChange={async (date) => {
                          await this.setState({ fecha_culmina: date });
                          this.getdatedif();
                        }}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_culmina')}
                        size="lg"
                    />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="cantidaddias">Cantidad de días:</label>
                    <Form.Control type="number"
                      value={this.state.cantidaddias}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'cantidaddias')}
                      disabled
                      onChange={(val) => {
                        this.setState({ cantidaddias: val.target.value });
                      }}
                      id="cantidaddias" placeholder="00" />
                  </Form.Group>

                  <button type="button"
                    className="btn btn-success btn-lg"
                    style={{ margin: '5px' }}
                    onClick={this.create}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch" /> : "Guardar"}</button>
                  <Link to={'/employee/' + this.state.id_empleado} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>

                </div>
              </div>
            </div>
            <div className="col-md-6 grid-margin stretch-card">
              <div className="card">
                <div className="card-body">
                  <Form.Group>
                    <label htmlFor="descripcion">Descripción</label>
                    <textarea id="descripcion" rows="4"
                      value={this.state.descripcion}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'descripcion')}
                      onChange={(val) => {
                        this.setState({ descripcion: val.target.value });
                      }}
                    />
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="codigo_incapacidad">Código o número de incapacidad:</label>
                    <Form.Control type="text"
                      value={this.state.codigo_incapacidad}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'codigo_incapacidad')}
                      onChange={(val) => {
                        this.setState({ codigo_incapacidad: val.target.value });
                      }}
                      id="codigo_incapacidad" placeholder="" size="lg" />
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="departamento">Contrato:</label>
                    <select
                      value={this.state.id_contrato}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'id_contrato')}
                      onChange={(val) => {
                        this.setState({ id_contrato: val.target.value });
                      }}
                      size="lg"
                      id="departamento">
                      {this.listacontrato()}
                    </select>
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="ano">Año de incapacidad:</label>
                    <select
                      value={this.state.ano}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'ano')}
                      onChange={(val) => {
                        this.setState({ ano: val.target.value });
                      }}
                      size="lg"
                      id="ano">
                      {this.listaanos()}
                    </select>
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="id_codigoplanilla">Correspondiente a la planilla:</label>
                    <select
                      value={this.state.id_codigoplanilla}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'id_codigoplanilla')}
                      onChange={(val) => {
                        this.setState({ id_codigoplanilla: val.target.value });
                      }}
                      size="lg"
                      id="id_codigoplanilla">
                      {this.listapayroll()}
                    </select>
                  </Form.Group>
                </div>
              </div>
            </div>

          </div>
        </form>
      </div>
    )
  }
}

export default IncapacitiesNew;
