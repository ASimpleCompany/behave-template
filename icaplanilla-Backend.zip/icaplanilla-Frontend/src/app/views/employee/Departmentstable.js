import React, { Component } from 'react';
import { Form, Modal, Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import toastr from "toastr";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';


const SearchBar = (props) => {
  let input;
  const handleClick = () => {
    props.onSearch(input.value);
  };
  return (
    <div>
      <Form.Group>
        <Form.Control type="text" ref={n => input = n}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};



export class DepartmentsTable extends Component {

  constructor(props) {
    super(props);
    this.state = {
      userdata: [],
      issubmitting: true
    }
    this.modalclose = this.modalclose.bind(this);
    this.handleShow = this.handleShow.bind(this);
    this.handleCloseGuardar = this.handleCloseGuardar.bind(this);
  }

  columns = [{
    dataField: 'descripcion',
    text: 'Nombre',
    sort: true
  },
  {
    dataField: 'id_departamento',
    text: 'Detalle',
    sort: true,
    formatter: (cell, row) => {
      return <div>
        <button style={{ 'marginLeft': '10px' }} onClick={() =>
          this.getone(cell)
        } className="btn btn-success"><i className="fa fa-edit"></i></button>
        <Link style={{ 'marginLeft': '10px' }} to={'/employee/department/' + cell} className="btn btn-success"><i className="fa fa-users"></i></Link>

        <button style={{ 'marginLeft': '10px' }} onClick={() => this.delete(cell)} className="btn btn-danger"><i className="fa fa-eraser"></i></button>
      </div>
    }
  }];

  tableoptions = {
    paginationPosition: 'bottom',
  }

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get('department/', null);
      this.setState({ userdata: mydata.data, issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async getone(id) {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get('department/' + id, null);
      console.log(mydata);
      this.setState({
        descripcion: mydata.data[0].descripcion, typefunction: 'Actualizar',
        id_departamento: mydata.data[0].id_departamento, issubmitting: false, show: true
      });

    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async adddata() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append('descripcion', this.state.descripcion);
      await RequestService.post('department/', form);
      toastr.success('Departamento Creado');
      this.setState({ descripcion: '' });
      this.getdata();
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async updatedata() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append('descripcion', this.state.descripcion);
      await RequestService.put('department/' + this.state.id_departamento, form);
      toastr.success('Departamento Actualizado');
      this.setState({ descripcion: '' });
      this.getdata();
    } catch (e) {
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
      this.setState({ issubmitting: false });
    }
  }


  delete(deleteid) {
    confirmAlert({
      title: 'Eliminar',
      message: '¿Seguro desea eliminar?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              await RequestService.delete('department/' + deleteid, null);
              toastr.success('Departamento eliminado');
              await this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser eliminados.', 'Intente de nuevo');
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }




  handleCloseGuardar() {
    if (this.state.typefunction === 'Agregar') {
      this.adddata();
    } else {
      this.updatedata();
    }
    this.setState({ show: false });
  }

  modalclose() {
    this.setState({ show: false });
  }

  handleShow(type) {
    this.setState({ show: true, typefunction: type });
  }

  render() {

    return (
      <div>
        <Modal show={this.state.show} onHide={this.modalclose}>
          <Modal.Header closeButton>
            <Modal.Title>{this.state.typefunction} Departamento:</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form.Group>
              <label htmlFor="nombre">Descripción:</label>
              <Form.Control type="text"
                value={this.state.descripcion}
                className={Utils.loaderrors(this.state.descripcion, 'descripcion')}
                id="descripcion"
                onChange={(val) => {
                  this.setState({ descripcion: val.target.value });
                }}
                placeholder="Descripción" size="lg" />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.modalclose}>
              Cerrar
              </Button>
            <Button variant="primary" onClick={this.handleCloseGuardar}>
              Guardar
              </Button>
          </Modal.Footer>
        </Modal>
        <div className="page-header">
          <h3 className="page-title">Lista de Departamentos </h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Departamentos</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id_departamento"
                  data={this.state.userdata}
                  columns={this.columns}
                  search
                  loading={true}
                >
                  {
                    props => (
                      <div className={"row"}>
                        <div className="col-lg-8">
                          <Link onClick={() => { this.handleShow('Agregar') }} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar </Link>
                        </div>
                        <div className="col-lg-4">
                          <SearchBar {...props.searchProps} className="form-control" />
                        </div>
                        <hr />
                        <BootstrapTable
                          noDataIndication={"No se encontraron registros para mostrar."}
                          pagination={paginationFactory({ hideSizePerPage: true, pageListRenderer: false })}
                          {...props.baseProps}
                        />
                      </div>
                    )
                  }
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}


export default DepartmentsTable;
