import React, { Component } from 'react';
import { Dropdown } from 'react-bootstrap';
import { observer } from "mobx-react";
import User from "../../mobx/user";
import Cookies from 'universal-cookie';
import { Link, withRouter } from 'react-router-dom';
const cookies = new Cookies();


@observer
class Navbar extends Component {

  constructor(props) {
    super(props);
    this.state = {
      active: ''
    }
    this.singout = this.singout.bind(this);
  }

  toggleOffcanvas() {
    document.querySelector('.sidebar-offcanvas').classList.toggle('active');
  }

  async singout(e) {
    e.preventDefault();
    await User.logout();
    window.location.replace("/login");
  }

  componentDidMount() {
    this.onRouteChanged();
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }
  }

  onRouteChanged() {

    let path = window.location.pathname.split("/");

    switch (path[1]) {
      case 'admin':
        this.setState({ active: "admin" });
        break;
      case 'employee':
        this.setState({ active: "employee" });
        break;
      case 'payroll':
        this.setState({ active: "payroll" });
        break;
      default:
        this.setState({ active: "" });
    }
  }


render() {
  const { menu } = this.props
  return (

    <nav className="navbar col-lg-12 col-12 p-lg-0 fixed-top d-flex flex-row">

      <div className="navbar-menu-wrapper d-flex align-items-center justify-content-between">

        <a className="navbar-brand brand-logo-mini align-self-center d-lg-none" href="!#" onClick={evt => evt.preventDefault()}><img src={require("../../assets/images/logo-mini.svg")} alt="logo" /></a>
        <button className="navbar-toggler navbar-toggler align-self-center" type="button" onClick={() => document.body.classList.toggle('sidebar-icon-only')}>
          <i className="mdi mdi-menu" />
        </button>

        <ul className="navbar-nav navbar-nav-left header-links">
          {
            menu.map(element => (

              <li className={`${this.state.active === element.path.substr(1) ? 'active' : ''}  nav-item d-none d-md-flex `}  >

                <Link className="nav-link" to={element.path}>
                  <i className={`${element.icon}`} />
                  <span className="text-capitalize">
                    {element.descripcion}
                  </span>

                </Link>

              </li>

            ))}

        </ul>

        <ul className="navbar-nav navbar-nav-right ml-lg-auto">

          <li className="nav-item  nav-profile border-0">

            <Dropdown alignRight>

              <Dropdown.Toggle className="nav-link count-indicator bg-transparent">
                <span className="profile-text text-capitalize">{cookies.get('nombre') + ' ' + cookies.get('apellido')}</span>
                <img className="img-xs rounded-circle" src={require("../../assets/images/face-clipart.png")} alt="Profile" />
              </Dropdown.Toggle>

              <Dropdown.Menu className="preview-list navbar-dropdown pb-3">

                <br></br>

                <Dropdown.Item className="dropdown-item preview-item d-flex align-items-center border-0"
                  onClick={this.singout}>
                  <i className="mdi mdi-exit-to-app"></i>
                    Cerrar Sesión
                  </Dropdown.Item>

              </Dropdown.Menu>

            </Dropdown>

          </li>

        </ul>

        <button className="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" onClick={this.toggleOffcanvas}>
          <span className="mdi mdi-menu"></span>
        </button>

      </div>

    </nav>

  );
}
}

export default withRouter(Navbar);
