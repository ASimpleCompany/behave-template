import React, { Component } from 'react';
import { Link } from "react-router-dom";
import BootstrapTable from 'react-bootstrap-table-next';
import { Doughnut,Bar } from 'react-chartjs-2';
import { ProgressBar, Form } from 'react-bootstrap';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import 'react-confirm-alert/src/react-confirm-alert.css';
import RequestService from "../../services/RequestService"
import Utils from "../../services/Utils";
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import toastr from "toastr";

const SearchBar = (props) => {
  let input;
  const handleClick = () => {
    props.onSearch(input.value);
  };
  return (
    <div>
      <Form.Group>
        <Form.Control type="text" ref={n => input = n}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};


//@observer
class Dashboard extends Component {

  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(),
      userdata: [],
      tabledata: [],
      gotdata: false,
      issubmitting: true
    }
  }

  areaData = {
    labels: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct","Nov","Dic"],
    datasets: [{
      label: 'Montos',
      data: [],
      backgroundColor: '#2196f3',
      borderColor: '#0c83e2',
      borderWidth: 1,
      fill: true,
      datasetKeyProvider: "key1"
    }
    ]
  };


  areaOptions = {
    responsive: true,
    maintainAspectRatio: true,
    scales: {
      yAxes: [{
        gridLines: {
          color: "#F2F6F9"
        },
        ticks: {
          beginAtZero: true,
          min: 0,
          max: 5000,
          stepSize: 1500,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "#F2F6F9"
        },
        ticks: {
          beginAtZero: true
        }
      }]
    },
    legend: {
      display: false
    },
    elements: {
      point: {
        radius: 2
      }
    },
    layout: {
      padding: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0
      }
    },
    stepsize: 1
  };

  columns = [
    {
      dataField: "empleado",
      text: "Descripción",
      sort: true,
      headerStyle: (colum, colIndex) => {
        return { width: '300px', textAlign: 'center' };
      }
    },
    {
      dataField: "tipodato",
      text: "Categoría",
      sort: true,
    },
    {
      dataField: "dato",
      text: "Detalle",
      sort: true,
    },
    {
      dataField: "fecha_creacion",
      text: "Fecha de Creación",
      sort: true,
    },
    {
      dataField: "id_empleado",
      text: "Ver",
      sort: false,
      formatter: (cell, row) => {

        var path;

        switch (row.tipodato) {

          case 'Contrato':
          case 'Salario':
            path = '/employee/'+cell + '/contratos';
            break
          case 'Planilla Quincenal':
            path = '/payroll/planillas/'+ cell ;
            break
          case 'Incapacidades':
            path = '/employee/'+cell + '/incapacidades';
            break

          case 'Compromisos':
            path = '/employee/'+cell + '/compromisos';
            break

          case 'Vacaciones':
            path = '/employee/'+cell + '/vacaciones';
            break

          default:
        }

        return (
          <div>
            <Link style={{ 'marginLeft': '15px' }} to={path} className="btn btn-primary"><i className="fa fa-search"></i></Link>
          </div>
        );
      },
    },
  ];

  tableoptions = {
    paginationPosition: "bottom",
  };


  componentDidMount() {
    this.getUserRole();
    this.getdata();
    this.getpendingView();
  }

  async getUserRole() {
    try {
      let role = this.cookies.get('id_rol');
      let mydata = await RequestService.get('user/roles/' + role);
      this.setState({ userdata: mydata.data });
    } catch (e) {

      console.log(e);

    }
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get('home/stats', null);
      let rs=[];
      let max=0;
      for (let data in mydata.data){
        if(max<=mydata.data[data].monto){
          max=mydata.data[data].monto;
        }
        rs.push(mydata.data[data].monto);
      }


      let mydatapie = await RequestService.get('home/piechar', null);

      this.areaOptions.scales.yAxes[0].ticks.max=max;
      this.areaData.datasets[0].data=rs;

      let totales = mydatapie.data[0];
      this.setState({ issubmitting: false });
      this.setState(totales);
      this.setState({ gotdata: true });

    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente nuevamente');
    }
  }

  async getpendingView() {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get('home/pendingview', null);
      this.setState({ tabledata: mydata.data, issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      console.log(e);
      toastr.error(
        "Los datos no pudieron ser consultados.",
        "Intente de nuevo"
      );
    }
  }


  render() {

    const usersDoughnutChartData = {
      datasets: [{
        data: [this.state.totdocentes, this.state.totadmins],
        backgroundColor: [
          "#19d895",
          "#2196f3",
          "#dde4eb"
        ],
        borderColor: [
          "#19d895",
          "#2196f3"
        ],
      }],
      labels: [
        'Docentes',
        'Administradores',
      ],
    };

    const usersDoughnutChartOptions = {
      cutoutPercentage: 70,
      animationEasing: "easeOutBounce",
      animateRotate: true,
      animateScale: false,
      responsive: true,
      maintainAspectRatio: true,
      showScale: true,
      legend: {
        display: false
      },
      layout: {
        padding: {
          left: 0,
          right: 0,
          top: 0,
          bottom: 0
        }
      }
    };

    //KPI
    let admin_percent = ((parseInt(this.state.totadmins) * 100) / (parseInt(this.state.totadmins) + parseInt(this.state.totdocentes)));
    var admin_kpi = admin_percent.toFixed(0);
    let docentes_percent = ((parseInt(this.state.totdocentes) * 100) / (parseInt(this.state.totadmins) + parseInt(this.state.totdocentes)));
    var docentes_kpi = docentes_percent.toFixed(0);

    return (

      <div>

        {/* Title */}
        <div className="row">
          <h2 className="p-3">Resumen General</h2>
        </div>

        {/*KPI'S*/}
        <div className="row">

          {/*Distribución de Colaboradores*/}
          <div className="col-sm-5 col-md-5 col-lg-5 grid-margin stretch-card">

            <div className="card">
              <div className="card-body">
                <div className="row">
                  <div className="col-md-5 d-flex align-items-center">
                    <Doughnut data={usersDoughnutChartData} options={usersDoughnutChartOptions} width={180} />
                  </div>
                  <div className="col-md-7">
                    <h3 className="card-title font-weight-medium mb-0 d-none d-md-block">Colaboradores</h3>
                    <div className="wrapper mt-4">
                      <div className="d-flex justify-content-between mb-2">
                        <div className="d-flex align-items-center">
                          <p className="mb-0 font-weight-medium">{this.state.totadmins}</p>
                          <small className="text-muted ml-2">Administrativos</small>
                        </div>
                        <p className="mb-0 font-weight-medium">{admin_kpi}%</p>
                      </div>
                      <ProgressBar variant="primary" now={admin_kpi}/>
                    </div>
                    <div className="wrapper mt-4">
                      <div className="d-flex justify-content-between mb-2">
                        <div className="d-flex align-items-center">
                          <p className="mb-0 font-weight-medium">{this.state.totdocentes}</p>
                          <small className="text-muted ml-2">Docentes</small>
                        </div>
                        <p className="mb-0 font-weight-medium">{docentes_kpi}%</p>
                      </div>
                      <ProgressBar variant="success" now={docentes_kpi} />
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/*Total de Planilla Mensual*/}
          <div className="col-sm-7 col-md-7 col-lg-7 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h2 className="card-title mb-0">Salarios Pagados - Año Actual</h2>
                  <div className="wrapper d-flex">
                    <div className="d-flex align-items-center">
                      <span className="dot-indicator bg-primary"/>
                      <p className="mb-0 ml-2 text-muted">Montos Por Mes</p>
                    </div>
                  </div>
                </div>
                <div className="chart-container">
                  <Bar data={this.areaData} options={this.areaOptions}  datasetKeyProvider={this.datasetKeyProvider} height={80} />
                </div>
              </div>
            </div>
          </div>

        </div>

        {/*Title*/}
        <div className="row">
          <h3 className="mx-auto p-4">Actividades Pendientes de Aprobación</h3>
        </div>

        {/* Actividades Pendientes de Aprobación*/}
        <div className="row">

          {Utils.loading(this.state.issubmitting)}

          <div className="col-lg-12 grid-margin stretch-card">

            <div className="card">

              <div className="card-body">

                <ToolkitProvider
                  keyField="id"
                  data={this.state.tabledata}
                  columns={this.columns}
                  search
                  loading={true}
                >

                  {(props) => (
                    <div className={"row"}>
                      <div className="col-lg-4">
                        <SearchBar
                          {...props.searchProps}
                          className="form-control"
                        />
                      </div>
                      <hr />
                      <BootstrapTable
                        noDataIndication={"No se encontraron registros para mostrar."}
                        pagination={paginationFactory({
                          hideSizePerPage: true,
                          pageListRenderer: false,
                        })}
                        {...props.baseProps}
                      />
                    </div>
                  )}

                </ToolkitProvider>

              </div>

            </div>

          </div>

        </div>

      </div >

    );
  }
}

export default Dashboard;