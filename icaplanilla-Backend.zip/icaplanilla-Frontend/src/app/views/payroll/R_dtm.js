import React, { Component } from "react";
import { Form, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider from "react-bootstrap-table2-toolkit";
import moment from "moment";
import "react-confirm-alert/src/react-confirm-alert.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";

const SearchBar = (props) => {
  let input;
  return (
      <div>
        <Form.Group>
          <Form.Control
              type="text"
              ref={(n) => (input = n)}
              placeholder="Buscar"
              size="lg"
              onChange={() => {
                props.onSearch(input.value);
              }}
          />
        </Form.Group>
      </div>
  );
};

export default class R_dtm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nominadata: [],
      listapayroll: [],
      issubmitting: true,
      show: false,
      ano: 2020,
    };
  }

  columns = [
    {
      dataField: "estado",
      text: "Estado",
      sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(row.id_estado, row.estado);
      },
    },
    {
      dataField: "nomina",
      text: "Planilla",
      sort: true,
      headerStyle: (colum, colIndex) => {
        return { width: "250px", textAlign: "center" };
      },
    },
    {
      dataField: "ano",
      text: "Año",
      sort: true,
    },
    {
      dataField: "monto_nomina",
      text: "Monto",
      align: "right",
      sort: true,
      formatter: (cell, row) => {
        return parseFloat(cell).toFixed(2);
      },
    },
    {
      dataField: "total_pagar",
      text: "Total a pagar",
      align: "right",
      sort: true,
      formatter: (cell, row) => {
        return parseFloat(cell).toFixed(2);
      },
    },
    {
      dataField: "id_nomina",
      text: "Detalle",
      sort: true,
      formatter: (cell, row) => {
        return (
            <div>
              <Link to={"/payroll/reports/planillas/detalle/" + cell}>
                <button type="button" className="btn btn-success p-1 m-1">
                  <i className="fa fa-eye" />
                </button>
              </Link>
            </div>
        );
      },
    },
  ];

  tableoptions = {
    paginationPosition: "bottom",
  };

  componentDidMount() {
    this.setState({ano: moment().year()})
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let nominadata = await RequestService.post("payroll/nomina/all", {ano:this.state.ano,id:2});
      this.setState({ nominadata: nominadata.data });
      this.setState({issubmitting: false});
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error(
          "Los datos no pudieron ser consultados.",
          "Intente de nuevo"
      );
    }
  }


  render() {
    return (
        <div>
          <div className="page-header">
            <h3 className="page-title">Reportes de Planillas </h3>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link to="/payroll" role="button">
                    Planillas
                  </Link>
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Reportes {">"} Planillas
                </li>
              </ol>
            </nav>
          </div>
          <div className="row">
            {Utils.loading(this.state.issubmitting)}
            <div className="col-lg-12 grid-margin stretch-card">
              <div className="card">
                <div className="card-body">
                  <ToolkitProvider
                      keyField="id_codigoplanilla"
                      data={this.state.nominadata}
                      columns={this.columns}
                      search
                      loading={true}
                  >
                    {(props) => (
                        <div className={"row"}>
                          <div className="col-lg-2">
                            <Form.Group>
                              <input
                                  type="number"
                                  name="Año"
                                  className={"form-control form-control-lg"}
                                  placeholder={'Año'}
                                  onChange={(val) => {
                                    this.setState({ ano: val.target.value });
                                  }}
                                  value={this.state.ano}
                              />
                            </Form.Group>
                          </div>
                          <div className="col-lg-1">
                            <button
                                type="button"
                                onClick={() => this.getdata()}
                                className="btn btn-primary p-3"
                            >
                              <i className="fa fa-search" />
                            </button>
                          </div>
                          <div className="col-lg-5">

                          </div>
                          <div className="col-lg-4">
                            <SearchBar
                                {...props.searchProps}
                                className="form-control"
                            />
                          </div>
                          <hr />
                          <BootstrapTable
                              noDataIndication={
                                "No se encontraron registros para mostrar."
                              }
                              pagination={paginationFactory({
                                hideSizePerPage: true,
                                pageListRenderer: false,
                              })}
                              {...props.baseProps}
                          />
                        </div>
                    )}
                  </ToolkitProvider>
                </div>
              </div>
            </div>
          </div>
        </div>
    );
  }
}
