import React, { Component } from 'react';
import { Button, Form, Modal } from 'react-bootstrap';
import { Link } from "react-router-dom";
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import moment from "moment";
import { confirmAlert } from "react-confirm-alert";

const SearchBar = (props) => {
  let input;
  return (
    <div>
      <Form.Group>
        <Form.Control
          type="text"
          ref={(n) => (input = n)}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};

class DtercerMes extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nominadata: [],
      listapayroll: [],
      departmentdata: [],
      listaano: [],
      issubmitting: true,
      show: false,
      ano: 0,
      id_departamento: 0,
      id_codigoplanilla: 0,
      carga_marcacion: false,
      marcacion_inicio: '',
      marcacion_fin: ''
    };
    this.modalclose = this.modalclose.bind(this);
    this.handleShow = this.handleShow.bind(this);
    this.adddata = this.adddata.bind(this);
    this.delete = this.delete.bind(this);
  }

  columns = [
    {dataField: 'estado', text: 'Estado', sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(row.id_estado, row.estado);
      }
    },
    {dataField: "nomina",text: "Planilla",sort: true,
      headerStyle: (colum, colIndex) => {
        return { width: '250px', textAlign: 'center' };
      }
    },
    {dataField: "codigodesplanilla",text: "Código",sort: true},
    {dataField: "ano",text: "Año",sort: true},
    {dataField: 'monto_nomina',text: 'Monto',align: 'right',sort: true, formatter: (cell, row) => { return parseFloat(cell).toFixed(2); }},
    {dataField: 'total_pagar',text: 'Total a Pagar',align: 'right', sort: true, formatter: (cell, row) => { return parseFloat(cell).toFixed(2); }},
    {dataField: "id_nomina",text: "Detalle",sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            <Link
              style={{ "marginLeft": "10px" }}
              to={"/payroll/decimo/" + cell}
              className="btn btn-success p-1 m-1"
            >
              <i className="fa fa-edit" />
            </Link>
            {row.id_estado === 7 ? <button
              style={{ "marginLeft": "10px" }}
              onClick={() => this.delete(cell)}
              className="btn btn-danger p-1 m-1"
            >
              <i className="fa fa-eraser" />
            </button> : null}
          </div>
        );
      },
    },
  ];


  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      let listaano = [{ 'ano': moment().year() }, { 'ano': moment().year() - 1 }];
      this.setState({ issubmitting: true });
      let availablepayroll = await RequestService.get('payroll/available/2', null);
      let mydepartment = await RequestService.get('department/', null);
      let nominadata = await RequestService.get('payroll/nomina/tabla/2', null);
      
      this.setState({ nominadata: nominadata.data });
      this.setState({ id_departamento: mydepartment.data[0].id_departamento, id_codigoplanilla: availablepayroll.data[0].id_codigoplanilla });
      this.setState({ departmentdata: mydepartment.data, ano: moment().year(), listaano: listaano, issubmitting: false, listapayroll: availablepayroll.data });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.');
    }
  }

  async adddata() {
    try {
      this.setState({ issubmitting: true, show: false });
      let form = new FormData();

      form.append("id_departamento", this.state.id_departamento);
      form.append("id_codigoplanilla", this.state.id_codigoplanilla);
      form.append("ano", this.state.ano);

      await RequestService.post("payroll/tenth/", form);
      toastr.success("Planilla Creada");

      this.getdata();
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
      toastr.error(
        "Valide la información",
        "Intente de nuevo"
      );
    }
  }

  async delete(id) {
    confirmAlert({
      title: 'Eliminar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let form = new FormData();
              await RequestService.delete("payroll/nomina/" + id, form);
              toastr.success("Eliminado");
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                "Los datos no pudieron ser consultados.",
                "Intente de nuevo"
              );
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }


/*
  listadepartment() {
    return this.state.departmentdata.map((value, index) => {
      return <option value={value.id_departamento}>{value.descripcion}</option>
    });
  }*/

  listaanos() {
    return this.state.listaano.map((value, index) => {
      return <option value={value.ano}>{value.ano}</option>
    });
  }

  listapayroll() {
    return this.state.listapayroll.map((value, index) => {
      if (parseInt(this.state.ano) === parseInt(value.ano)) {
        return <option value={value.id_codigoplanilla}>{value.descripcion}</option>
      }
    });
  }



  modalclose() {
    this.setState({ show: false });
  }

  handleShow() {
    this.setState({ show: true });
  }


  render() {

    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Décimo Tercer Mes </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/payroll"
                  role="button">Planillas
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Gestión de Planillas {'>'} Décimo Tercer Mes</li>
            </ol>
          </nav>
        </div>

        <Modal show={this.state.show} onHide={this.modalclose}>
          <Modal.Header closeButton>
            <Modal.Title>{this.state.typefunction} Departamento:</Modal.Title>
          </Modal.Header>
          <Modal.Body className={'row'}>

            <div className={'col-lg-12'}>
              <Form.Group>
                <label htmlFor="ano">Año de Planilla:</label>
                <select
                  value={this.state.ano}
                  className={"form-control " + Utils.loaderrors(this.state.errors, 'ano')}
                  onChange={(val) => {
                    this.setState({ ano: val.target.value });
                  }}
                  size="lg"
                  id="ano">
                  {this.listaanos()}
                </select>
              </Form.Group>
            </div>

            <div className={'col-lg-12'}>
              <Form.Group>
                <label htmlFor="id_codigoplanilla">Correspondiente a la planilla:</label>
                <select
                  value={this.state.id_codigoplanilla}
                  className={"form-control " + Utils.loaderrors(this.state.errors, 'id_codigoplanilla')}
                  onChange={(val) => {
                    this.setState({ id_codigoplanilla: val.target.value });
                  }}
                  size="lg"
                  id="id_codigoplanilla">
                  {this.listapayroll()}
                </select>
              </Form.Group>
            </div>



          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.modalclose}>
              Cerrar
              </Button>
            <Button variant="primary" onClick={this.adddata}>
              Crear Planilla
              </Button>
          </Modal.Footer>
        </Modal>

        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id_codigoplanilla"
                  data={this.state.nominadata}
                  columns={this.columns}
                  search
                  loading={true}
                >
                  {(props) => (
                    <div className={"row"}>
                      <div className="col-lg-8">
                        <Button
                          onClick={this.handleShow}
                          className="btn btn-success"
                          style={{ height: "45px", padding: "14px" }}
                        >
                          Agregar
                            </Button>
                      </div>
                      <div className="col-lg-4">
                        <SearchBar
                          {...props.searchProps}
                          className="form-control"
                        />
                      </div>
                      <hr />
                      <BootstrapTable
                        noDataIndication={"No se encontraron registros para mostrar."}
                        pagination={paginationFactory({
                          hideSizePerPage: true,
                          pageListRenderer: false,
                        })}
                        {...props.baseProps}
                      />
                    </div>
                  )}
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default DtercerMes;
