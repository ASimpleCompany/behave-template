import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';

export class UserNew extends Component {

  constructor(props) {
    super(props);
    this.state = {
      hora_inicio_jornada: '',
      hora_fin_hornada: '',
      total_horas_diarias: '',
      horas_receso: '',
      descripcion: '',
      issubmitting: false
    }
    this.updateuser = this.update.bind(this);
    this.getdata = this.getdata.bind(this);
  }

  componentDidMount() {
    this.getdata()
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let id = this.props.match.params.id;
      let mydata = await RequestService.get('schedule/' + id, null);
      this.setState(mydata.data[0]);
      this.setState({ issubmitting: false });
    } catch (e) {
      toastr.error('No se pudo consultar la información.', 'Error');
      this.setState({ issubmitting: false });
    }
  }



  async update(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        //data.append('hora_inicio_jornada',this.state.hora_inicio_jornada);
        //data.append('hora_fin_hornada',this.state.hora_fin_hornada);
        //data.append('total_horas_diarias',this.state.total_horas_diarias);
        //data.append('horas_receso',this.state.horas_receso);
        data.append('descripcion', this.state.descripcion);
        data.append('dia_lunes', this.state.dia_lunes);
        data.append('dia_martes', this.state.dia_martes);
        data.append('dia_miercoles', this.state.dia_miercoles);
        data.append('dia_jueves', this.state.dia_jueves);
        data.append('dia_viernes', this.state.dia_viernes);
        data.append('dia_sabado', this.state.dia_sabado);
        data.append('dia_domingo', this.state.dia_domingo);

        data.append('horain_lunes', this.state.horain_lunes);
        data.append('horain_martes', this.state.horain_martes);
        data.append('horain_miercoles', this.state.horain_miercoles);
        data.append('horain_jueves', this.state.horain_jueves);
        data.append('horain_viernes', this.state.horain_viernes);
        data.append('horain_sabado', this.state.horain_sabado);
        data.append('horain_domingo', this.state.horain_domingo);
        data.append('horafin_lunes', this.state.horafin_lunes);
        data.append('horafin_martes', this.state.horafin_martes);
        data.append('horafin_miercoles', this.state.horafin_miercoles);
        data.append('horafin_jueves', this.state.horafin_jueves);
        data.append('horafin_viernes', this.state.horafin_viernes);
        data.append('horafin_sabado', this.state.horafin_sabado);
        data.append('horafin_domingo', this.state.horafin_domingo);

        await RequestService.put('schedule/' + this.state.id_horario, data);
        toastr.success('Horario Actualizado');
        this.setState({
          issubmitting: false,
          hora_inicio_jornada: '',
          hora_fin_hornada: '',
          total_horas_diarias: '',
          horas_receso: '',
          descripcion: '',
        });
        this.props.history.push("/employee/schedule/table");
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }

  sumhour() {
    let hour = 0;
    hour = parseInt(this.state.dia_lunes) + parseInt(this.state.dia_martes) + parseInt(this.state.dia_miercoles) +
      parseInt(this.state.dia_jueves) + parseInt(this.state.dia_viernes) + parseInt(this.state.dia_sabado) + parseInt(this.state.dia_domingo);
    return hour;
  }


  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Editar Horario</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/schedule/table"
                  role="button">Horarios
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Editar</li>
            </ol>
          </nav>
        </div>
        <form>
          <div className="row">
            {Utils.loading(this.state.issubmitting)}

            <div className="col-md-4 grid-margin stretch-card">
              <div className="card">
                <div className="card-body">

                  <Form.Group>
                    <label htmlFor="descripcion">Descripción de horario:</label>
                    <Form.Control type="text"
                      value={this.state.descripcion}
                      className={Utils.loaderrors(this.state.errors, 'descripcion')}
                      id="descripcion"
                      onChange={(val) => {

                        this.setState({ descripcion: val.target.value });
                      }}
                      placeholder="Descripción" size="lg" />
                  </Form.Group>

                  <button type="button"
                    className="btn btn-success btn-lg"
                    style={{ margin: '5px' }}
                    onClick={this.updateuser}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch" /> : "Guardar"}</button>
                  <Link to={'/employee/schedule/table'} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>

                </div>
              </div>
            </div>
            <div className="col-md-8 grid-margin stretch-card">
              <div className="card">
                <div className="card-body">
                  <h6>Horas Trabajadas por semana: {this.sumhour()}</h6>
                  <br />
                  <div className="row">
                    <div className="col-md-12">
                      <div>
                        <div className="row">
                          <div className="col-md-2">
                            <p style={{ 'padding-top': '15px' }}>
                              Día:
                              </p>
                          </div>
                          <div className="col-md-3">
                            <p style={{ 'padding-top': '15px' }}>
                              Total de Horas:
                              </p>
                          </div>
                          <div className="col-md-3">
                            <p style={{ 'padding-top': '15px' }}>
                              Hora de Entrada:
                              </p>
                          </div>
                          <div className="col-md-3">
                            <p style={{ 'padding-top': '15px' }}>
                              Hora de Salida:
                              </p>
                          </div>
                        </div>
                      </div>
                      <hr />
                      <Form.Group>
                        <div className="row">
                          <div className="col-md-2">
                            <label htmlFor="dia_lunes" style={{ 'padding-top': '15px' }}>
                              Lunes:
                              </label>
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="number"
                              max={8}
                              value={this.state.dia_lunes}
                              className={Utils.loaderrors(this.state.errors, 'dia_lunes')}
                              id="dia_lunes"
                              onChange={(val) => {
                                if (val.target.value >= 0) {
                                  this.setState({ dia_lunes: val.target.value });
                                } else {
                                  this.setState({ dia_lunes: 0 });
                                }
                              }}
                              placeholder="0" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horain_lunes}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horain_lunes')}
                              onChange={(val) => {
                                this.setState({ horain_lunes: val.target.value });
                              }}
                              id="horain_lunes" placeholder="Inicio" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horafin_lunes}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horafin_lunes')}
                              onChange={(val) => {
                                this.setState({ horafin_lunes: val.target.value });
                              }}
                              id="horafin_lunes" placeholder="Fin" size="lg" />
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group>
                        <div className="row">
                          <div className="col-md-2">
                            <label htmlFor="dia_lunes" style={{ 'padding-top': '15px' }}>
                              Martes:
                              </label>
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="number"
                              max={8}
                              value={this.state.dia_martes}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'dia_martes')}
                              id="dia_martes"
                              onChange={(val) => {
                                if (val.target.value >= 0) {
                                  this.setState({ dia_martes: val.target.value });
                                } else {
                                  this.setState({ dia_martes: 0 });
                                }
                              }}
                              placeholder="0" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horain_martes}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horain_martes')}
                              onChange={(val) => {
                                this.setState({ horain_martes: val.target.value });
                              }}
                              id="horain_martes" placeholder="Inicio" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horafin_martes}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horafin_martes')}
                              onChange={(val) => {
                                this.setState({ horafin_martes: val.target.value });
                              }}
                              id="horafin_martes" placeholder="Inicio" size="lg" />
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group>
                        <div className="row">
                          <div className="col-md-2">
                            <label htmlFor="dia_lunes" style={{ 'padding-top': '15px' }}>
                              Miércoles:
                              </label>
                          </div>
                          <div className="col-md-3">

                            <Form.Control type="number"
                              max={8}
                              value={this.state.dia_miercoles}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'dia_miercoles')}
                              id="dia_miercoles"
                              onChange={(val) => {
                                if (val.target.value >= 0) {
                                  this.setState({ dia_miercoles: val.target.value });
                                } else {
                                  this.setState({ dia_miercoles: 0 });
                                }
                              }}
                              placeholder="0" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horain_miercoles}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horain_miercoles')}
                              onChange={(val) => {
                                this.setState({ horain_miercoles: val.target.value });
                              }}
                              id="horain_miercoles" placeholder="Inicio" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horafin_miercoles}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horafin_miercoles')}
                              onChange={(val) => {
                                this.setState({ horafin_miercoles: val.target.value });
                              }}
                              id="horafin_miercoles" placeholder="Inicio" size="lg" />
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group>
                        <div className="row">
                          <div className="col-md-2">
                            <label htmlFor="dia_lunes" style={{ 'padding-top': '15px' }}>
                              Jueves:
                              </label>
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="number"
                              max={8}
                              value={this.state.dia_jueves}
                              className={Utils.loaderrors(this.state.errors, 'dia_jueves')}
                              id="dia_jueves"
                              onChange={(val) => {
                                if (val.target.value >= 0) {
                                  this.setState({ dia_jueves: val.target.value });
                                } else {
                                  this.setState({ dia_jueves: 0 });
                                }
                              }}
                              placeholder="0" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horain_jueves}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horain_jueves')}
                              onChange={(val) => {
                                this.setState({ horain_jueves: val.target.value });
                              }}
                              id="horain_jueves" placeholder="Inicio" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horafin_jueves}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'v')}
                              onChange={(val) => {
                                this.setState({ horafin_jueves: val.target.value });
                              }}
                              id="horafin_jueves" placeholder="Inicio" size="lg" />
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group>
                        <div className="row">
                          <div className="col-md-2">
                            <label htmlFor="dia_lunes" style={{ 'padding-top': '15px' }}>
                              Viernes:
                              </label>
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="number"
                              max={8}
                              value={this.state.dia_viernes}
                              className={Utils.loaderrors(this.state.errors, 'dia_viernes')}
                              id="dia_viernes"
                              onChange={(val) => {
                                if (val.target.value >= 0) {
                                  this.setState({ dia_viernes: val.target.value });
                                } else {
                                  this.setState({ dia_viernes: 0 });
                                }
                              }}
                              placeholder="0" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horain_viernes}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horain_viernes')}
                              onChange={(val) => {
                                this.setState({ horain_viernes: val.target.value });
                              }}
                              id="horain_viernes" placeholder="Inicio" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horafin_viernes}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horafin_viernes')}
                              onChange={(val) => {
                                this.setState({ horafin_viernes: val.target.value });
                              }}
                              id="horafin_viernes" placeholder="Inicio" size="lg" />
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group>
                        <div className="row">
                          <div className="col-md-2">
                            <label htmlFor="dia_lunes" style={{ 'padding-top': '15px' }}>
                              Sábado:
                              </label>
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="number"
                              max={8}
                              value={this.state.dia_sabado}
                              className={Utils.loaderrors(this.state.errors, 'dia_sabado')}
                              id="dia_sabado"
                              onChange={(val) => {
                                if (val.target.value >= 0) {
                                  this.setState({ dia_sabado: val.target.value });
                                } else {
                                  this.setState({ dia_sabado: 0 });
                                }
                              }}
                              placeholder="0" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horain_sabado}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horain_sabado')}
                              onChange={(val) => {
                                this.setState({ horain_sabado: val.target.value });
                              }}
                              id="horain_sabado" placeholder="Inicio" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horafin_sabado}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horafin_sabado')}
                              onChange={(val) => {
                                this.setState({ horafin_sabado: val.target.value });
                              }}
                              id="horafin_sabado" placeholder="Fin" size="lg" />
                          </div>
                        </div>
                      </Form.Group>

                      <Form.Group>
                        <div className="row">
                          <div className="col-md-2">
                            <label htmlFor="dia_lunes" style={{ 'padding-top': '15px' }}>
                              Domingo:
                              </label>
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="number"
                              max={8}
                              value={this.state.dia_domingo}
                              className={Utils.loaderrors(this.state.errors, 'dia_domingo')}
                              id="dia_domingo"
                              onChange={(val) => {
                                if (val.target.value >= 0) {
                                  this.setState({ dia_domingo: val.target.value });
                                } else {
                                  this.setState({ dia_domingo: 0 });
                                }
                              }}
                              placeholder="0" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horain_domingo}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horain_domingo')}
                              onChange={(val) => {
                                this.setState({ horain_domingo: val.target.value });
                              }}
                              id="horain_domingo" placeholder="Inicio" size="lg" />
                          </div>
                          <div className="col-md-3">
                            <Form.Control type="time"
                              value={this.state.horafin_domingo}
                              className={"form-control " + Utils.loaderrors(this.state.errors, 'horafin_domingo')}
                              onChange={(val) => {
                                this.setState({ horafin_domingo: val.target.value });
                              }}
                              id="horafin_domingo" placeholder="Fin" size="lg" />
                          </div>
                        </div>
                      </Form.Group>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    )
  }
}

export default UserNew;
