import React, { Component } from "react";
import { Button, Form, Modal } from "react-bootstrap";
import { Link } from "react-router-dom";
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider from "react-bootstrap-table2-toolkit";
import Cookies from "universal-cookie";
import "react-confirm-alert/src/react-confirm-alert.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";
import { confirmAlert } from "react-confirm-alert";

const cookies = new Cookies();

class Planilla extends Component {
  constructor(props) {
    super(props);
    var role = cookies.get("id_rol");
    this.state = {planilladata: [],creditos:[],debitos:[],issubmitting: true,role: role,show: false,showstudent: false,showdetail: false,codigoplanilla: 0};
    this.getdataplanilla = this.getdataplanilla.bind(this);
    this.aproveContract = this.aproveContract.bind(this);
    this.noaproveContract = this.noaproveContract.bind(this);
    //this.update = this.update.bind(this);
    //this.add = this.add.bind(this);
    //this.delete = this.delete.bind(this);
  }

  columnscrdr = [
    {
      dataField: "descripcion",
      text: "Descripcion",
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            {cell}
            <br />
            <small>{row.descuento_directo}</small>
          </div>
        );
      },
      footer: "Totales",
    },
    {dataField:"monto",text:"Monto",sort:true,align:"right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);},
      footerAlign: (column, colIndex) => "right",
      footer: (columnData) => columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
    },
  ];

  columns = [
    {
      dataField: "ano",
      text: "Año",
      headerClasses: 'headertableclass',
      sort: true,
      footer: ""
    },
    {
      dataField: "totaldevengado",
      text: "Total Devengado",
      align: "right",
      sort: true,
      headerClasses: 'headertableclass',
      footerClasses: 'footertableclass',
      style:  (cell, row, rowIndex, colIndex) => {return { backgroundColor: "rgb(245 255 245)" };},
      footer: (columnData) =>columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item),0).toFixed(2),
      footerAlign: (column, colIndex) => "right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);}
    }
  ];

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let id_contrato = this.props.match.params.id;
      let anos = await RequestService.get("payroll/end/yeardetail/" + id_contrato,null);
      let detail = await RequestService.get("payroll/end/detail/" + id_contrato,null);   
      this.setState(detail.data[0]);
      this.setState({ issubmitting: false, planilladata:anos.data});
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error("Los datos no pudieron ser consultados.","Intente de nuevo");
    }
  }

  async getdataplanilla(id) {
    try {
      this.setState({ issubmitting: true });
      let planilla = await RequestService.get("payroll/detailpayroll/" + id,null);
      let datosdetalle = await RequestService.get("payroll/employee/" + id,null);
      let dr =[], cr =[];
      planilla.data.forEach((element) => {
        if (element.crdr === "CR") {
          cr.push(element);
        } else {dr.push(element); }
      });
      this.setState(datosdetalle.data[0]);
      this.setState({
        detalle_planilla: planilla.data,
        debitos: dr,
        creditos: cr,
      });
      this.setState({ issubmitting: false, show: true });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error(
        "Los datos no pudieron ser consultados.",
        "Intente de nuevo"
      );
    }
  }

  /*async update() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append("comentario", this.state.descripcion);
      form.append("tabla", "n");
      await RequestService.put("payroll/comment/" + this.state.id_nomina, form);
      toastr.success("Comentario Guardado");
      this.setState({ descripcion: "" });
      await this.getdata();
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error(
        "Los datos no pudieron ser actualizados.",
        "Intente de nuevo"
      );
    }
  }*/

  async aproveContract() {
    confirmAlert({
      title: "Actualizar",
      message: "¿Seguro desea aprobar la planilla?",
      buttons: [
        {
          label: "Si",
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let data = new FormData();
              data.append("accion", true);
              let rs = await RequestService.post(
                "payroll/nomina/aprove/" + this.state.id_nomina,
                data
              );
              toastr.success("Actualizacion realizada");
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                "Los datos no pudieron ser actualizados.",
                "Intente de nuevo"
              );
            }
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  }

  async noaproveContract() {
    confirmAlert({
      title: "Actualizar",
      message: "¿Seguro desea realizar esta acción?",
      buttons: [
        {
          label: "Si",
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let data = new FormData();
              data.append("accion", false);
              await RequestService.post(
                "payroll/nomina/aprove/" + this.state.id_nomina,
                data
              );
              toastr.success("Actualizacion realizada");
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                "Los datos no pudieron ser actualizados.",
                "Intente de nuevo"
              );
            }
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  }

  async add() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append("id_nomina", this.state.id_nomina);
      form.append("id_empleado", this.state.id_empleado);
      await RequestService.post("payroll/addemployee/", form);
      toastr.success("Comentario Guardado");
      await this.getdata();
    } catch (e) {
      console.log(e);
      this.setState({ issubmitting: false });
      toastr.error(
        "Los datos no pudieron ser actualizados.",
        "Intente de nuevo"
      );
    }
  }

  async delete(id) {
    confirmAlert({
      title: "Eliminar",
      message: "¿Seguro desea realizar esta acción?",
      buttons: [
        {
          label: "Si",
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let form = new FormData();
              await RequestService.delete("payroll/detail/" + id, form);
              toastr.success("Eliminado");
              await this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                "Los datos no pudieron ser consultados.",
                "Intente de nuevo"
              );
            }
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  }


  render() {
    return (
      <div>
        <div className="page-header">
    <h1 className="page-title">Detalle de Liquidación: {this.state.nombre} {Utils.showstatus(this.state.idestadonomina, this.state.estadonomina)}</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link to="/payroll" role="button">
                  Planillas
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link to="/payroll/first/planillas" role="button">
                  Generar Planillas
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                Detalle
              </li>
            </ol>
          </nav>
        </div>   
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="row">
                  <div className="col-lg-12"/>
                  <div className="row">
                    <div className="col-lg-3">
                      <h4>Devengado Anualmente:</h4>
                      <hr/>
                      <ToolkitProvider
                        keyField="ano"
                        data={this.state.planilladata}
                        columns={this.columns}
                        search
                        loading={true}
                      >
                        {(props) => (
                          <div className={"row"}>
                            <BootstrapTable
                              noDataIndication={
                                "No se encontraron registros para mostrar."
                              }
                              {...props.baseProps}
                            />
                          </div>
                        )}
                      </ToolkitProvider>
                    </div>
                    <div className="col-lg-9">
                      <h4>Detalle de Finalización de Contrato:</h4>
                      <hr/>
                      <div className="row">
                        <div className="col-lg-6">
                          <div className="row">
                            <div className="col-lg-5 font-weight-bold text-right">Tipo de Contrato:</div>
                            <div className="col-lg-7">{this.state.tipocontrato}</div>
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="row">
                            <div className="col-lg-5 font-weight-bold text-right">Departamento:</div>
                            <div className="col-lg-7">{this.state.departamento}</div>
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="row">
                            <div className="col-lg-5 font-weight-bold text-right">Inicio de Labores:</div>
                            <div className="col-lg-7">{this.state.fecha_inicio_labores}</div>
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="row">
                            <div className="col-lg-5 font-weight-bold text-right">Fecha Fin de Labores:</div>
                            <div className="col-lg-7">{this.state.fecha_culmina}</div>
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="row">
                            <div className="col-lg-5 font-weight-bold text-right">Fecha Fin de Labores:</div>
                            <div className="col-lg-7">{this.state.fecha_culmina}</div>
                          </div>
                        </div>

                        <div className="col-lg-6">
                          <div className="row">
                            <div className="col-lg-5 font-weight-bold text-right">Tipo de Terminación:</div>
                            <div className="col-lg-7">{this.state.finaliza}</div>
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="row">
                            <div className="col-lg-5 font-weight-bold text-right">Motivo de Terminación:</div>
                            <div className={'border overflow-auto p-2'} style={{'height':'145px', 'width':'55%'}}>
                              {this.state.motivo}
                            </div>
                          </div>
                        </div>
                      </div>
                      <h4>Detalle de Pago:   
                        {this.state.idestadonomina===0 ? <button
                            style={{ "marginLeft": "10px" }}
                            //onClick={() => this.adddata(cell)}
                            className="btn btn-success p-1 m-1"
                        >
                         Generar Pago <i className="fa fa-mail-forward" />
                        </button>:null}
                      </h4>
                      <hr/>
                      <div className="row">
                        
                        <div className={'col-lg-12'}>
                          {/* <button type="button" onClick={()=> {
                              this.handleShow()
                            }} className="btn btn-success mb-2">Agregar Descuentos</button> */}
                        </div>
                        <div className={'col-lg-6 stretch-card'}>
                          <div className="card">
                            <div className="card-body">
                              <h4>Ingresos</h4>
                              <BootstrapTable
                                noDataIndication={"No se encontraron registros para mostrar."}
                                keyField="id_descuento_realizado"
                                data={this.state.creditos}
                                columns={this.columnscrdr}
                                loading={true}
                              />
                            </div>
                          </div>
                        </div>
                        <div className={'col-lg-6'}>
                          <div className="card">
                            <div className="card-body">
                              <h4>Descuentos</h4>
                              <BootstrapTable
                                  noDataIndication={"No se encontraron registros para mostrar."}
                                  keyField="id_descuento_realizado"
                                  data={this.state.debitos}
                                  columns={this.columnscrdr}
                                  loading={true}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr />
                  <div className="row">
                    <div className="col-lg-12">
                      {this.state.id_estado === 7 &&
                        cookies.get("id_rol") === "1" ? (
                          <button
                            type="button"
                            className="btn btn-warning"
                            style={{ margin: "5px" }}
                            onClick={this.aproveContract}
                          >
                            {this.state.issubmitting ? (
                              <i className="fa fa-spin fa-circle-o-notch" />
                            ) : (
                                "Aprobar"
                              )}
                          </button>
                        ) : null}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}


export default Planilla;
