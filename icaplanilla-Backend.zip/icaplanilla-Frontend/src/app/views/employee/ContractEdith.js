import React, { Component } from "react";
import { Form, Modal, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Utils from "../../../services/Utils"
import RequestService from '../../../services/RequestService';
import toastr from "toastr";
import DatePicker from "react-datepicker/es";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import Cookies from 'universal-cookie';
import moment from "moment";

const cookies = new Cookies();

const SearchBar = (props) => {
  let input;
  return (
      <div>
        <Form.Group>
          <Form.Control type="text" ref={n => input = n}
                        placeholder="Buscar"
                        size="lg"
                        onChange={() => {
                          props.onSearch(input.value);
                        }}
          />
        </Form.Group>
      </div>
  );
};

export class ContractEdith extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id_departamento: 0,
      id_ocupacion: 0,
      id_tipocontrato: 8,
      id_horario: 0,
      id_finaliza:0,
      nombre:'',
      apellido:'',
      id_tipo_finaliza:1,
      motivo:'',
      fecha_inicio_labores: new Date(),
      fecha_fin_labores: new Date(),
      fecha_culmina:new Date(),
      departmentdata: [],
      horarios: [],
      ocupationdata: [],
      salarydata: [],
      initialocupation: [],
      issubmitting: false,
      show: false,
      showfinaliza:false,
      id_empleado: 0
    }

    this.aproveContract = this.aproveContract.bind(this);
    this.noaproveContract = this.noaproveContract.bind(this);
    this.modalclose = this.modalclose.bind(this);
    this.modalshow = this.modalshow.bind(this);
    this.modalclosefinaliza = this.modalclosefinaliza.bind(this);
    this.modalfinaliza = this.modalfinaliza.bind(this);
    this.newsalary = this.newsalary.bind(this);
    this.createupdatesalary = this.createupdatesalary.bind(this);
    this.updatecontract = this.updatecontract.bind(this);
    this.finaliza = this.finaliza.bind(this);
    this.updatesalariohora=this.updatesalariohora.bind(this);

  }

  columns = [
    { dataField: 'fecha_creacion', text: 'Fecha de creación', sort: true },
    { dataField: 'monto_mensual', text: 'Salario Mensual', sort: true, formatter: (cell, row) => { return cell.toFixed(2); } },
    { dataField: 'monto_quincenal', text: 'Salario Quicenal', sort: true, formatter: (cell, row) => { return cell.toFixed(2); } },
    { dataField: 'monto_hora', text: 'Salario por Hora', sort: true },
    {
      dataField: 'id_estado', text: 'Estado', sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(cell, row.descripcion);
      }
    },
    {
      dataField: 'observacion', text: 'Observaciones', sort: true,
      formatter: (cell, row) => {
      return <div style={{ 'marginLeft': '5px' }}>{cell}</div> ;
      }
    
    },
    {
      dataField: 'id_salario', text: 'Acciones', sort: true,
      formatter: (cell, row) => {
        return row.id_estado === 7 ? <div>
          <button style={{ 'marginLeft': '5px' }} onClick={() => this.aprovesalary(cell)} className="btn btn-warning"><i className="fa fa-check"></i></button>
          <button style={{ 'marginLeft': '5px' }} onClick={() => this.modalsalaryupdate(cell)} className="btn btn-success"><i className="fa fa-edit"></i></button>
        </div> : null;
      }
    
    }];

  componentDidMount() {
    let { id_empleado } = this.props.location.state;
    this.setState({ id_empleado: id_empleado });
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let id = this.props.match.params.id;
      let contract = await RequestService.get('contract/' + id, null);
      let salario = await RequestService.get('salary/' + id + '/contract', null);

      this.setState({departamento: contract.data[0].departamento,
        estado: contract.data[0].estado,
        fecha_fin_labores:    Utils.improveDate(contract.data[0].fecha_fin_labores),
        fecha_inicio_labores: Utils.improveDate(contract.data[0].fecha_inicio_labores) ,
        horario: contract.data[0].horario,
        id_contrato: contract.data[0].id_contrato,
        id_departamento: contract.data[0].id_departamento,
        id_estado: contract.data[0].id_estado,
        id_horario: contract.data[0].id_horario,
        id_ocupacion: contract.data[0].id_ocupacion,
        horas:contract.data[0].horas,
        id_tipocontrato: contract.data[0].id_tipocontrato,
        nombre: contract.data[0].nombre,
        hora_semana: contract.data[0].hora_semana,
        apellido: contract.data[0].apellido,
        ocupacion: contract.data[0].ocupacion,
        tipocontrato: contract.data[0].tipocontrato});

      if (contract.data[0].id_estado === 7 || this.state.id_estado === 6) {
        let mydepartment = await RequestService.get('department/', null);
        let myocupacion = await RequestService.get('ocupation/', null);
        let horarios = await RequestService.get('schedule/list/', null);
        this.setState({ horarios: horarios.data, departmentdata: mydepartment.data, ocupationdata: myocupacion.data });
      }else if (contract.data[0].id_estado === 11 || this.state.id_estado === 10) {
        let finaliza = await RequestService.get('contract/finalize/'+id, null);
        this.setState({motivo:finaliza.data[0].motivo,id_tipo_finaliza:finaliza.data[0].id_tipo_finaliza,
          id_finaliza:finaliza.data[0].id_finaliza, fecha_culmina:Utils.improveDate(finaliza.data[0].fecha_culmina)})
      }
      this.setState({ salarydata: salario.data, issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.');
    }
  }

  async contratoestado(tipo){
    try {
      this.setState({ issubmitting: true });
      let data = new FormData();
      data.append('accion', tipo);
      await RequestService.post('contract/aprove/' + this.props.match.params.id, data);
      toastr.success('Actualizacion realizada');
      this.getdata();
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.');
    }
  }

  async aproveContract() {
    confirmAlert({
      title: 'Actualizar',
      message: this.state.id_estado === 6 || this.state.id_estado === 11 ? '¿Seguro desea finalizar el contrato?' : '¿Seguro desea aprobar el contrato?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            this.contratoestado(true);
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }

  async noaproveContract() {
    confirmAlert({
      title: 'Actualizar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            this.contratoestado(false);
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }

  async aprovesalary(id) {
    confirmAlert({
      title: 'Acciones',
      message: '¿Que acción desea tomar sobre el salario?',
      buttons: [
        {
          label: 'Aprobar',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let data = new FormData();
              data.append('id_estado', 6);
              await RequestService.put('salary/' + id + '/approve', data);
              toastr.success('Actualizacion realizada');
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser actualizados.');
            }
          }
        },
        {
          label: 'No aprobar',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let data = new FormData();
              data.append('id_estado', 8);
              await RequestService.put('salary/' + id + '/approve', data);
              toastr.success('Actualizacion realizada');
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser actualizados.');
            }
          }
        },
        {
          label: 'Cancelar',
          onClick: () => null
        }
      ]
    });
  }

  async newsalary(type) {
    try {
      this.setState({ issubmitting: true });
      let rs = await RequestService.post('contract/hassalary/' + this.props.match.params.id, null);
      if (rs.data[0].result === "0") {
        this.setState({ show: true, typefunction: type, issubmitting: false });
      } else {
        toastr.warning('Contrato ya cuenta con salario pendiente por aprobar.');
        this.setState({ issubmitting: false });
      }
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Error de conexión.', 'Intente de nuevo');
    }
  }

  async updatecontract(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('id_empleado', this.state.id_empleado);
        data.append('fecha_inicio_labores', moment(this.state.fecha_inicio_labores).format("YYYY-MM-DD"));
        data.append('fecha_fin_labores', moment(this.state.fecha_fin_labores).format("YYYY-MM-DD"));
        data.append('id_tipocontrato', this.state.id_tipocontrato);
        data.append('id_horario', this.state.id_horario);
        data.append('ocupacion', this.state.id_ocupacion);
        data.append('departamento', this.state.id_departamento);
        data.append('hora_semana', this.state.hora_semana);
        
        await RequestService.put('contract/' + this.props.match.params.id, data);
        toastr.success('Contrato Actualizado');
        this.getdata();
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }



  async finaliza(){
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('motivo', this.state.motivo);
        data.append('id_contrato', this.state.id_contrato);
        data.append('id_tipo_finaliza', this.state.id_tipo_finaliza);
        data.append('fecha_culmina',moment(this.state.fecha_culmina).format("YYYY-MM-DD"));

        let rs=[]
        if(this.state.id_finaliza===0){
          rs= await RequestService.post('contract/finalize/', data);
        }else{
          rs=await RequestService.put('contract/finalize/'+this.state.id_finaliza, data);
        }

        if(rs.data.insertId!==0){
          this.contratoestado(true);
        }
        toastr.success('Contrato actualizado para finalización');
        this.setState({ showfinaliza: false });
        this.getdata();
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }

  async createupdatesalary() {
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();

        data.append('monto_mensual', this.state.monto_mensual);
        data.append('monto_quincenal', this.state.monto_quincenal);
        data.append('monto_hora', this.state.monto_hora);
        data.append('id_contrato', this.state.id_contrato);

        if (this.state.typefunction === 'Agregar') {
          await RequestService.post('salary/', data);
          toastr.success('Salario Creado');
        } else {
          await RequestService.put('salary/' + this.state.id_salario, data);
          toastr.success('Salario Actualizado');
        }
        this.getdata();
        this.setState({ show: false });
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }


  listadepartment() {
    let data = this.state.departmentdata.map((value, index) => {
      return <option value={value.id_departamento}>{value.descripcion}</option>
    });
    data.unshift(<option value={0}>--------</option>);
    return data;
  }

  listhorarios() {
    let data = this.state.horarios.map((value, index) => {
      return <option value={value.id_horario}>{value.descripcion}</option>
    });
    data.unshift(<option value={0}>--------</option>);
    return data;
  }

  cambiahoras(id) {
    let rs = Object.keys(this.state.horarios).find(key => this.state.horarios[key].id_horario === parseInt(id));
    this.setState({horas:this.state.horarios[rs].horas});
  }

  listocupation() {
    let data = this.state.ocupationdata.map((value, index) => {
      if (parseInt(this.state.id_departamento) === parseInt(value.id_departamento)) {
        return <option value={value.id_ocupacion}>{value.descripcion}</option>
      }
      return null;
    });
    data.unshift(<option value={0}>--------</option>);
    return data;
  }

  updatesalariohora(){
    try{
      //let montohora = (this.state.monto_mensual/4.3333)/this.state.hora_semana;
      let montoquin = this.state.monto_mensual/2;
      //this.setState({monto_hora:montohora.toFixed(5), monto_quincenal:montoquin});
      this.setState({monto_quincenal:montoquin});
    }catch(e){
      this.setState({monto_hora:0,monto_quincenal:0});
    }
  }

  validacionmostrar(){
    return (this.state.id_estado === 7 || this.state.id_estado === 6 ) && cookies.get('id_rol') === '1'
  }

  modalclose() {this.setState({ show: false });}
  modalshow() {this.setState({ show: true });}
  modalclosefinaliza() {this.setState({ showfinaliza: false });}
  modalfinaliza() {this.setState({ showfinaliza: true });}


  async modalsalaryupdate(id) {
    try {
      this.setState({ issubmitting: true });
      let salario = await RequestService.get('salary/' + id, null);
      this.setState(salario.data[0]);
      this.setState({ issubmitting: false, show: true, id_salario: id, typefunction: 'Actualizar' });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Error de conexión.', 'Intente de nuevo');
    }
  }

  render() {
    return (
        <div>
          <Modal show={this.state.showfinaliza}  onHide={this.modalclosefinaliza}>
            <Modal.Header closeButton>
              <Modal.Title>Motivo de Finalización:</Modal.Title>
            </Modal.Header>
            <Modal.Body className={'row'}>
              <div className={'col-lg-12'}>
                <Form.Group>
                  <label htmlFor="id_horario">Motivo de finalización:</label>
                  <select
                      value={this.state.id_tipo_finaliza}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'id_tipo_finaliza')}
                      onChange={(val) => {
                        this.setState({ id_tipo_finaliza: val.target.value });
                      }}
                      size="lg"
                      id="id_horario">
                    <option value={1}>Renuncia</option>
                    <option value={2}>Despido</option>
                    <option value={3}>Despido Justificado (Art. 213)</option>
                    <option value={4}>Mutuo acuerdo (Art. 210 Numeral 1)</option>
                    <option value={5}>Despido por terminación de contrato (Art. 210 Numeral 3)</option>
                    <option value={6}>Despido por menos de 2 años (Art. 212)</option>
                  </select>
                </Form.Group>
              </div>
              <div className={'col-lg-12'}>
                <Form.Group>
                  <label htmlFor="nombre">Fecha Finaliza:</label>
                  <br/>
                  <DatePicker
                      dateFormat="dd/MM/yyyy"
                      selected={this.state.fecha_culmina}
                      onChange={(date) => {this.setState({ fecha_culmina: date });}}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_culmina')}
                      size="lg"
                  />
                </Form.Group>
              </div>

              <div className={'col-lg-12'}>
                <Form.Group>
                  <label htmlFor="nombre">Motivo:</label>
                  <textarea
                      name={"motivo"}
                      rows="4"
                      className={"form-control " +Utils.loaderrors(this.state.errors, "motivo")
                      }
                      value={this.state.motivo}
                      onChange={(val) => {
                        this.setState({ motivo: val.target.value });
                      }}
                  />
                </Form.Group>
              </div>

            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={this.modalclosefinaliza}>
                Cerrar
              </Button>
              <Button variant="primary" onClick={this.finaliza}>
                Guardar
              </Button>
            </Modal.Footer>
          </Modal>

          <div className="page-header">
            <h1 className="page-title">Detalles del Contrato: {this.state.nombre+ ' ' + this.state.apellido + ' '} { Utils.showstatus(this.state.id_estado, this.state.estado)}</h1>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link
                      to="/employee/"
                      role="button">Recursos Humanos
                  </Link>
                </li>
                <li className="breadcrumb-item">
                  <Link
                      to="/employee/table"
                      role="button">Colaboradores
                  </Link>
                </li>
                <li className="breadcrumb-item">
                  <Link
                      to={'/employee/' + this.state.id_empleado}
                      role="button">Contratos
                  </Link>
                </li>
                <li className="breadcrumb-item active" aria-current="page">Editar</li>
              </ol>
            </nav>
          </div>
          <form className="forms-sample">
            {Utils.loading(this.state.issubmitting)}
            <div className=" grid-margin stretch-card">
              <div className="card">
                <div className="card-body">
                  <div className="row">
                    <div className="col-4">
                      <Form.Group>
                        <label htmlFor="id_tipocontrato">Tipo de contrato:</label>
                        {this.validacionmostrar() ? <select
                            value={this.state.id_tipocontrato}
                            className={"form-control " + Utils.loaderrors(this.state.errors, 'id_tipocontrato')}
                            onChange={(val) => {
                              this.setState({ id_tipocontrato: val.target.value, fecha_fin_labores: '' });
                            }}
                            size="lg"
                            id="id_tipocontrato">
                          <option value={8}>Indefinido</option>
                          <option value={9}>Definido</option>
                        </select> : <div>{this.state.tipocontrato}</div>}
                      </Form.Group>
                    </div>
                    <div className="col-4 ">
                      <Form.Group>
                        <label htmlFor="fecha_inicio_labores">Fecha de Inicio:</label>
                        <br/>
                        {this.validacionmostrar() ?<DatePicker
                            dateFormat="dd-MM-yyyy"
                            selected={this.state.fecha_inicio_labores}
                            //disabled={this.validacionmostrar()}
                            onChange={(date) => {
                              this.setState({ fecha_inicio_labores: date });
                            }}
                            className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_inicio_labores')}
                            size="lg"
                        />:<div>{moment(this.state.fecha_fin_labores).format("DD-MM-YYYY")}</div>}
                      </Form.Group>
                    </div>
                    {parseInt(this.state.id_tipocontrato) === 9 ? <div className="col-4 ">
                      <Form.Group>
                        <label htmlFor="fecha_fin_labores">Fecha de Finaliza:</label>
                        <br/>
                        {this.validacionmostrar() ?<DatePicker
                            dateFormat="dd/MM/yyyy"
                            minDate={this.state.fecha_inicio_labores}
                            //disabled={this.validacionmostrar()}
                            selected={this.state.fecha_fin_labores}
                            onChange={(date) => {
                              this.setState({ fecha_fin_labores: date });
                            }}
                            className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_fin_labores')}
                            size="lg"
                        />:<div>{moment(this.state.fecha_fin_labores).format("DD-MM-YYYY")}</div>}
                      </Form.Group>
                    </div> : null}
                    <div className="col-4">
                      <Form.Group>
                        <label htmlFor="departamento">Departamento:</label>
                        {this.validacionmostrar() ? <select
                            value={this.state.id_departamento}
                            className={"form-control " + Utils.loaderrors(this.state.errors, 'id_departamento')}
                            onChange={(val) => {
                              this.setState({ id_departamento: val.target.value });
                            }}
                            size="lg"
                            id="departamento">
                          {this.listadepartment()}
                        </select> : <div>{this.state.departamento}</div>}
                      </Form.Group>
                    </div>
                    <div className="col-4">
                      <Form.Group>
                        <label htmlFor="id_ocupacion">Ocupación:</label>
                        {this.validacionmostrar()? <select
                            value={this.state.id_ocupacion}
                            className={"form-control " + Utils.loaderrors(this.state.errors, 'id_ocupacion')}
                            onChange={(val) => {
                              this.setState({ id_ocupacion: val.target.value });
                            }}
                            size="lg"
                            id="ocupacion">
                          {this.listocupation()}
                        </select> : <div>{this.state.ocupacion}</div>}
                      </Form.Group>
                    </div>

                    <div className="col-4">
                      <Form.Group>
                        <label htmlFor="id_horario">Horario:</label>
                        {this.validacionmostrar() ? <select
                            value={this.state.id_horario}
                            className={"form-control " + Utils.loaderrors(this.state.errors, 'id_horario')}
                            onChange={(val) => {
                              this.cambiahoras(val.target.value);
                              this.setState({ id_horario: val.target.value });
                            }}
                            size="lg"
                            id="id_horario">
                          {this.listhorarios()}
                        </select> : <div>{this.state.horario}</div>}
                      </Form.Group>
                    </div>
                    <div className="col-4">
                      <Form.Group>
                        <label htmlFor="hora_semana">Horas Por Semana:</label>
                        {this.validacionmostrar() ? <Form.Control type="text"
                        value={this.state.hora_semana}
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'hora_semana')}
                        onChange={async (val) => {
                          await this.setState({ hora_semana: val.target.value });
                          this.updatesalariohora();
                        }}
                        id="hora_semana" placeholder="hora_semana" size="lg" />: <div>{this.state.hora_semana}</div>}
                      </Form.Group>
                    </div>
                  </div>


                  {this.validacionmostrar()? <button type="button" className="btn btn-success " style={{ margin: '5px' }} onClick={this.updatecontract}>{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button> : null}

                  {this.state.id_estado === 7 && cookies.get('id_rol') === '1' ? <button type="button" className="btn btn-warning " style={{ margin: '5px' }} onClick={this.aproveContract}>{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Aprobar"}</button> : null}
                  {this.state.id_estado === 7 && cookies.get('id_rol') === '1' ? <button type="button" className="btn btn-danger " style={{ margin: '5px' }} onClick={this.noaproveContract}>{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "No Aprobar"}</button> : null}

                  {this.state.id_estado === 6 ? <button type="button" className="btn btn-warning " style={{ margin: '5px' }} onClick={this.modalfinaliza}>{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Finalizar Contrato"}</button> : null}

                  {this.state.id_estado === 11 && cookies.get('id_rol') === '1' ? <button type="button" className="btn btn-danger " style={{ margin: '5px' }} onClick={this.aproveContract}>{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Finalizar"}</button> : null}
                  {this.state.id_estado === 11 && cookies.get('id_rol') === '1' ? <button type="button" className="btn btn-warning " style={{ margin: '5px' }} onClick={this.noaproveContract}>{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "No Finalizar"}</button> : null}

                  {this.state.id_estado === 10 ? <Link to={'/payroll/fourth/liquidaciones/' + this.state.id_contrato} className="btn btn-success " style={{ margin: '5px' }}>Ver Detalle</Link> : null}
                  
                  <Link to={'/employee/' + this.state.id_empleado} className="btn btn-secondary " style={{ margin: '5px' }}>Regresar</Link>

                  <hr/>
                  {this.state.id_estado === 11 || this.state.id_estado === 10?
                      <div className={'row'}>
                        <div className="col-6">
                          <div className="col-12" style={{'backgroundColor':'white !important'}}>
                            <Form.Group>
                              <label htmlFor="id_horario">Motivo de finalización:</label>
                              <select
                                  value={this.state.id_tipo_finaliza}
                                  className={"form-control "}
                                  disabled
                                  size="lg"
                                  id="id_horario">
                                <option value={1}>Renuncia</option>
                                <option value={2}>Despido</option>
                                <option value={3}>Despido Justificado (Art. 213)</option>
                                <option value={4}>Mutuo acuerdo (Art. 210 Numeral 1)</option>
                                <option value={5}>Despido por terminación de contrato (Art. 210 Numeral 3)</option>
                                <option value={6}>Despido por menos de 2 años (Art. 212)</option>
                              </select>
                            </Form.Group>
                          </div>
                          <div className="col-12">
                            <Form.Group>
                              <label htmlFor="nombre">Fecha Finaliza:</label>
                              <br/>
                              <DatePicker
                                  dateFormat="dd/MM/yyyy"
                                  selected={this.state.fecha_culmina}
                                  className={"form-control "}
                                  size="lg"
                                  disabled
                              />
                              {this.state.id_estado === 11 && cookies.get('id_rol') === '1' ?
                                  <button type="button" className="btn btn-primary p-3" style={{ margin: '5px' }} onClick={this.modalfinaliza}>
                                    {this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Editar"}
                                  </button>:null}
                            </Form.Group>

                          </div>

                        </div>

                        <div className="col-6">
                          <Form.Group>
                            <label htmlFor="motivo">Motivo:</label>
                            <div className={'border overflow-auto p-2'} style={{'height':'145px'}}>
                              {this.state.motivo}
                            </div>
                          </Form.Group>
                        </div>

                      </div>
                      :null}
                </div>
              </div>
            </div>
          </form>
          <div className=" grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="mb-5">
                  <h4 className="page-title">Datos de Salario:</h4>
                </div>
                <div>
                  <ToolkitProvider
                      keyField="id_salario"
                      data={this.state.salarydata}
                      columns={this.columns}
                      search
                      loading={true}
                  >
                    {
                      props => (
                          <div className={"row"}>
                            <div className="col-lg-8">
                              {this.state.id_estado === 7 || this.state.id_estado === 6 ? <Link onClick={() => { this.newsalary('Agregar') }} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Aumentar/Agregar Salario </Link> : null}
                            </div>
                            <div className="col-lg-4">
                              <SearchBar {...props.searchProps} className="form-control" />
                            </div>
                            <hr />
                            <BootstrapTable
                                noDataIndication={"No se encontraron registros para mostrar."}
                                pagination={paginationFactory({ hideSizePerPage: true, pageListRenderer: false })}
                                {...props.baseProps}
                            />
                          </div>
                      )
                    }
                  </ToolkitProvider>
                </div>
                <Modal show={this.state.show} onHide={this.modalclose}>
                  <Modal.Header closeButton>
                    <Modal.Title>{this.state.typefunction} Salario:</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    <div className="col-6 ">
                      <Form.Group>
                        <label htmlFor="monto_mensual">Salario Mensual:</label>
                        <Form.Control type="number"
                                      value={this.state.monto_mensual}
                                      className={"form-control" + Utils.loaderrors(this.state.errors, 'monto_mensual')}
                                      onChange={ async (val) => {
                                        await this.setState({ monto_mensual: val.target.value });
                                        this.updatesalariohora();
                                      }}
                                      id="monto_mensual" placeholder="0000.00" size="lg" />
                      </Form.Group>
                    </div>
                    <div className="col-6">
                      <Form.Group>
                        <label htmlFor="monto_quincenal">Salario Quincenal:</label>
                        <Form.Control type="number"
                                      value={this.state.monto_quincenal}
                                      className={"form-control" + Utils.loaderrors(this.state.errors, 'monto_quincenal')}
                                      //disabled
                                      onChange={(val) => {
                                        this.setState({ monto_quincenal: val.target.value });
                                      }}
                                      id="monto_quincenal" placeholder="0000.00" size="lg" />
                      </Form.Group>
                    </div>
                    <div className="col-6">
                      <Form.Group>
                        <label htmlFor="monto_hora">Salario por Hora:</label>
                        <Form.Control type="number"
                                      value={this.state.monto_hora}
                                      className={"form-control" + Utils.loaderrors(this.state.errors, 'monto_hora')}
                                      //disabled
                                      onChange={(val) => {
                                        this.setState({ monto_hora: val.target.value });
                                      }}
                                      id="monto_hora" placeholder="0000.00" size="lg" />
                      </Form.Group>
                    </div>
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={this.modalclose}>
                      Cerrar
                    </Button>
                    <Button variant="primary" onClick={this.createupdatesalary}>
                      {this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch" /> : "Guardar"}
                    </Button>
                  </Modal.Footer>
                </Modal>
              </div>
            </div>
          </div>
        </div>
    );
  }
}

export default ContractEdith;
