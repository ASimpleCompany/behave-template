import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';

export class CommitmentNew extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id: 0,
      descripcion: '',
      montototal: '',
      monto_letra_quincenal: '',
      id_empleado: 0
    }
    this.create = this.create.bind(this);
  }

  componentDidMount() {
    let { id_empleado } = this.props.location.state;
    this.setState({ id_empleado: id_empleado });
  }


  async create(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('descripcion', this.state.descripcion);
        data.append('montototal', this.state.montototal);
        data.append('monto_letra_quincenal', this.state.monto_letra_quincenal);
        data.append('id_empleado', this.state.id_empleado);
        await RequestService.post('commitment/', data);
        toastr.success('Compromiso Creado');
        this.props.history.push('/employee/' + this.state.id_empleado);
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }


  handleChange = date => {
    this.setState({
      startDate: date
    });
  };


  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title"> Agregar Compromiso</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to={'/employee/' + this.state.id_empleado}
                  role="button">Compromisos
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Agregar</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <form className="forms-sample">
                  <Form.Group>
                    <label htmlFor="descripcion">Descripción:</label>
                    <Form.Control type="text"
                      value={this.state.descripcion}
                      className={Utils.loaderrors(this.state.errors, 'descripcion')}
                      id="descripcion"
                      onChange={(val) => {
                        this.setState({ descripcion: val.target.value });
                      }}
                      placeholder="Descripción" size="lg" />
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="montototal">Monto Total de Compromiso:</label>
                    <Form.Control type="number"
                      value={this.state.montototal}
                      className={"form-control "+Utils.loaderrors(this.state.errors, 'montototal')}
                      onChange={(val) => {
                        this.setState({ montototal: val.target.value });

                      }}
                      id="montototal" placeholder="0000.00" />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="monto_letra_quincenal">Monto quincenal a deducir:</label>
                    <Form.Control type="text"
                      value={this.state.monto_letra_quincenal}
                      className={"form-control "+Utils.loaderrors(this.state.errors, 'monto_letra_quincenal')}
                      onChange={(val) => {

                        this.setState({ monto_letra_quincenal: val.target.value });

                      }}
                      id="monto_letra_quincenal" placeholder="0000.00" />
                  </Form.Group>

                  <button type="button"
                    className="btn btn-success btn-lg"
                    style={{ margin: '5px' }}
                    onClick={this.create}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button>
                  <Link to={'/employee/' + this.state.id_empleado} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default CommitmentNew;
