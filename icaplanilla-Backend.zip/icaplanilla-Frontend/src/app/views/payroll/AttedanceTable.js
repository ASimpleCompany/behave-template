import React, { Component } from "react";
import { Link } from "react-router-dom";
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { Form, FormFile, Modal, Button } from "react-bootstrap";
import RequestService from "../../../services/RequestService"
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import { Calendar, momentLocalizer, Views } from 'react-big-calendar';
import moment from 'moment';
import DatePicker from "react-datepicker";
require('moment/locale/es.js');

// Setup the localizer by providing the moment (or globalize) Object
// to the correct localizer.
const localizer = momentLocalizer(moment)// or globalizeLocalizer

const events = [{
  id: 0,
  title: 'Evento de todo el día título muy largo',
  allDay: false,
  start: new Date(2020, 6, 20),
  end: new Date(2020, 6, 20),
},
{
  id: 1,
  title: 'Evento Largo',
  start: new Date(2015, 3, 7),
  end: new Date(2015, 3, 10),
},

{
  id: 2,
  title: 'DTS STARTS',
  start: new Date(2016, 2, 13, 0, 0, 0),
  end: new Date(2016, 2, 20, 0, 0, 0),
}]

export class Attedance extends Component {

  constructor() {
    super();
    this.state = {
      file: null,
      dataAttend: '',
      attendUser: '',
      startDate: new Date(),
      endDate: new Date(),


    };

    this.handleClose = this.modalclose.bind(this);
    this.modalclose = this.modalclose.bind(this);
    this.handleShow = this.handleShow.bind(this);


  }

  onClickHandler = async (e) => {
    e.preventDefault();
    const data = new FormData()
    data.append('file', this.state.file)
    try {
      let file = await RequestService.uploadFile(data , this.state.startDate , this.state.endDate);

      this.setState({
        dataAttend: file.data.results
      })

      this.state.dataAttend.forEach(element => {
        let event = {};

        event.id = element.id
        event.title = `Incorrecta Asistencia  ${element.nombre}`
        event.start = new Date(`${element.fecha_marcacion} ${element.hora_entrada}`);
        event.end = new Date(`${element.fecha_marcacion} 00:00:00`);
        events.push(event)
      });

    } catch (e) {
        return;
    }
  };

  onChange = (event) => {
    let fileName = event.target.files[0].name;
    // event.target.siblings(".custom-file-label").addClass("selected").html(fileName);
    this.setState({
      file: event.target.files[0],
      attendance: '',
      fileName: fileName
    });
  }

  modalclose() {
    this.setState({ show: false });
  }

  handleShow(event) {
    this.setState({ show: true, attendUser: event });
  }

  setstartDate = (date) => {
    this.setState({
      startDate: date
    });
  }
  setEndDate =  (date) => {
    this.setState({
      endDate: date
    });
  }


  render() {
    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Cargar Marcaciones</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link to="/payroll" role="button">Planillas</Link></li>
              <li className="breadcrumb-item active" aria-current="page">Marcaciones</li>
            </ol>
          </nav>
        </div>
        <Modal show={this.state.show} onHide={this.modalclose}>
          <Modal.Header closeButton>
            <Modal.Title>{this.state.attendUser.title}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form.Group>
              <label htmlFor="nombre">Descripción:</label>
              <Form.Control type="text"
                value={this.state.descripcion}
                id="descripcion"
                onChange={(val) => {
                  this.setState({ descripcion: val.target.value });
                }}
                placeholder="Descripción" size="lg" />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.modalclose}>
              Cerrar
            </Button>
            <Button variant="primary" onClick={this.handleCloseGuardar}>
              Guardar
            </Button>
          </Modal.Footer>
        </Modal>
        <div className="col-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <h4 className="card-title">Planillas</h4>
                <p className="card-description"> Subir Marcacion </p>
                <form className="forms-sample">
                  <Form.Group>  
                  
                  <div class="custom-file mb-3">
                    <input type="file" class="custom-file-input" id="validatedCustomFile"   onChange={this.onChange} name="file" required/>
                    <label class="custom-file-label form-control"  lang="es" for="validatedCustomFile">{this.state.fileName}</label>
                  
                  </div>
                   
                  </Form.Group>
              
                  <Form.Group className="row">
                      <div className="col-4">
                        <label className="col-sm-12 col-form-label">Fecha de Inicio</label>
                        <div className="col-sm-12">
                          <DatePicker className="form-control w-100"
                            selected={this.state.startDate}
                            onChange={this.setstartDate}
                          />
                        </div>

                      </div>

                      <div className="col-4">
                        <label className="col-sm-12 col-form-label">Fecha Final</label>
                        
                          <DatePicker className="form-control w-100"
                            selected={this.state.endDate}
                            onChange={this.setEndDate}
                          />
                      

                      </div>
                  </Form.Group>
               
                  <div className="row float-right">
                    <button type="submit" className="btn btn-primary mr-2" onClick={this.onClickHandler}>Submit</button>
                    <button className="btn btn-light">Cancel</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
      
        <div className="row mt-3">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                  <Calendar
                      localizer={localizer}
                      events={events}
                      startAccessor="start"
                      endAccessor="end"
                      culture='es'
                      messages={{
                          date: 'Fecha',
                          time: 'Hora',
                          event: 'Event',
                          allDay: 'Todo el día',
                          week: 'Semana',
                          work_week: 'Work Week',
                          day: 'Día',
                          month: 'Mes',
                          previous: 'Atrás',
                          next: 'Siguiente',
                          yesterday: 'Ayer',
                          tomorrow: 'Mañana',
                          today: 'Hoy',
                          agenda: 'Agenda',
                          noEventsInRange: 'No hay eventos disponibles.',
                      }}
                      onSelectEvent={event => this.handleShow(event)}
                      style={{ height: 500 }}
                  />
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default Attedance;