import React, { Component } from 'react';
import { Link } from "react-router-dom";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import toastr from "toastr";
import SearchBar from "../../commons/SearchBar";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';



class EmployeeTable extends Component {

  constructor(props) {
    super(props);
    this.state = {
      userdata: [],
      issubmitting: true
    }
  }

  columns = [
    { dataField: 'estado', text: 'Estado', sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(row.id_estado, row.estado);
      }},
    { dataField: 'num_colaborador', text: '# de Colaborador', sort: true },
    { dataField: 'nombre', text: 'Nombre', sort: true },
    { dataField: 'apellido', text: 'Apellido', sort: true },
    {
      dataField: 'genero', text: 'Género',
      sort: true,
      formatter: (cell, row) => {
        return cell === 'M' ? 'Masculino' : 'Femenino';
      }
    },
    { dataField: 'cedula', text: 'Cédula', sort: true },
    { dataField: 'departamento', text: 'Departamento', sort: true,
      formatter: (cell, row) => {
        let result='';
        if (cell==='2'){
          result= Utils.showstatus(10, 'LIQUIDADO');
        }else if(cell==='8'){
          result= Utils.showstatus(3, 'NO APROBADO');
        }else if(cell==='7'){
          result= Utils.showstatus(7, 'POR APROBADO');
        }else if(cell==='11'){
          result= Utils.showstatus(3, 'POR FINALIZAR');
        }else{
          result=cell;
        }
        return result;
      }
    },
    {
      dataField: 'id_empleado', text: 'Detalle', sort: true,
      formatter: (cell, row) => {
        return <div>
          <Link style={{ 'marginLeft': '5px' }} to={'/employee/' + cell} className="btn btn-primary"><i className="fa fa-search"></i></Link>
          <Link style={{ 'marginLeft': '5px' }} to={{ pathname: '/employee/edit/' + cell, state: { prevPath: this.props.location.pathname } }} className="btn btn-success"><i className="fa fa-edit"></i></Link>
        </div>
      }
    }];

  tableoptions = {
    paginationPosition: 'bottom'
  };

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get('employee/inactive', null);
      this.setState({ userdata: mydata.data, issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      console.log(e);
      toastr.error('Los datos no pudieron ser consultados.');
    }
  }

  delete(deleteid) {
    confirmAlert({
      title: 'Eliminar',
      message: '¿Seguro desea eliminar?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              await RequestService.delete('employee/' + deleteid, null);
              toastr.success('Empleado eliminado');
              await this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser eliminados.');
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }

  render() {
    const selectRow = {
      mode: 'checkbox',
      bgColor: 'pink',
      className: 'my-selection-custom'
    };

    return (
        <div>

          <div className="page-header">
            <h3 className="page-title">Lista de Colaboradores Inactivos</h3>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link
                      to="/employee/"
                      role="button">Recursos Humanos
                  </Link>
                </li>
                <li className="breadcrumb-item active" aria-current="page">Colaboradores</li>
              </ol>
            </nav>
          </div>

          <div className="row">
            {Utils.loading(this.state.issubmitting)}

            <div className="col-lg-12 grid-margin stretch-card">

              <div className="card">

                <div className="card-body">

                  <ToolkitProvider
                      keyField="id_departamento"
                      data={this.state.userdata}
                      columns={this.columns}
                      search
                      loading={true}
                  >
                    {
                      props => (
                          <div className={"row"}>
                            <div className="col-lg-8">
                              <Link to={"/employee/RegisterForm/new"} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar </Link>
                            </div>
                            <div className="col-lg-4">
                              <SearchBar {...props.searchProps} className="form-control" />
                            </div>
                            <hr />
                            <BootstrapTable
                                noDataIndication={"No se encontraron registros para mostrar."}
                                pagination={paginationFactory({ hideSizePerPage: true, pageListRenderer: false })}
                                {...props.baseProps}
                            />
                          </div>
                      )
                    }
                  </ToolkitProvider>

                </div>
              </div>
            </div>
          </div>
        </div>
    )
  }
}

export default EmployeeTable;
