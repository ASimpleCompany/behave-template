import React from "react";
import toastr from "toastr";
import RequestService from "./RequestService";
import Spinner from "../app/shared/Spinner";
import moment from "moment";


class Utils {
  legaldiscounts = [2, 4, 13, 8, 9,12,15];

  logerrors(e) {
    let rs = {};
    if (typeof e.response !== "undefined") {
      if (typeof e.response.data.message !== "undefined") {
        toastr.error(e.response.data.message);
      }
      if (typeof e.response.data.errors !== "undefined") {
        e.response.data.errors.forEach((element) => {
          rs[element.param] = "has-error";
        });
        toastr.error("No se pudo realizar la acción, favor valide la información.");
      } else {
        toastr.error("Favor intente más tarde.");
      }
    } else {
      toastr.error("No se pudo actualizar, favor intente más tarde.");
    }
    return rs;
  }

  improveDate(inDate){

    return inDate!==null && inDate!=='00-00-0000' ? new Date(moment(inDate, "DD-MM-YYYY")): '';
  }

  loaderrors(statedata, name) {
    let rs = "";
    if (typeof statedata !== "undefined") {
      if (typeof statedata[name] !== "undefined") {
        rs = "has-error";
      }
    }
    return rs;
  }

  showstatus(id, desc) {
    let classestado = "badge-warning";
    if (id === 6 ||id===1) {
      classestado = "badge-success";
    } else if (id === 8 || id === 10) {
      classestado = "badge-danger";
    } else if (id === 9 || id === 11||id === 0||id === 7) {
      classestado = "badge-warning";
    }
    return <label className={"badge " + classestado}>{desc}</label>;
  }

  loading(state) {
    if (state) {
      let style = {
        position: "absolute",
        width: "80%",
        height: "80vh",
        backgroundColor: "rgba(255,255,255,0.6)",
        zIndex: "10",
      };
      return (
        <div style={style}>
          <Spinner />
        </div>
      );
    } else {
      return null;
    }
  }

  downloadfiles(id) {
    window.open(RequestService.url + "detailpayroll/report/" + id);
  }

  downloadallfiles(id) {
    window.open(RequestService.url + "detailpayroll/reportall/" + id);
  }

  downloadexcelfiles(id) {
    window.open(RequestService.url + "detailpayroll/reportexcel/" + id);
  }

  downloadecimofiles(id) {
    window.open(RequestService.url + "detailpayroll/reporttenth/" + id);
  }

  downloadpayroll(id) {
    window.open(RequestService.url + "detailpayroll/reportpayrol/" + id);
  }

  downloadpayrollvacation(id) {
    window.open(RequestService.url + "detailpayroll/reportvaction/" + id);
  }





}

export default new Utils();
