import React, { Component } from "react";
import { Form } from "react-bootstrap";
import DatePicker from "react-datepicker";
import { Link } from 'react-router-dom';
import Utils from "../../../services/Utils"
import RequestService from '../../../services/RequestService';
import toastr from "toastr";
import moment from "moment";

export class RegisterForm extends Component {

  constructor(props) {
    super(props);
    this.state = {
      num_colaborador: '',
      nombre: '',
      apellido: '',
      genero: 'M',
      cedula: '',
      seguro_social: '',
      correo: '',
      estado: 1,
      id_departamento: 0,
      id_ocupacion: 0,
      id_tipocontrato: 8,
      id_horario: 0,
      fecha_nacimiento: new Date(),
      fecha_inicio_labores: new Date(),
      fecha_fin_labores: new Date(),
      telefono: '',
      apellido_casada: '',
      departmentdata: [],
      horarios: [],
      ocupationdata: [],
      issubmitting: false,
    }
    this.createemployee = this.createemployee.bind(this);
    this.updatesalariohora=this.updatesalariohora.bind(this);
  }


  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let mydepartment = await RequestService.get('department/', null);
      let myocupacion = await RequestService.get('ocupation/', null);
      let horarios = await RequestService.get('schedule/list/', null);
      this.setState({
        id_departamento: mydepartment.data[0].id_departamento,
        id_ocupacion: myocupacion.data[0].id_ocupacion, id_horario: horarios.data[0].id_horario
      });
      this.setState({
        departmentdata: mydepartment.data, ocupationdata: myocupacion.data,
        horarios: horarios.data, issubmitting: false
      });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async createemployee(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();

        data.append('num_colaborador', this.state.num_colaborador);
        data.append('nombre', this.state.nombre);
        data.append('apellido', this.state.apellido);
        data.append('genero', this.state.genero);
        data.append('cedula', this.state.cedula);
        data.append('seguro_social', this.state.seguro_social);
        data.append('correo', this.state.correo);
        data.append('estado', this.state.estado);
        data.append('ocupacion', parseInt(this.state.id_ocupacion));
        data.append('departamento', parseInt(this.state.id_departamento));
        data.append('telefono', this.state.telefono);
        data.append('apellido_casada', this.state.apellido_casada);
        data.append('fecha_nacimiento', moment(this.state.fecha_nacimiento).format("YYYY-MM-DD"));
        data.append('fecha_inicio_labores', moment(this.state.fecha_inicio_labores).format("YYYY-MM-DD"));
        data.append('fecha_fin_labores', moment(this.state.fecha_fin_labores).format("YYYY-MM-DD"));
        data.append('id_tipocontrato', this.state.id_tipocontrato);
        data.append('id_horario', this.state.id_horario);
        data.append('monto_mensual', this.state.monto_mensual);
        data.append('monto_quincenal', this.state.monto_quincenal);
        data.append('monto_hora', this.state.monto_hora);

        await RequestService.post('employee/complete', data);
        toastr.success('Empleado Creado');
        this.setState({ issubmitting: false });
        this.props.history.push("/employee/table");
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }

  listadepartment() {
    let data = this.state.departmentdata.map((value, index) => {
      return <option value={value.id_departamento}>{value.descripcion}</option>
    });
    return data;
  }

  listhorarios() {
    let data = this.state.horarios.map((value, index) => {
      return <option value={value.id_horario}>{value.descripcion}</option>
    });
    return data;
  }

  listocupation() {
    let data = this.state.ocupationdata.map((value, index) => {
      if (this.state.id_departamento == value.id_departamento) {
        return <option value={value.id_ocupacion}>{value.descripcion}</option>
      }
      return null;
    });
    data.unshift(<option value={0}>--------</option>);
    return data;
  }


  
  updatesalariohora(){
    try{
      let montohora = (this.state.monto_mensual/4.3333)/this.state.hora_semana;
      let montoquin = this.state.monto_mensual/2;
      this.setState({monto_hora:montohora.toFixed(5), monto_quincenal:montoquin});
    }catch(e){
      this.setState({monto_hora:0,monto_quincenal:0});
    }
  }

  handleChange = (date, type) => {
    console.log(`this is da current date ${date}`);
    if (type === "inicio") {
      this.setState({
        startDate: date,
      });
    } else {
      this.setState({
        endDate: date,
      });
    }
  };
  render() {
    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Nuevo Colaborador</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Agregar</li>
            </ol>
          </nav>
        </div>
        <form className="forms-sample">
          {Utils.loading(this.state.issubmitting)}
          <div className=" grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="mb-5">
                  <h1 className="page-title"><strong>Información General</strong></h1>
                </div>
                <div className="row">
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="num_colaborador">Número de Colaborador:</label>
                      <Form.Control type="Number"
                        value={this.state.num_colaborador}
                        className={Utils.loaderrors(this.state.errors, 'num_colaborador')}
                        id="num_colaborador"
                        onChange={(val) => {
                          this.setState({ num_colaborador: val.target.value });
                        }}
                        placeholder="00000" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="nombre">Nombre:</label>
                      <Form.Control type="text"
                        value={this.state.nombre}
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'nombre')}
                        onChange={(val) => {
                          this.setState({ nombre: val.target.value });
                        }}
                        id="nombre" placeholder="Nombre" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="apellido">Apellido:</label>
                      <Form.Control type="text"
                        value={this.state.apellido}
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'apellido')}
                        onChange={(val) => {
                          this.setState({ apellido: val.target.value });
                        }}
                        id="apellido" placeholder="Apellido" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="apellido_casada">Apellido de Casada:</label>
                      <Form.Control type="text"
                        value={this.state.apellido_casada}
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'apellido_casada')}
                        onChange={(val) => {
                          this.setState({ apellido_casada: val.target.value });
                        }}
                        id="apellido_casada" placeholder="Apellido de Casada" size="lg" />
                    </Form.Group>
                  </div>
                  {/* division */}

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="genero">Genero:</label>
                      <select
                        value={this.state.genero}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'genero')}
                        onChange={(val) => {
                          this.setState({ genero: val.target.value });
                        }}
                        size="lg"
                        id="genero">
                        <option value={'M'}>Masculino</option>
                        <option value={'F'}>Femenino</option>
                      </select>
                    </Form.Group>
                  </div>

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="fecha_nacimiento">Fecha de Nacimiento:</label>
                      <br/>
                      <DatePicker
                          dateFormat="dd/MM/yyyy"
                          selected={this.state.fecha_nacimiento}
                          onChange={(date) => {
                            this.setState({ fecha_nacimiento: date });
                          }}
                          className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_nacimiento')}
                          size="lg"
                      />

                    </Form.Group>
                  </div>

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="cedula">Cédula:</label>
                      <Form.Control type="text"
                        value={this.state.cedula}
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'cedula')}
                        onChange={(val) => {
                          this.setState({ cedula: val.target.value });
                        }}
                        id="cedula" placeholder="Cédula" size="lg" />
                    </Form.Group>
                  </div>

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="seguro_social">Seguro Social:</label>
                      <Form.Control type="text"
                        value={this.state.seguro_social}
                        className={"form-control "+ Utils.loaderrors(this.state.errors, 'seguro_social')}
                        onChange={(val) => {
                          this.setState({ seguro_social: val.target.value });
                        }}
                        id="seguro_social" placeholder="Seguro Social" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="estado">Estado:</label>
                      <select
                        value={this.state.estado}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'estado_id')}
                        onChange={(val) => { this.setState({ estado: val.target.value }); }}
                        size="lg"
                        id="estado">
                        <option value={1}>Activo</option>
                        <option value={2}>Inactivo</option>
                        <option value={13}>Suspendido(a)</option>
                      </select>
                    </Form.Group>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className=" grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="mb-5">
                  <h1 className="page-title"><strong>Información de Contacto</strong></h1>
                </div>
                <div className="row">
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="telefono">Teléfono:</label>
                      <Form.Control type="text"
                        value={this.state.telefono}
                        className={Utils.loaderrors(this.state.errors, 'telefono')}
                        onChange={(val) => {
                          this.setState({ telefono: val.target.value });
                        }}
                        id="telefono" placeholder="Telefono" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="correo">Correo:</label>
                      <Form.Control type="email"
                        value={this.state.correo}
                        className={Utils.loaderrors(this.state.errors, 'correo')}
                        onChange={(val) => {
                          this.setState({ correo: val.target.value });
                        }}
                        id="correo" placeholder="Correo" size="lg" />
                    </Form.Group>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className=" grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="mb-5">
                  <h1 className="page-title"><strong>Detalle de Contrato</strong></h1>
                </div>
                <div className="row">
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="id_tipocontrato">Tipo de contrato:</label>
                      <select
                        value={this.state.id_tipocontrato}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_tipocontrato')}
                        onChange={(val) => {
                          this.setState({ id_tipocontrato: val.target.value });
                        }}
                        size="lg"
                        id="id_tipocontrato">
                        <option value={8}>Indefinido</option>
                        <option value={9}>Temporal</option>
                      </select>
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="fecha_inicio_labores">Fecha de Inicio:</label>
                      <br/>
                      <DatePicker
                          dateFormat="dd-MM-yyyy"
                          selected={this.state.fecha_inicio_labores}
                          //disabled={this.validacionmostrar()}
                          onChange={(date) => {
                            this.setState({ fecha_inicio_labores: date });
                          }}
                          className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_inicio_labores')}
                          size="lg"
                      />
                    </Form.Group>
                  </div>
                  {this.state.id_tipocontrato == 9 ? <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="fecha_fin_labores">Fecha de Finaliza:</label>
                      <br/>
                      <DatePicker
                          dateFormat="dd/MM/yyyy"
                          //disabled={this.validacionmostrar()}
                          min ={this.state.fecha_inicio_labores}
                          selected={this.state.fecha_fin_labores}
                          onChange={(date) => {
                            this.setState({ fecha_fin_labores: date });
                          }}
                          className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_fin_labores')}
                          size="lg"
                      />
                    </Form.Group>
                  </div> : null}

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="departamento">Departamento:</label>
                      <select
                        value={this.state.id_departamento}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_departamento')}
                        onChange={(val) => {
                          this.setState({ id_departamento: val.target.value });
                        }}
                        size="lg"
                        id="departamento">
                        {this.listadepartment()}
                      </select>
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin">
                    <Form.Group>
                      <label htmlFor="id_ocupacion">Ocupación:</label>
                      <select
                        value={this.state.id_ocupacion}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_ocupacion')}
                        onChange={(val) => {
                          console.log(val.target.value);
                          this.setState({ id_ocupacion: val.target.value });
                        }}
                        size="lg"
                        id="ocupacion">
                        {this.listocupation()}
                      </select>
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin">
                    <Form.Group>
                      <label htmlFor="id_horario">Horario:</label>
                      <select
                        value={this.state.id_horario}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_horario')}
                        onChange={(val) => {
                          console.log(val.target.value);
                          this.setState({ id_horario: val.target.value });
                        }}
                        size="lg"
                        id="id_horario">
                        {this.listhorarios()}
                      </select>
                    </Form.Group>
                  </div>
                  
                  <div className="col-4 grid-margin">
                    <Form.Group>
                        <label htmlFor="hora_semana">Horas Por Semana:</label>
                        <Form.Control type="text"
                        value={this.state.hora_semana}
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'hora_semana')}
                        onChange={async (val) => {
                          await this.setState({ hora_semana: val.target.value });
                          this.updatesalariohora();
                        }}
                        id="hora_semana" placeholder="hora_semana" size="lg" />
                    </Form.Group>
                  </div>


                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="monto_mensual">Salario Mensual:</label>
                      <Form.Control type="number"
                        value={this.state.monto_mensual}
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'monto_mensual')}
                        onChange={async (val) => {
                          await this.setState({ monto_mensual: val.target.value });
                          this.updatesalariohora();
                        }}
                        id="monto_mensual" placeholder="0000.00" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="monto_quincenal">Salario Quincenal:</label>
                      <Form.Control type="number"
                        value={this.state.monto_quincenal}
                        //disabled
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'monto_quincenal')}
                        onChange={(val) => {
                          this.setState({ monto_quincenal: val.target.value });
                        }}
                        id="monto_quincenal" placeholder="0000.00" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="monto_hora">Salario por Hora:</label>
                      <Form.Control type="number"
                        value={this.state.monto_hora}
                        //disabled
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'monto_hora')}
                        onChange={(val) => {
                          this.setState({ monto_hora: val.target.value });
                        }}
                        id="monto_hora" placeholder="0000.00" size="lg" />
                    </Form.Group>
                  </div>
                </div>
              </div>
            </div>
          </div>




          <button type="button"
            className="btn btn-success btn-lg"
            style={{ margin: '5px' }}
            onClick={this.createemployee}
          >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button>
          <Link to={'/employee/table'} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
        </form>
        {/* LO QUE IMPORTA ES LO QUE ESTA ARRIBA DE ESTE COMENTARIO, LO DE MAS ESTA SOLO PARA GUIA */}

        {/* FIN */}
      </div>
    );
  }
}

export default RegisterForm;
