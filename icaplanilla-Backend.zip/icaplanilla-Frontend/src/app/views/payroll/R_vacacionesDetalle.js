import React, { Component } from 'react';
import { Button, Form, Modal } from 'react-bootstrap';
import { Link } from "react-router-dom";
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import Cookies from 'universal-cookie';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import { confirmAlert } from "react-confirm-alert";

const cookies = new Cookies();

const SearchBar = (props) => {
  let input;
  return (
      <div>
        <Form.Group>
          <Form.Control
              type="text"
              ref={(n) => (input = n)}
              placeholder="Buscar"
              size="lg"
              onChange={() => {
                props.onSearch(input.value);
              }}
          />
        </Form.Group>
      </div>
  );
};

class R_VacacionesDetalle extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ids:[9,18,27],
      planilladata: [],
      listaempleado: [],
      carga_marcacion: true,
      issubmitting: true,

      show:false,
      showstudent:false,
      showdetail:false,
      codigoplanilla:0,
      dr:[],
      cr:[]
    };
    this.modalclose = this.modalclose.bind(this);
    this.getdataplanilla = this.getdataplanilla.bind(this);
    this.modalclosedetail = this.modalclosedetail.bind(this);
    this.handleShowdetail = this.handleShowdetail.bind(this);
    this.aproveContract = this.aproveContract.bind(this);
    this.noaproveContract = this.noaproveContract.bind(this);

    this.add = this.add.bind(this);
    this.delete = this.delete.bind(this);
  }

  columnscrdr = [
    {
      dataField: "descripcion",
      text: "Descripcion",
      sort: true,
      formatter: (cell, row) => { return <div>{cell}<br /><small>{row.descuento_directo}</small></div>; },
      footer: 'Totales',
    },
    {
      dataField: "monto",
      text: "Monto",
      sort: true,
      align: 'right',
      formatter: (cell, row) => { return parseFloat(cell).toFixed(2); },
      footerAlign: (column, colIndex) => 'right',
      footer: columnData => columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
    },
  ]

  columns = [
    {
      dataField: "nombre",
      text: "Colaborador",
      headerClasses: 'headertableclass',
      sort: true,
      footer: "",
      headerStyle: (colum, colIndex) => {return { width: '200px', textAlign: 'center' };}
    },
    {
      dataField: "departamento",
      text: "Departamento",
      sort: true,
      footer: "Totales",
      headerClasses: 'headertableclass',
      headerStyle: (colum, colIndex) => {return { width: '110px', textAlign: 'center' };}
    },
    {
      dataField: "salario_quincenal_neto",
      text: "Esta \n Quincena",
      align: "right",
      sort: true,
      headerClasses: 'headertableclass',
      footerClasses: 'footertableclass',
      style: (cell, row, rowIndex, colIndex) => {return { backgroundColor: "rgb(245 255 245)" };},
      footer: (columnData) =>columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
      footerAlign: (column, colIndex) => "right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);},
    },
    {
      dataField: "ausentismo_tardanza",
      text: "Ausencias",
      align: "right",
      sort: true,
      headerClasses: 'headertableclass',
      footerClasses: 'footertableclass',
      style: (cell, row, rowIndex, colIndex) => {return { backgroundColor: "#fff7e6" };},
      footer: (columnData) =>columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
      footerAlign: (column, colIndex) => "right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);},
    },
    {
      dataField: "deduccion_seg_social",
      text: "Seg. Social",
      align: "right",
      sort: true,
      headerClasses: 'headertableclass',
      footerClasses: 'footertableclass',
      style: (cell, row, rowIndex, colIndex) => {return { backgroundColor: "rgb(255 245 245)" };},
      footer: (columnData) =>columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
      footerAlign: (column, colIndex) => "right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);}
    },
    {
      dataField: "deduccion_seg_educativo",
      text: "Seg. Educativo",
      align: "right",
      sort: true,
      headerClasses: 'headertableclass',
      footerClasses: 'footertableclass',
      style: (cell, row, rowIndex, colIndex) => {return { backgroundColor: "rgb(255 245 245)" };},
      footer: (columnData) =>columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
      footerAlign: (column, colIndex) => "right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);},
    },
    {
      dataField: "total_descuentos",
      text: "Total Deduc.",
      align: "right",
      headerClasses: 'headertableclass',
      footerClasses: 'footertableclass',
      style: (cell, row, rowIndex, colIndex) => {return { backgroundColor: "rgb(244 244 244)" };},
      footer: (columnData) =>columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
      footerAlign: (column, colIndex) => "right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);},
      sort: true,
    },
    {
      dataField: "otros_descuentos",
      text: "Otros Desc.",
      align: "right",
      headerClasses: 'headertableclass',
      footerClasses: 'footertableclass',
      style: (cell, row, rowIndex, colIndex) => {return { backgroundColor: "rgb(255 245 245)" };},
      footer: (columnData) =>columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
      footerAlign: (column, colIndex) => "right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);},
      sort: true,
    },

    {
      dataField: "neto_a_pagar",
      text: "Total a Pagar",
      align: "right",
      headerClasses: 'headertableclass',
      footerClasses: 'footertableclass',
      style: (cell, row, rowIndex, colIndex) => {return { backgroundColor: "rgb(244 244 244)" };},
      footer: (columnData) =>columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
      footerAlign: (column, colIndex) => "right",
      formatter: (cell, row) => {return parseFloat(cell).toFixed(2);},
      sort: true,
    },
    {
      dataField: "id_planilla",
      text: "Detalle",
      sort: true,
      footer: 'Detalle',
      formatter: (cell, row) => {
        return (
            <div>
              <button type="button" onClick={() => this.getdataplanilla(cell)} className="btn btn-primary p-1 m-1"><i className="fa fa-plus" /></button>
              {this.state.id_estado === 6 ? <button type="button" onClick={() => Utils.downloadfiles(cell)} className="btn btn-warning p-1 m-1"><i className="fa fa-print" /></button> : null}
            </div>
        );
      },
    },
  ];

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let id_nomina = this.props.match.params.id;
      let nomina = await RequestService.get('payroll/nomina/' + id_nomina, null);
      let planilla = await RequestService.get('payroll/detail/' + id_nomina, null);

      if (this.state.listaempleado.length <= 0) {
        let employeelist = await RequestService.get('payroll/employeelist/' + id_nomina, null);
        this.setState({ listaempleado: employeelist.data });
      }
      this.setState(nomina.data[0]);
      this.setState({ issubmitting: false, planilladata: planilla.data });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async getdataplanilla(id) {
    try {
      this.setState({ issubmitting: true });
      let planilla = await RequestService.get('payroll/detailpayroll/' + id, null);
      let datosdetalle = await RequestService.get('payroll/employee/' + id, null);
      let dr = [], cr = [];
      planilla.data.forEach(element => {
        if (element.crdr === 'CR') {
          cr.push(element);
        } else {
          dr.push(element);
        }
      });
      this.setState(datosdetalle.data[0]);
      this.setState({ detalle_planilla: planilla.data, debitos: dr, creditos: cr });
      this.setState({ issubmitting: false, show: true });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async aproveContract() {
    confirmAlert({
      title: 'Actualizar',
      message: '¿Seguro desea aprobar la planilla?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let data = new FormData();
              data.append('accion', true);
              let rs = await RequestService.post('payroll/nomina/aprove/' + this.state.id_nomina, data);
              console.log(rs);
              toastr.success('Actualizacion realizada');
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser actualizados.', 'Intente de nuevo');
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }

  async noaproveContract() {
    confirmAlert({
      title: 'Actualizar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let data = new FormData();
              data.append('accion', false);
              let rs = await RequestService.post('payroll/nomina/aprove/' + this.state.id_nomina, data);
              toastr.success('Actualizacion realizada');
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser actualizados.', 'Intente de nuevo');
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }


  async add() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append("id_nomina", this.state.id_nomina);
      form.append("id_empleado", this.state.id_empleado);
      await RequestService.post("payroll/addemployee/", form);
      toastr.success("Comentario Guardado");
      this.getdata();
    } catch (e) {
      console.log(e);
      this.setState({ issubmitting: false });
      toastr.error(
          "Los datos no pudieron ser actualizados.",
          "Intente de nuevo"
      );
    }
  }

  async delete(id) {
    confirmAlert({
      title: 'Eliminar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let form = new FormData();
              await RequestService.delete("payroll/detail/" + id, form);
              toastr.success("Eliminado");
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                  "Los datos no pudieron ser consultados.",
                  "Intente de nuevo"
              );
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }


  lista() {
    let data = this.state.listaempleado.map((value, index) => {
      return <option value={value.id_empleado}>{value.nombre}</option>
    });
    data.unshift(<option value={0}>--------</option>);
    return data;
  }

  modalclose() {
    this.setState({ show: false });
  }

  modalclosedetail() {
    this.setState({ showdetail: false });
  }

  handleShowdetail() {
    this.setState({showdetail: true});
  }




  render() {

    return (
        <div>
          <div className="page-header">
            <h1 className="page-title"> Detalle de Vacaciones</h1>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <li className="breadcrumb-item"><Link to="/payroll" role="button">Planillas</Link></li>
                <li className="breadcrumb-item"><Link to="/payroll/reports/vacaciones" role="button">Reportes de Vacaciones</Link></li>
                <li className="breadcrumb-item active" aria-current="page">Detalle</li>
              </ol>
            </nav>
          </div>
          <Modal size={'lg'} dialogClassName={'modal-custome'} show={this.state.showdetail} onHide={this.modalclosedetail}>
            <Modal.Header closeButton>
              <Modal.Title>Resumen de Planilla: <strong>${this.state.total_pagar}</strong> <br />
                <small>{this.state.nomina}<br />
                  {Utils.showstatus(this.state.id_estado, this.state.estado)}</small>
              </Modal.Title>
            </Modal.Header>
            <Modal.Body className={'row'}>
              <div className={'col-lg-10'}>
                <Form.Group>
                  <label htmlFor="descripcion">Comentario:</label>
                  <textarea name={'descripcion'}
                            rows="4"
                            disabled={this.state.id_estado !== 7}
                            className={"form-control " + Utils.loaderrors(this.state.errors, 'descripcion')}
                            value={this.state.descripcion}
                            onChange={(val) => {
                              this.setState({ descripcion: val.target.value });
                            }} />
                </Form.Group>
              </div>
              <div className={'col-lg-2'}>
                {this.state.id_estado === 7 ? <button type="button" onClick={() => {
                  this.update()
                }} className="btn btn-primary mb-2 mt-4"> Guardar </button> : null}
              </div>
              <div className={'col-lg-6'}>
                <Form.Group>
                  <label htmlFor="aprobado_por">Creado por:</label>
                  <input type="text" name="name"
                         disabled
                         className={"form-control "}
                         value={this.state.creado_por}
                  />
                </Form.Group>
              </div>
              <div className={'col-lg-6'}>
                <Form.Group>
                  <label htmlFor="aprobado_por">Aprobado por:</label>
                  <input type="text" name="name"
                         disabled
                         className={"form-control "}
                         value={this.state.aprobado_por}
                  />
                </Form.Group>
              </div>

              <div className={'col-lg-4'}>
                <Form.Group>
                  <label htmlFor="carga_marcacion">Carga marcaciones:</label>
                  <input type="text" name="carga_marcacion"
                         disabled
                         className={"form-control "}
                         value={this.state.carga_marcacion === 0 ? 'No' : 'Si'}
                  />
                </Form.Group>
              </div>
              <div className={'col-lg-4'}>
                <Form.Group>
                  <label htmlFor="carga_marcacion">Fecha inicio de marcaciones:</label>
                  <input type="text" name="marcacion_inicio"
                         disabled
                         className={"form-control "}
                         value={this.state.marcacion_inicio}
                  />
                </Form.Group>
              </div>
              <div className={'col-lg-4'}>
                <Form.Group>
                  <label htmlFor="marcacion_fin">Fecha fin de marcaciones:</label>
                  <input type="text" name="marcacion_fin"
                         disabled
                         className={"form-control "}
                         value={this.state.marcacion_fin}
                  />
                </Form.Group>
              </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={this.modalclosedetail}>
                Cerrar
              </Button>
            </Modal.Footer>
          </Modal>
          <Modal show={this.state.show} size={'lg'} dialogClassName={'modal-custome'} onHide={this.modalclose}>
            <Modal.Header closeButton>
              <Modal.Title>{this.state.typefunction} Resumen de Planilla por Colaborador:</Modal.Title>
            </Modal.Header>
            <Modal.Body className={'row'}>
              <div className={'col-lg-6'}>
                <div className="card">
                  <div className="card-body">
                    <h4>Deducciones:</h4>
                    <BootstrapTable
                        noDataIndication={"No se encontraron registros para mostrar."}
                        keyField="id_descuento_realizado"
                        data={this.state.debitos}
                        columns={this.columnscrdr}
                        search
                        loading={true}
                    />
                  </div>
                </div>
              </div>

              <div className={'col-lg-6 stretch-card'}>
                <div className="card">
                  <div className="card-body">
                    <h4>Ingresos:</h4>
                    <BootstrapTable
                        noDataIndication={"No se encontraron registros para mostrar."}
                        keyField="id_descuento_realizado"
                        data={this.state.creditos}
                        columns={this.columnscrdr}
                        search
                        loading={true}
                    />
                  </div>
                </div>
              </div>

            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={this.modalclose}>
                Cerrar
              </Button>
            </Modal.Footer>
          </Modal>




          <div className="row">
            {Utils.loading(this.state.issubmitting)}
            <div className="col-lg-12 grid-margin stretch-card">
              <div className="card">
                <div className="card-body">
                  <div className="row">
                    <div className="col-lg-12">

                    </div>
                    <div className="row">
                      <div className="col-lg-12">
                        <ToolkitProvider
                            keyField="id_departamento"
                            data={this.state.planilladata}
                            columns={this.columns}
                            search
                            loading={true}
                        >
                          {(props) => (
                              <div className={"row"}>
                                <div className="col-lg-8">
                                  <h4>{this.state.departamento}</h4>
                                  {this.state.nomina}: <button type="button" onClick={this.handleShowdetail} className="btn btn-success">Detalle</button>
                                  <button type="button" onClick={()=>this.props.history.goBack()} className="btn btn-secondary ml-2">Regresar</button>
                                </div>
                                <div className="col-lg-4">
                                  <SearchBar
                                      {...props.searchProps}
                                      className="form-control"
                                  />
                                </div>
                                <hr />
                                <BootstrapTable
                                    noDataIndication={"No se encontraron registros para mostrar."}
                                    {...props.baseProps}
                                />
                              </div>
                          )}
                        </ToolkitProvider>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    );
  }
}

export default R_VacacionesDetalle;
