const db = require('../config/db');
const { getUserId, validateAdminiostrative } = require('../helpers/utils')
const { insertlog } = require('../helpers/logactions');
const { check, validationResult } = require('express-validator');
const {inpuestosfijos}=require('./payrollFunctions')
const util = require('util');
const query = util.promisify(db.query).bind(db);


exports.tablends = (req, res, next) => {
  let sql ='SELECT tc.id_contrato, upper(concat(te.apellido ,\' \',te.apellido )) as nombre, td.descripcion as departamento, \
  DATE_FORMAT(tc.fecha_inicio_labores,\'%d-%m-%Y\') as fecha_inicio_labores, DATE_FORMAT(tfc.fecha_culmina,\'%d-%m-%Y\') as fecha_culmina,\
  ctf.descripcion as finaliza, ct.descripcion as tipocontrato, tc.id_estado as idestadocontrato, tce.descripcion as estadocontrato,\
  ifnull(tn.id_estado,0) as idestadonomina, ifnull(tce2.descripcion,\'NO CREADO\') as estadonomina\
  from tbl_contratos tc inner join ctl_tipocontrato ct on ct.id_tipocontrato = tc.id_tipocontrato\
  inner join tbl_empleados te on te.id_empleado = tc.id_empleado\
  inner join tbl_departamento td on tc.id_departamento = td.id_departamento\
  inner join tbl_finaliza_contrato tfc on tc.id_contrato = tfc.id_contrato\
  inner join ctl_tipo_finaliza ctf on ctf.id_tipo_finaliza = tfc.id_tipo_finaliza\
  inner join tbl_catalogo_estado tce on tce.id_estado = tc.id_estado\
  left join tbl_nomina tn on tfc.id_nomina = tn.id_nomina left join tbl_catalogo_estado tce2 on tn.id_estado = tce2.id_estado\
  where YEAR(tfc.fecha_culmina)= YEAR(now()) order by tfc.id_finaliza desc';
  db.query(sql, [req.params.id], function (error, results, fields) {
    if (error) {
      return res.status(401).json({ message: 'error en conexión a datos ' + error });
    }
    return res.status(200).json(results);
  });
}


exports.tablendsreport = (req, res, next) => {
  let sql ='SELECT tc.id_contrato, upper(concat(te.apellido ,\' \',te.apellido )) as nombre, td.descripcion as departamento, \
  DATE_FORMAT(tc.fecha_inicio_labores,\'%d-%m-%Y\') as fecha_inicio_labores, DATE_FORMAT(tfc.fecha_culmina,\'%d-%m-%Y\') as fecha_culmina,\
  ctf.descripcion as finaliza, ct.descripcion as tipocontrato, tc.id_estado as idestadocontrato, tce.descripcion as estadocontrato,\
  ifnull(tn.id_estado,0) as idestadonomina, ifnull(tce2.descripcion,\'NO CREADO\') as estadonomina\
  from tbl_contratos tc inner join ctl_tipocontrato ct on ct.id_tipocontrato = tc.id_tipocontrato\
  inner join tbl_empleados te on te.id_empleado = tc.id_empleado\
  inner join tbl_departamento td on tc.id_departamento = td.id_departamento\
  inner join tbl_finaliza_contrato tfc on tc.id_contrato = tfc.id_contrato\
  inner join ctl_tipo_finaliza ctf on ctf.id_tipo_finaliza = tfc.id_tipo_finaliza\
  inner join tbl_catalogo_estado tce on tce.id_estado = tc.id_estado\
  left join tbl_nomina tn on tfc.id_nomina = tn.id_nomina left join tbl_catalogo_estado tce2 on tn.id_estado = tce2.id_estado\
  where tn.id_estado in (6,10) order by tfc.id_finaliza desc';
  db.query(sql, [req.params.id], function (error, results, fields) {
    if (error) {
      return res.status(401).json({ message: 'error en conexión a datos ' + error });
    }
    return res.status(200).json(results);
  });
}


exports.detailperyeardend = async (req, res, next) => {
  let sqlanos='SELECT tc.id_contrato,tn.ano,sum(tp.salario_quincenal_neto-tp.ausentismo_tardanza) as totaldevengado from tbl_planillas tp \
  inner join tbl_contratos tc on tp.id_contrato = tc.id_contrato \
  inner join tbl_nomina tn on tp.id_nomina = tn.id_nomina \
  inner join ctl_codigoplanilla cc ON tp.id_codigoplanilla = cc.id_codigoplanilla \
  where tn.id_estado = 6 and tc.id_contrato=? GROUP by tc.id_contrato, tn.ano\
  order by  tn.ano desc';
  try{
    let anos = await query(sqlanos, [req.params.id]);
    return res.status(200).json(anos);
  }catch(e){
    return res.status(401).json({ message: 'error en conexión a datos ' + error });
  }
}


exports.detailend = async (req, res, next) => {
  let sql='SELECT tc.id_contrato, upper(concat(te.apellido ,\' \',te.apellido )) as nombre, td.descripcion as departamento,\
  DATE_FORMAT(tc.fecha_inicio_labores,\'%d-%m-%Y\') as fecha_inicio_labores, DATE_FORMAT(tfc.fecha_culmina,\'%d-%m-%Y\') as fecha_culmina,\
  ctf.descripcion as finaliza,tfc.motivo, ct.descripcion as tipocontrato, tc.id_estado as idestadocontrato, tce.descripcion as estadocontrato,\
  ifnull(tn.id_estado,0) as idestadonomina, ifnull(tce2.descripcion,\'NO CREADO\') as estadonomina  from tbl_contratos tc \
  inner join ctl_tipocontrato ct on ct.id_tipocontrato = tc.id_tipocontrato  inner join tbl_empleados te on te.id_empleado = tc.id_empleado  \
  inner join tbl_departamento td on tc.id_departamento = td.id_departamento  inner join tbl_finaliza_contrato tfc on tc.id_contrato = tfc.id_contrato  \
  inner join ctl_tipo_finaliza ctf on ctf.id_tipo_finaliza = tfc.id_tipo_finaliza  inner join tbl_catalogo_estado \
  tce on tce.id_estado = tc.id_estado  left join tbl_nomina tn on tfc.id_nomina = tn.id_nomina left join tbl_catalogo_estado tce2 on tn.id_estado = tce2.id_estado  \
  where tc.id_contrato = ? order by tfc.id_finaliza desc';
  try{
    let detail = await query(sql, [req.params.id]);
    return res.status(200).json(detail);
  }catch(e){
    return res.status(401).json({ message: 'error en conexión a datos ' + error });
  }
}


exports.createend = [
  [
    check('id_contrato').notEmpty().bail().isInt({ min: 1 }),
    check('carga_marcacion').notEmpty(),
    check('marcacion_inicio').custom((value, meta) => { return !(meta.req.body.carga_marcacion === 'true' && value === '') }),
    check('marcacion_fin').custom((value, meta) => { return !(meta.req.body.carga_marcacion === 'true' && value === '') }),
  ],
  async (req, res, next) => {

    
    const errors = validationResult(req);
    if (!errors.isEmpty()) { return res.status(422).json({ errors: errors.array() }); }

    let useid = getUserId(req);
    let sql = 'INSERT INTO tbl_nomina (id_estado, ano,id_codigoplanilla, carga_marcacion, id_departamento, marcacion_inicio, marcacion_fin,creado_por) VALUES(7,?,?,?,?,?,?,?)';

    let nomina = [req.body.ano, 55, true, req.body.id_departamento, req.body.marcacion_inicio, req.body.marcacion_fin, useid];

    if (req.body.carga_marcacion === 'false') {
      sql = 'INSERT INTO tbl_nomina (id_estado, ano,id_codigoplanilla, carga_marcacion,id_departamento,creado_por) VALUES(7,?,?,?,?,?)';
      nomina = [req.body.ano,55, false, req.body.id_departamento, useid];
    }

    let rs = [];
    try {
      rs = await query(sql, nomina);
    } catch (e) {
      return res.status(401).json({ message: 'error en conexión a datos ', error: e });
    }

    let id_nomina = rs.insertId;

    try {
      let empleados = await query('select get_employeedata(te.id_empleado,\'SALARY\') as mensual,\
      get_employeedata(te.id_empleado,\'SALARYQUIN\') as salario_quin, te.id_empleado, tc.id_contrato,te.id_empleado  from tbl_empleados te \
      inner join tbl_contratos tc on te.id_empleado = tc.id_empleado where tc.id_estado = 6 and te.id_estado = 1 and te.id_empleadoo=?', [req.body.id_empleado]);
      
      let descuentofijo = await query('select * from tbl_descuento_fijos where id_tipo_descuento in (2,4,11) and id_estado = 1');

      for (const empleado of empleados) {
        let sqldetalle = 'INSERT INTO tbl_detalle_planilla(id_nomina,id_tipo_descuento,id_empleado,id_codigoplanilla,id_planilla,monto) VALUES (?,?,?,?,?,?)';
        
        /*
        * Crea Planill para colaborador
        */
        let planilladata = [empleado.mensual, empleado.salario_quin, empleado.id_empleado, id_nomina, 55, empleado.id_contrato];
        let planilla = await query('INSERT INTO tbl_planillas(salario_mensual_pactado,salario_quincenal_neto, id_empleado, id_nomina, id_codigoplanilla,id_contrato) VALUES (?,?,?,?,?,?)', planilladata);
        let id_planilla = planilla.insertId;

        /*
        * Insertar creditos para colaborador
        */
        let datosdetalle = [id_nomina, 12, empleado.id_empleado, 55, id_planilla, empleado.salario_quin];
        await query(sqldetalle, datosdetalle);

        /*
        * Insertar todos los descuentos fijos
        */
        inpuestosfijos(55,descuentofijo,empleado,id_planilla,id_nomina);
        
        /*
        * Insertar todos los descuentos directos
        */
        let directos = await query('SELECT id_descuento_directo, montototal, monto_letra_quincenal, montoactual, montoactual-monto_letra_quincenal as last FROM tbl_descuento_directo WHERE id_empleado = ? and id_estado=6', [empleado.id_empleado]);
        sqldetalle = 'INSERT INTO tbl_detalle_planilla(id_descuento_directo,id_nomina,id_tipo_descuento,id_empleado,id_codigoplanilla,id_planilla,monto) VALUES (?,?,?,?,?,?,?)';

        for (const directo of directos) {
          let datosdetalle = [];
          if (directo.last <= 0) {
            datosdetalle = [directo.id_descuento_directo, id_nomina, 1, empleado.id_empleado, 55, id_planilla, directo.montoactual];
          } else {
            datosdetalle = [directo.id_descuento_directo, id_nomina, 1, empleado.id_empleado, 55, id_planilla, directo.monto_letra_quincenal];
          }
          await query(sqldetalle, datosdetalle);
        }
      }
    } catch (e) {
      return res.status(401).json({ message: 'error en conexión a datos ', error: e });
    }
    return res.status(200).json(rs);
  }
];




