import React, { Component } from "react";
import { Form } from "react-bootstrap";
//import { Link } from "react-router-dom";
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider from "react-bootstrap-table2-toolkit";
import "react-confirm-alert/src/react-confirm-alert.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";
// import moment from "moment";
// import { confirmAlert } from "react-confirm-alert";

const SearchBar = (props) => {
  let input;
  return (
    <div>
      <Form.Group>
        <Form.Control
          type="text"
          ref={(n) => (input = n)}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};

class Buttons extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userdata: [],
      issubmitting: true,
    };
  }

  columns = [
    {
      dataField: "descripcion",
      text: "Nombre",
      sort: true,
    },
    {
      dataField: "total_horas_diarias",
      text: "Total de Horas",
      sort: true,
    },
    {
      dataField: "id_horario",
      text: "Detalle",
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            <button
              style={{ "marginLeft": "10px" }}
              type="button"
              //onClick={() => Utils.downloadfiles(cell)}
              className="btn btn-primary btn-icon-text"
            >
              Imprimir <i className="mdi mdi-printer btn-icon-append" />
            </button>
          </div>
        );
      },
    },
  ];

  tableoptions = {
    paginationPosition: "bottom",
  };

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get("schedule/", null);
      this.setState({ userdata: mydata.data, issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      console.log(e);
      toastr.error(
        "Los datos no pudieron ser consultados.",
        "Intente de nuevo"
      );
    }
  }

  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Reporte de Planilla 03 </h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="/payroll">Planillas</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
              Reportes {'>'} Planilla 03
              </li>
            </ol>
          </nav>
        </div>

        <div className="row">
          {Utils.loading(this.state.issubmitting)}

          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id_departamento"
                  data={this.state.userdata}
                  columns={this.columns}
                  search
                  loading={true}
                >
                  {(props) => (
                    <div className={"row"}>
                      <div className="col-lg-4">
                        <SearchBar
                          {...props.searchProps}
                          className="form-control"
                        />
                      </div>
                      <hr />
                      <BootstrapTable
                        noDataIndication={
                          "No se encontraron registros para mostrar."
                        }
                        pagination={paginationFactory({
                          hideSizePerPage: true,
                          pageListRenderer: false,
                        })}
                        {...props.baseProps}
                      />
                    </div>
                  )}
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Buttons;
