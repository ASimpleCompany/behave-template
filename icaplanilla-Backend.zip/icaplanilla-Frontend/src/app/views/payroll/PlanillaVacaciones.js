import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import { Link } from "react-router-dom";
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { confirmAlert } from "react-confirm-alert";
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';


const SearchBar = (props) => {
  let input;
  return (
    <div>
      <Form.Group>
        <Form.Control
          type="text"
          ref={(n) => (input = n)}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};

class Planilla extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nominadata: [],
      listapayroll: [],
      departmentdata: [],
      listaano: [],
      issubmitting: true,
      show: false,
      ano: 0,
      id_departamento: 0,
      id_codigoplanilla: 0,
      carga_marcacion: false,
      marcacion_inicio: '',
      marcacion_fin: ''
    };
    this.modalclose = this.modalclose.bind(this);
    this.handleShow = this.handleShow.bind(this);
    this.adddata = this.adddata.bind(this);
    this.delete = this.delete.bind(this);

  }

  columns = [
    {
      dataField: 'estado_nomina', text: 'Estado Vacación', sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(row.id_estado, row.estado);
      },
      headerStyle: (colum, colIndex) => {return { width: '130px', textAlign: 'center' }}

    },
    {
      dataField: 'estado_nomina', text: 'Estado Pago', sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(row.id_estado_nomina, row.estado_nomina);
      }
    },
    {dataField: "nombre",text: "Colaborador",sort: true, headerStyle: (colum, colIndex) => {return { width: '200px', textAlign: 'center' };}},
    {dataField: "cantidaddias",text: "Cant. de Días",sort: true},
    {dataField: "fecha_inicio",text: "Inicio",sort: true},
    {dataField: "fecha_retorno",text: "Retorno",sort: true},
    {dataField: 'monto_nomina', text: 'Monto', align: 'right', sort: true, formatter: (cell, row) => { return parseFloat(cell).toFixed(2); } },
    {dataField: 'total_pagar', text: 'Total a Pagar', align: 'right', sort: true, formatter: (cell, row) => { return parseFloat(cell).toFixed(2); } },
    {
      dataField: "id_vacaciones",
      text: "Detalle",
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            {row.id_estado_nomina === 7 || row.id_estado_nomina ===6?
            <Link
                style={{ "marginLeft": "10px" }}
                to={"/payroll/third/vacaciones/" + row.id_nomina}
                className="btn btn-success p-1 m-1"
            >
              <i className="fa fa-edit" />
            </Link>:null}

            {row.id_estado_nomina === 7 ? <button
              style={{ "marginLeft": "10px" }}
              onClick={() => this.delete(row.id_nomina)}
              className="btn btn-danger p-1 m-1"
            >
              <i className="fa fa-eraser" />
            </button> : null}

            {row.id_estado_nomina === 0 && row.id_estado===6 ? <button
                style={{ "marginLeft": "10px" }}
                onClick={() => this.adddata(cell)}
                className="btn btn-success p-1 m-1"
            >
              <i className="fa fa-mail-forward" />
            </button> : null}
          </div>
        );
      },
    },
  ];

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let nominadata = await RequestService.get('payroll/vacations', null);
      this.setState({ nominadata: nominadata.data });
      this.setState({ issubmitting: false});
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async adddata(id) {
    try {
      this.setState({ issubmitting: true, show: false });
      let form = new FormData();
      form.append("id_vacaciones", id);
      let rs= await RequestService.post("payroll/vacations", form);

      toastr.success("Planilla Creada");
      this.getdata();
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
      toastr.error(
        "Valide la información",
        "Intente de nuevo"
      );
    }
  }

  async delete(id) {
    confirmAlert({
      title: 'Eliminar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              await RequestService.delete("payroll/nomina/" + id,null);
              toastr.success("Eliminado");
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                "Los datos no pudieron ser eliminados.",
                "Intente de nuevo"
              );
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }

  listapayroll() {
    return this.state.listapayroll.map((value, index) => {
      if (parseInt(this.state.ano) === parseInt(value.ano)
        && parseInt(value.id_departamento) === parseInt(this.state.id_departamento)) {
        return <option value={value.id_codigoplanilla}>{value.descripcion}</option>
      }
    });
  }



  modalclose() {
    this.setState({ show: false });
  }

  handleShow() {
    this.setState({ show: true });
  }


  render() {

    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Vacaciones</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
            <li className="breadcrumb-item">
                <Link to="/payroll" role="button">Planillas</Link></li>
              <li className="breadcrumb-item active" aria-current="page">Gestión de Planillas {'>'} Vacaciones</li>
            </ol>
          </nav>
        </div>

        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id_vacaciones"
                  data={this.state.nominadata}
                  columns={this.columns}
                  search
                  loading={true}
                >
                  {(props) => (
                    <div className={"row"}>
                      <div className="col-lg-8">

                      </div>
                      <div className="col-lg-4">
                        <SearchBar
                          {...props.searchProps}
                          className="form-control"
                        />
                      </div>
                      <hr />
                      <BootstrapTable
                        noDataIndication={"No se encontraron registros para mostrar."}
                        pagination={paginationFactory({
                          hideSizePerPage: true,
                          pageListRenderer: false,
                        })}
                        {...props.baseProps}
                      />
                    </div>
                  )}
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Planilla;
