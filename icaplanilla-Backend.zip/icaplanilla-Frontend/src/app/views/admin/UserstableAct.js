import React, { Component } from 'react';
import { Form, Modal, Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
import RequestService from '../../../services/RequestService';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { Search, CSVExport } from 'react-bootstrap-table2-toolkit';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';

const SearchBar = (props) => {
  let input;
  const handleClick = () => {
    props.onSearch(input.value);
  };
  return (
    <div>
      <Form.Group>
        <Form.Control type="text" ref={n => input = n}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};

const columns = [{
  dataField: 'tabla',
  text: 'Datos en:',
  sort: true
}, {
  dataField: 'accion',
  text: 'Acción Realizada',
  sort: true
}, {
  dataField: 'usuario',
  text: 'Nombre de Usuario',
  sort: true
}, {
  dataField: 'fecha_creacion',
  text: 'Fecha',
  sort: true
}
];

export class UserTableAct extends Component {

  constructor(props) {
    super(props);
    this.state = {
      userdata: []
    }
  }

  tableoptions = {
    paginationPosition: 'bottom',
  }

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    let mydata = await RequestService.get('user/activities/get', null);
    console.log(mydata);
    this.setState({ userdata: mydata.data });
  }


  render() {
    const selectRow = {
      mode: 'checkbox',
      bgColor: 'pink',
      className: 'my-selection-custom'
    };

    return (
      <div>
        <div className="page-header">
          <h3 className="page-title"> Lista de Actividades</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/admin"
                  role="button">Administración
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Actividades</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id"
                  pagination={paginationFactory()}
                  data={this.state.userdata}
                  columns={columns}
                  search
                  loading={true}
                >
                  {
                    props => (
                      <div className={"row"}>
                        <div className="col-lg-4">
                          <SearchBar {...props.searchProps} className="form-control" />
                        </div>
                        <hr />
                        <BootstrapTable
                          noDataIndication={"No se encontraron registros para mostrar."}
                          pagination={paginationFactory({ hideSizePerPage: true })}
                          {...props.baseProps}
                        />
                      </div>
                    )
                  }
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default UserTableAct;
