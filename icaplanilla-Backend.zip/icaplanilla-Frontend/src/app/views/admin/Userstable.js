import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import { Link } from "react-router-dom";
import toastr from "toastr";
import Utils from "../../../services/Utils"
import RequestService from '../../../services/RequestService';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import overlayFactory from 'react-bootstrap-table2-overlay';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';

const SearchBar = (props) => {
  let input;
  const handleClick = () => {
    props.onSearch(input.value);
  };
  return (
    <div>
      <Form.Group>
        <Form.Control type="text" ref={n => input = n}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};

export class BasicTable extends Component {

  constructor(props) {
    super(props);
    this.state = {
      userdata: [],
      issubmitting: false
    }
  }

  tableoptions = {
    paginationPosition: 'bottom',
  }

  columns = [{ dataField: 'nombre', text: 'Nombre', sort: true },
  { dataField: 'apellido', text: 'Apellido', sort: true },
  { dataField: 'nombre_usuario', text: 'Nombre de Usuario', sort: true },
  {
    dataField: 'id_estado', text: 'Estado', sort: true,
    formatter: (cell, row) => {
      let rs = <label class="badge badge-danger">Inactivo</label>;
      if (cell === 1) {
        rs = <label class="badge badge-success">Activo</label>;
      }
      return rs;
    }
  },
  {
    dataField: 'id', text: 'Detalle', sort: true,
    formatter: (cell, row) => {
      return <div>
        <Link type="button" to={'/admin/user/' + cell} id={cell} className="btn btn-success"><i className="fa fa-edit"></i></Link>
        <button style={{ 'marginLeft': '10px' }} onClick={() => this.delete(cell)} className="btn btn-danger"><i className="fa fa-eraser"></i></button>
      </div>
    }
  }
  ];

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get('user/', null);
      this.setState({ userdata: mydata.data, issubmitting: false });
    } catch (e) {
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
      this.setState({ issubmitting: false });
    }
  }

  delete(deleteid) {
    confirmAlert({
      title: 'Eliminar',
      message: '¿Seguro desea eliminar?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              await RequestService.delete('user/' + deleteid, null);
              await this.getdata();
              toastr.success('Usuario eliminado');
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser eliminados.', 'Intente de nuevo');
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });

  }

  render() {
    const selectRow = {
      mode: 'checkbox',
      bgColor: 'pink',
      className: 'my-selection-custom'
    };

    return (
      <div>
        <div className="page-header">
          <h3 className="page-title"> Lista de Usuarios </h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/admin"
                  role="button">Administración
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Usuarios</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id"
                  data={this.state.userdata}
                  columns={this.columns}
                  search
                  loading={true}
                  overlay={overlayFactory({ spinner: true, styles: { overlay: (base) => ({ ...base, background: 'rgba(255, 0, 0, 0.5)' }) } })}
                >
                  {
                    props => (
                      <div className={"row"}>
                        <div className="col-lg-8">
                          <Link to={'/admin/user/new'} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar </Link>
                        </div>
                        <div className="col-lg-4">
                          <SearchBar {...props.searchProps} className="form-control" />
                        </div>
                        <hr />
                        <BootstrapTable
                          noDataIndication={"No se encontraron registros para mostrar."}
                          pagination={paginationFactory({ hideSizePerPage: true })}
                          {...props.baseProps}
                        />
                      </div>
                    )
                  }
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default BasicTable
