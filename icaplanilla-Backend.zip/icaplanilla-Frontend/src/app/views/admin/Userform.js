import React, { Component, useState } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';

export class Userform extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id: 0,
      password: '',
      nombre: '',
      nombre_usuario: '',
      apellido: '',
      estado: 1,
      rol: 1,
      issubmitting: false
    }
    this.updatepass = this.updatepass.bind(this);
    this.updateuser = this.updateuser.bind(this);
  }

  componentDidMount() {
    this.setState({ id: this.props.match.params.id });
    this.getdata();
  }


  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let id = this.props.match.params.id;
      let mydata = await RequestService.get('user/' + id, null);
      let { nombre, apellido, nombre_usuario, id_estado, id_rol } = mydata.data[0];
      this.setState({ nombre: nombre, apellido: apellido, nombre_usuario: nombre_usuario, estado: id_estado, rol: id_rol, issubmitting: false });

    } catch (e) {
      toastr.error('No se pudo consultar la información de usuario.', 'Error');
      this.setState({ issubmitting: false });
    }
  }

  async updateuser(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('nombre', this.state.nombre);
        data.append('apellido', this.state.apellido);
        data.append('nombre_usuario', this.state.nombre_usuario);
        data.append('estado', this.state.estado);
        data.append('rol', this.state.rol);
        await RequestService.put('user/' + this.state.id, data);
        toastr.success('Usuario Actualizado');
        this.setState({
          issubmitting: false, nombre: '', password: '', apellido: '',
          nombre_usuario: '', rol: 1, estado: 1
        });
        this.props.history.push("/admin/table");
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }



  async updatepass(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else if (this.state.password === this.state.passconfirm) {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('contrasena', this.state.password);
        let mydata = await RequestService.post('auth/password/' + this.state.id, data);
        toastr.success('Contraseña Actualizada');
        this.setState({ issubmitting: false, passconfirm: '', password: '' });
      } else {
        toastr.warning('Las contraseñas no coinciden');
        this.setState({ issubmitting: false });
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }


  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Editar Usuario </h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/admin"
                  role="button">Administración
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/admin/table"
                  role="button">Usuarios
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Editar</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <h4 className="card-title">Datos de Usuario</h4>
                <form className="forms-sample">
                  <Form.Group>
                    <label htmlFor="exampleInputUsername1">Nombre:</label>
                    <Form.Control type="text"
                      value={this.state.nombre}
                      className={Utils.loaderrors(this.state.errors, 'nombre')}
                      id="exampleInputUsername1"
                      onChange={(val) => {
                        this.setState({ nombre: val.target.value });
                      }}
                      placeholder="Nombre" size="lg" />
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="exampleInputEmail1">Apellido:</label>
                    <Form.Control type="text"
                      className={Utils.loaderrors(this.state.errors, 'apellido')}
                      value={this.state.apellido}
                      onChange={(val) => {
                        this.setState({ apellido: val.target.value });
                      }}
                      id="exampleInputEmail1" placeholder="Apellido" />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="usuariosesion">Usuario de sesión:</label>
                    <Form.Control type="text"
                      className={Utils.loaderrors(this.state.errors, 'nombre_usuario')}
                      value={this.state.nombre_usuario}
                      onChange={(val) => {
                        this.setState({ nombre_usuario: val.target.value });
                      }}
                      id="usuariosesion" placeholder="Usuario" />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="estado">Estado:</label>
                    <select className="form-control form-control-sm "
                      value={this.state.estado}
                      onChange={(val) => {
                        this.setState({ estado: val.target.value });
                      }}
                      id="estado">
                      <option value={1}>Activo</option>
                      <option value={2}>Inactivo</option>
                    </select>
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="rol">Rol:</label>
                    <select
                      className={"form-control form-control-sm " + Utils.loaderrors(this.state.errors, 'rol_id')}
                      id="rol"
                      value={this.state.rol}
                      onChange={(val) => {
                        this.setState({ rol: val.target.value });
                      }}
                    >
                      <option value={1}>Administrador</option>
                      <option value={2}>Gestor</option>
                      <option value={3}>Observador</option>
                    </select>
                  </Form.Group>

                  <button type="button"
                    className="btn btn-success btn-lg"
                    style={{ margin: '5px' }}
                    onClick={this.updateuser}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button>
                  <Link to={'/admin/table'} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
                </form>
              </div>
            </div>
          </div>
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <h4 className="card-title">Cambiar Contraseña de Usuario</h4>
                <form className="forms-sample">
                  <Form.Group>
                    <label htmlFor="exampleInputUsername1">Contraseña</label>
                    <Form.Control type="password"
                      className={Utils.loaderrors(this.state.errors, 'contrasena')}
                      value={this.state.password}
                      onChange={(val) => {
                        this.setState({ password: val.target.value });
                      }}
                      id="exampleInputUsername1" placeholder="Contraseña" size="lg" />
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="exampleInputEmail1">Confirmar</label>
                    <Form.Control type="password"
                      value={this.state.passconfirm}
                      onChange={(val) => { this.setState({ passconfirm: val.target.value }); }}
                      className="form-control" id="exampleInputEmail1" placeholder="Confirmar"
                    />
                  </Form.Group>

                  <button type="submit" className="btn btn-success btn-lg" onClick={this.updatepass}>{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Cambiar"}</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default Userform;
