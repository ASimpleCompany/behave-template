import React, { Component } from 'react';
import { Link } from "react-router-dom";
import toastr from "toastr";
import RequestService from '../../../services/RequestService';


class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate : new Date(),
      gotdata:false,
      actions: [ 
        {  title: 'Usuarios' , descripcion: 'Usuarios', icon: 'fa fa-users icon-md',  link:'/admin/table' },
        {  title: 'Actividades' , descripcion: 'Actividades', icon: 'fa fa-eye icon-md', link:'/admin/activities' }
      
      ]
    } 
  }

  componentDidMount(){
    this.getdata();
  }

  async getdata(){
    try{
      let mydata = await RequestService.get('user/stats/get',null);
      let totales= mydata.data[0];
      this.setState({total:totales.total,
        admin:totales.admin,
        lector:totales.lector,
        gestor:totales.gestor,
        gotdata:true
      });
    }catch(e){
      toastr.error('Los datos no pudieron ser consultados.');
    }
  }

  render () {
    const { actions } = this.state;
    return (
      <div>
        
        {/* Title */}
        <div className="row">
        <h2 className="p-3">Administración</h2>
        </div>
        
        {/*KPI'S*/}
        <div className="row">
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="fa fa-users text-danger icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Cantidad de usuarios</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                      { this.state.gotdata ? this.state.total:<i className="fa fa-spin fa-circle-o-notch"></i> }
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="fa fa-briefcase text-warning icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Administradores</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        { this.state.gotdata ? this.state.admin:<i className="fa fa-spin fa-circle-o-notch"></i> }
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="fa fa-user text-success icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Gestores</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        { this.state.gotdata ? this.state.gestor:<i className="fa fa-spin fa-circle-o-notch"></i> }
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-account-box-multiple text-info icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Lectores</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        { this.state.gotdata ? this.state.lector:<i className="fa fa-spin fa-circle-o-notch"></i> }
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div> 

           {/*Main Functions*/}
           <div className="row">
          <h2 className="mx-auto p-4">¿Qué desea hacer hoy?</h2>
        </div>
         <div className="row">
          {actions.map((action) =>
            <Link className="col-sm-6 col-md-6 col-lg-6 grid-margin stretch-card streched-link text-decoration-none" to={action.link} role="button">
            <div className="card card-statistics">
              <div className="card-body py-5">
                <div className="d-flex flex-row justify-content-center align-items">
                  <i className={action.icon} ></i>
                  <div className="ml-3">
                       <h5 className="mb-0 text-right text-dark">{action.descripcion}</h5>
                  </div>
                </div>
              </div>
            </div>
            </Link> 
             )
          }
            </div>
         </div> 
    );
  }
}

export default Dashboard;