import React, { Component, useState } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';

export class UserNew extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id: 0,
      password: '',
      nombre: '',
      nombre_usuario: '',
      apellido: '',
      estado: 1,
      rol: 1,
      issubmitting: false
    }
    this.updateuser = this.updateuser.bind(this);
  }

  componentDidMount() {
    this.setState({ id: this.props.match.params.id });
  }

  async updateuser(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('nombre', this.state.nombre);
        data.append('contrasena', this.state.password);
        data.append('apellido', this.state.apellido);
        data.append('nombre_usuario', this.state.nombre_usuario);
        data.append('estado', this.state.estado);
        data.append('rol', this.state.rol);
        await RequestService.post('user/', data);
        toastr.success('Usuario Creado');
        this.setState({
          issubmitting: false,
          nombre: '',
          password: '',
          apellido: '',
          nombre_usuario: '',
          rol: 1,
          estado: 1
        });
        this.props.history.push("/admin/table");
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }


  handleChange = date => {
    this.setState({
      startDate: date
    });
  };

  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title"> Agregar Usuario </h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/admin"
                  role="button">Administración
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/admin/table"
                  role="button">Usuarios
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Agregar Usuario</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
              <div className="mb-5">
                <h1 className="page-title"><strong>Información General</strong></h1>
                </div>
                <form className="forms-sample">
                  <Form.Group>
                    <label htmlFor="exampleInputUsername1">Nombre:</label>
                    <Form.Control type="text"
                      value={this.state.nombre}
                      className={Utils.loaderrors(this.state.errors, 'nombre')}
                      id="exampleInputUsername1"
                      onChange={(val) => {
                        this.setState({ nombre: val.target.value });
                      }}
                      placeholder="Nombre" size="lg" />
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="exampleInputEmail1">Apellido:</label>
                    <Form.Control type="text" className="form-control"
                      value={this.state.apellido}
                      className={Utils.loaderrors(this.state.errors, 'apellido')}
                      onChange={(val) => {
                        this.setState({ apellido: val.target.value });
                      }}
                      id="exampleInputEmail1" placeholder="Apellido" />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="usuariosesion">Usuario de sesión:</label>
                    <Form.Control type="text" className="form-control"
                      value={this.state.nombre_usuario}
                      className={Utils.loaderrors(this.state.errors, 'nombre_usuario')}
                      onChange={(val) => {
                        this.setState({ nombre_usuario: val.target.value });
                      }}
                      id="usuariosesion" placeholder="Usuario" />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="contrasena">Contraseña</label>
                    <Form.Control type="password"
                      value={this.state.password}
                      className={Utils.loaderrors(this.state.errors, 'contrasena')}
                      onChange={(val) => {
                        this.setState({ password: val.target.value });
                      }}
                      id="contrasena" placeholder="Contraseña" size="lg" />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="estado">Estado:</label>
                    <select
                      value={this.state.estado}
                      className={"form-control form-control-sm " + Utils.loaderrors(this.state.errors, 'estado_id')}
                      onChange={(val) => {
                        this.setState({ estado: val.target.value });
                      }}
                      id="estado">
                      <option value={1}>Activo</option>
                      <option value={2}>Inactivo</option>
                    </select>
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="rol">Rol:</label>
                    <select
                      className={"form-control form-control-sm " + Utils.loaderrors(this.state.errors, 'rol_id')}
                      id="rol"
                      value={this.state.rol}
                      onChange={(val) => {
                        this.setState({ rol: val.target.value });
                      }}
                    >
                      <option value={1}>Administrador</option>
                      <option value={2}>Gestor</option>
                      <option value={3}>Observador</option>
                    </select>
                  </Form.Group>

                  <button type="button"
                    className="btn btn-success btn-lg"
                    style={{ margin: '5px' }}
                    onClick={this.updateuser}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button>
                  <Link to={'/admin/table'} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default UserNew;
