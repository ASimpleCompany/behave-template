import React, { Component } from "react";
import { Form } from "react-bootstrap";
import toastr from "toastr";
import User from "../../../mobx/user";
import image from "../../../assets/images/auth/login-bg.jpg";
import RequestService from "../../../services/RequestService";

class Login extends Component {

  constructor(props) {

    super(props);
    this.state = {
      username: "",
      password: "",
      issubmitting: false,
      remenber: false
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleClick = async (e) => {
    if (!this.state.issubmitting) {
      try {
        this.setState({ issubmitting: true });
        let test = await RequestService.userLogin(this.state.username, this.state.password);
        await User.login(test);
        window.location = "/";
      } catch (e) {
        if (typeof e.response !== 'undefined') {
          if (typeof e.response.data) {
            toastr.error(e.response.data.message);
          } else {
            toastr.error(e, "Favor intente más tarde.");
          }
        } else {
          toastr.error(e, "Favor intente más tarde.");
        }
        this.setState({ issubmitting: false });
      }
    }
  };

  render() {

    return (

      <div className="login-wrapper" style={{backgroundImage: `url(${image})`}}>

        <div className="d-flex align-items-center auth px-0">

          <div className="row w-100 mx-0">

            <div className="col-lg-4 mx-auto">

              <div className="auth-form-light text-left py-5 px-4 px-sm-5">

                <div className="text-center brand-logo">
                  <img src={require("../../../assets/images/logo.png")} alt="logo" />
                </div>

                <h4>¡Bienvenido!</h4>

                <h6 className="font-weight-light">
                  Inicia sesión para continuar
                </h6>

                <Form className="pt-3">

                  <Form.Group className="d-flex search-field">
                    <Form.Control
                      name="username"
                      type="text"
                      placeholder="Usuario"
                      size="lg"
                      className="h-auto"
                      value={this.state.username}
                      onChange={this.handleChange}
                    />
                  </Form.Group>

                  <Form.Group className="d-flex search-field">
                    <Form.Control
                      name="password"
                      type="password"
                      placeholder="Contraseña"
                      size="lg"
                      className="h-auto"
                      value={this.state.password}
                      onChange={this.handleChange}
                    />

                  </Form.Group>

                  <div className="mt-3">

                    <button
                      className="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn"
                      onClick={(e) => {
                        e.preventDefault();
                        this.setState({ issubmitting: !this.state.issubmitting })
                        this.handleClick();
                      }}
                    >
                      {this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"/> : "Iniciar Sesión"}
                    </button>

                  </div>
                  
                </Form>

              </div>

            </div>

          </div>

        </div>

      </div>
    );
  }
}


export default Login;