import React, { Component, useState } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';
import moment from 'moment';
import DatePicker from "react-datepicker/es";

export class VacationNew extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id_empleado: 0,
      id_contrato: 0,
      listacontratos: [],
      cantidaddias: 15
    }
    this.create = this.create.bind(this);
  }

  componentDidMount() {
    let { id_empleado } = this.props.location.state;
    this.setState({ id_empleado: id_empleado });
    this.getdata(id_empleado);
  }

  async getdata(id) {
    try {
      this.setState({ issubmitting: true });
      let constactlist = await RequestService.get('employee/constractlist/' + id, null);
      this.setState({ id_contrato: constactlist.data[0].id_contrato });
      this.setState({ listacontratos: constactlist.data, issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  listacontrato() {
    let data = this.state.listacontratos.map((value, index) => {
      return <option value={value.id_contrato}>{value.descripcion}</option>
    });
    return data;
  }

  async create(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('fecha_inicio', moment(this.state.fecha_inicio).format("YYYY-MM-DD"));
        data.append('fecha_retorno', moment(this.state.fecha_retorno).format("YYYY-MM-DD"));
        data.append('cantidaddias', this.state.cantidaddias);
        data.append('id_contrato', this.state.id_contrato);
        data.append('id_empleado', this.state.id_empleado);
        await RequestService.post('vacation/', data);
        toastr.success('Vacación Programada');
        this.props.history.push('/employee/' + this.state.id_empleado);
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }

  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Agregar Entrada de Vacaciones</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to={'/employee/' + this.state.id_empleado}
                  role="button">Vacaciones
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Agregar</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <form className="forms-sample">
                  <Form.Group>
                    <label htmlFor="fecha_inicio">Fecha de inicio:</label>
                    <br/>
                    <DatePicker
                        dateFormat="dd/MM/yyyy"
                        minDate={new Date()-5}
                        selected={this.state.fecha_inicio}
                        onChange={async (date) => {
                          await this.setState({ fecha_inicio: date });
                        }}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_inicio')}
                        size="lg"
                    />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="fecha_retorno">Fecha de retorno:</label>
                    <br/>
                    <DatePicker
                        dateFormat="dd/MM/yyyy"
                        selected={this.state.fecha_retorno}
                        minDate={this.state.fecha_inicio}
                        onChange={async (date) => {
                          await this.setState({ fecha_retorno: date });
                        }}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_retorno')}
                        size="lg"
                    />

                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="departamento">Contrato:</label>
                    <select
                      value={this.state.id_contrato}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'id_contrato')}
                      onChange={(val) => {
                        this.setState({ id_contrato: val.target.value });
                      }}
                      size="lg"
                      id="departamento">
                      {this.listacontrato()}
                    </select>
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="cantidaddias">Cantidad de días:</label>

                    <select value={this.state.cantidaddias}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'cantidaddias')}
                      onChange={(val) => {
                        this.setState({ cantidaddias: val.target.value });
                      }}
                      id="cantidaddias">
                      <option value={15}>15 Días</option>
                      <option value={30}>30 Días</option>
                    </select>
                  </Form.Group>

                  <button type="button"
                    className="btn btn-success btn-lg"
                    style={{ margin: '5px' }}
                    onClick={this.create}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button>
                  <Link to={'/employee/' + this.state.id_empleado} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default VacationNew;
