# Project standars

Para este proyecto se seguira el siguiente estandar de programacion:

## Credentials

### Database: 

SET GLOBAL event_scheduler = ON;



### Querys

select * from (select selected_date, weekday(selected_date) as weekd, te.id_empleado from tbl_empleados te,
(select adddate('2020-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) selected_date from
(select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0,
(select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1,
(select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2,
(select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3,
(select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4) v
where selected_date between '2020-01-15' and '2020-01-30') fechas
left join tbl_marcacion tm on fechas.id_empleado=tm.id_empleado and fechas.selected_date= tm.fecha_marcacion 
left join (SELECT dia_lunes as horas,0 as weekd, tc.id_empleado FROM tbl_horarios th inner join tbl_contratos tc on th.id_horario = tc.id_horario WHERE tc.id_estado=6 union all 
SELECT dia_martes as horas,	1 as weekd, tc.id_empleado FROM tbl_horarios th inner join tbl_contratos tc on th.id_horario = tc.id_horario WHERE tc.id_estado=6 union all 
SELECT dia_miercoles as horas,2 as weekd,tc.id_empleado FROM tbl_horarios th inner join tbl_contratos tc on th.id_horario = tc.id_horario WHERE tc.id_estado=6 union all 
SELECT dia_jueves as horas,	3 as weekd, tc.id_empleado FROM tbl_horarios th inner join tbl_contratos tc on th.id_horario = tc.id_horario WHERE tc.id_estado=6 union all 
SELECT dia_viernes as horas,4 as weekd, tc.id_empleado FROM tbl_horarios th inner join tbl_contratos tc on th.id_horario = tc.id_horario WHERE tc.id_estado=6 union all 
SELECT dia_sabado as horas,	5 as weekd, tc.id_empleado FROM tbl_horarios th inner join tbl_contratos tc on th.id_horario = tc.id_horario WHERE tc.id_estado=6 union all 
SELECT dia_domingo as horas,6 as weekd, tc.id_empleado FROM tbl_horarios th inner join tbl_contratos tc on th.id_horario = tc.id_horario WHERE tc.id_estado=6) 
horario on fechas.id_empleado=horario.id_empleado and horario.weekd=fechas.weekd
order by fechas.id_empleado, fechas.selected_date