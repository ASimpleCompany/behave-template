import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Dropdown } from 'react-bootstrap';
import Cookies from 'universal-cookie';
import RequestService from "../../services/RequestService";
const cookies = new Cookies();

/*TODO:
  dividir los colaboradores por estados en el menu para evitar confuciones
*/


class Sidebar extends Component {
  
 state = { user: 'funciona'};

  toggleMenuState(menuState) {
    if (this.state[menuState]) {
      this.setState({ [menuState]: false });
    } else if (Object.keys(this.state).length === 0) {
      this.setState({ [menuState]: true });
    } else {
      Object.keys(this.state).forEach(i => {
        this.setState({ [i]: false });
      });
      this.setState({ [menuState]: true });
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }
  }


  isPathActive(path) {
    return this.props.location.pathname.startsWith(path);
  }

  componentDidMount() {
   
    this.onRouteChanged();
    // add className 'hover-open' to sidebar navitem while hover in sidebar-icon-only menu
    const body = document.querySelector('body');
    document.querySelectorAll('.sidebar .nav-item').forEach((el) => {

      el.addEventListener('mouseover', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.add('hover-open');
        }
      });
      el.addEventListener('mouseout', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.remove('hover-open');
        }
      });
    });
  }


  async getUserRole() {
    try{
      let role = cookies.get('id_rol');
     
      let mydata = await RequestService.get('user/roles/'+ role);
      this.setState({userdata:mydata.data });
      this.setState({sidebar:mydata.data.sidebars[0].administracion });
    }catch(e){
      
      console.log(e);
 
    }
    
  }
  

  
  onRouteChanged() {
    document.querySelector('#sidebar').classList.remove('active');
    Object.keys(this.state).forEach(i => {
      this.setState({ [i]: false });
    });

    const dropdownPaths = [
      { path: '/basic-ui', state: 'basicUiMenuOpen' },
      { path: '/form-elements', state: 'formElementsMenuOpen' },
      { path: '/tables', state: 'tablesMenuOpen' },
      { path: '/icons', state: 'iconsMenuOpen' },
      { path: '/charts', state: 'chartsMenuOpen' },
      { path: '/user-pages', state: 'userPagesMenuOpen' },
    ];

    dropdownPaths.forEach((obj => {
      if (this.isPathActive(obj.path)) {
        this.setState({ [obj.state]: true })
      }
    }));

  }


  
/*
        <!--<div className="text-center sidebar-brand-wrapper d-flex align-items-center">
          <a className="sidebar-brand brand-logo" href="/"><img src={require("../../assets/images/logo.svg")} alt="logo" /></a>
          <a className="sidebar-brand brand-logo-mini pt-3" href="/"><img src={require("../../assets/images/logo-mini.svg")} alt="logo" /></a>
        </div>-->
 */


  render() {
    const { menu } = this.props
    return (

      <nav className="sidebar sidebar-offcanvas" id="sidebar">

        <ul className="nav">
         
          <li className="nav-item nav-profile not-navigation-link">

            <div className="nav-link">

              <br></br>
              <br></br>
              
              <Dropdown>

                <Dropdown.Toggle className="nav-link user-switch-dropdown-toggler p-0 toggle-arrow-hide bg-transparent border-0 w-100">

                  <div className="d-flex justify-content-between align-items-start">
                    <div className="profile-image">
                      <img src={require("../../assets/images/face-clipart.png")} alt="profile" />
                    </div>

                    <div className="text-left ml-3">
                      <p className="profile-name text-capitalize">{ cookies.get('nombre') + ' ' + cookies.get('apellido') }</p>
                      <small className="designation text-muted text-small text-capitalize">{ cookies.get('descrol') }</small>
                      <span className="status-indicator online"></span>
                    </div>

                  </div>

                </Dropdown.Toggle>

              </Dropdown> 

            </div>

          </li>


          { menu.map( element => (
         

           <li className={this.isPathActive('/icons') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to={element.path}>
                <i className={ `${element.icon} menu-icon`}></i>
              <span className="menu-title text-capitalize">{ element.descripcion}</span>
           </Link>
            
           </li>
           
          ))}

        </ul>

      </nav>
    );
  }


}

export default withRouter(Sidebar);