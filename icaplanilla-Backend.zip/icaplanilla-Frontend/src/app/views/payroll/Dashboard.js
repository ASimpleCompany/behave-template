import React, { Component } from 'react';
import { Link } from "react-router-dom";
import RequestService from '../../../services/RequestService';
import toastr from "toastr";
import { observer } from "mobx-react";

@observer
class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(),
      inputValue: '',
      gotdata: false,
      actions: [
        { title: 'Planilla', descripcion: 'Generar Planilla', icon: 'fa fa-book text-primary icon-md', link: '/payroll/first/planillas' },
        { title: 'Marcaciones', descripcion: 'Cargar Marcaciones', icon: 'fa fa-calendar text-primary icon-md', link: '/payroll/Attedance' },
      ]
    }
    this.statusChangedHandler = this.statusChangedHandler.bind(this);
    this.inputChangeHandler = this.inputChangeHandler.bind(this);
  }
  statusChangedHandler(event, id) {
    const todo = { ...this.state.todos[id] };
    todo.isCompleted = event.target.checked;
    const todos = [...this.state.todos];
    todos[id] = todo;
    this.setState({
      todos: todos
    })
  }

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      let mydata = await RequestService.get('payroll/stats', null);
      let totales = mydata.data[0];
      this.setState(totales);
      this.setState({ gotdata: true });
    } catch (e) {
      toastr.error('Los datos no pudieron ser consultados.', 'Intente nuevamente');
    }
  }

  inputChangeHandler(event) {
    this.setState({
      inputValue: event.target.value
    });
  }

  render() {

    const { actions } = this.state

    return (
      <div>
        <div className="row">
          <h2 className="p-3">Planillas</h2>
        </div>
        <div className="row">
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-account-cash text-danger icon-lg"/>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Total de Planilla Mensual</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        {this.state.gotdata ? '$ ' + this.state.totxmes : <i className="fa fa-spin fa-circle-o-notch"/>}
                      </h3>
                    </div>
                  </div>
                </div>
                <p className="text-muted mt-3 mb-0">
                  <i className="mdi mdi-alert-octagon mr-1" aria-hidden="true"/> Valor estimado </p>
              </div>
            </div>
          </div>

          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-square-inc-cash text-warning icon-lg"/>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Total de Planilla Anual</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        {this.state.gotdata ? '$ ' + this.state.totmesx12 : <i className="fa fa-spin fa-circle-o-notch"/>}
                      </h3>
                    </div>
                  </div>
                </div>
                <p className="text-muted mt-3 mb-0">
                  <i className="mdi mdi-alert-octagon mr-1" aria-hidden="true"/> Valor estimado </p>
              </div>
            </div>
          </div>

          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-check-decagram text-success icon-lg"/>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Planillas Aprobadas</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        {this.state.gotdata ? this.state.totapro : <i className="fa fa-spin fa-circle-o-notch"/>}
                      </h3>
                    </div>
                  </div>
                </div>
                <p className="text-muted mt-3 mb-0">
                  <i className="mdi mdi-alert-octagon mr-1" aria-hidden="true"/>Disponibles para impresión</p>
              </div>
            </div>
          </div>

          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-cash-multiple text-info icon-lg"/>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Impuestos Mensuales</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        {this.state.gotdata ? '$ ' + this.state.totimp : <i className="fa fa-spin fa-circle-o-notch"/>}
                      </h3>
                    </div>
                  </div>
                </div>
                <p className="text-muted mt-3 mb-0">
                  <i className="mdi mdi-alert-octagon mr-1" aria-hidden="true"/> Valor estimado </p>
              </div>
            </div>
          </div>

        </div>

        {/*Main Functions*/}
        <div className="row">
          <h2 className="mx-auto p-4">¿Qué desea hacer hoy?</h2>
        </div>
        <div className="row">
          {actions.map((action) =>
            <Link className="col-sm-6 col-md-6 col-lg-6 grid-margin stretch-card streched-link text-decoration-none" to={action.link} role="button">
              <div className="card card-statistics">
                <div className="card-body py-5">
                  <div className="d-flex flex-row justify-content-center align-items">
                    <i className={action.icon} />
                    <div className="ml-3">
                      <h5 className="mb-0 text-right text-dark">{action.descripcion}</h5>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          )
          }
        </div>
      </div>
    );
  }
}
const ListItem = (props) => {
  return (
    <li className={(props.isCompleted ? 'completed' : null)}>
      <div className="form-check form-check-success m-0 align-items-start">
        <label htmlFor="" className="form-check-label font-weight-medium">
          <input className="checkbox" type="checkbox"
            checked={props.isCompleted}
            onChange={props.changed}
          /> {props.children} <i className="input-helper"/>
        </label>
      </div>
      <i className="remove mdi mdi-close-circle-outline" onClick={props.remove}/>
    </li>
  )
};
export default Dashboard;