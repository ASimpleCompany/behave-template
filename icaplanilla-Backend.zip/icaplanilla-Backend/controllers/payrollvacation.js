const db = require('../config/db');
const { getUserId, validateAdminiostrative } = require('../helpers/utils')
const { insertlog } = require('../helpers/logactions');
const { check, validationResult } = require('express-validator');
const {inpuestosfijos}=require('./payrollFunctions')
const util = require('util');
const query = util.promisify(db.query).bind(db);


exports.tablepayrollvacations=(req, res, next) => {
  db.query('select tce.id_estado,tce.descripcion as estado, tv.id_vacaciones, concat(te.nombre,\' \',te.apellido) as nombre, td.descripcion as departamento,tn.ano, \
  tv.cantidaddias,tv.id_nomina, pagado,  DATE_FORMAT(tv.fecha_inicio, \'%d-%m-%Y\') as fecha_inicio,  DATE_FORMAT(tv.fecha_retorno, \'%d-%m-%Y\') as fecha_retorno,\
  IF(tn.monto_nomina>0,tn.monto_nomina,get_planilladata(tv.id_nomina,\'CRNOMINA\')) as monto_nomina, tn.fecha_creacion, if(tn.total_pagar>0,tn.total_pagar,get_planilladata(tv.id_nomina,\'TOTALNOMINA\')) as total_pagar,\
  ifnull(tcen.id_estado,0) as id_estado_nomina, ifnull(tcen.descripcion,\'NO CREADO\') as estado_nomina  from tbl_vacaciones tv  \
  inner join tbl_catalogo_estado tce on tce.id_estado =tv.id_estado  LEFT join tbl_contratos tc on tv.id_contrato =tc.id_contrato \
  left join tbl_empleados te on tc.id_empleado =te.id_empleado left join tbl_departamento td on tc.id_departamento =td.id_departamento\
  LEFT join tbl_nomina tn on tn.id_nomina = tv.id_nomina left join tbl_catalogo_estado tcen on tcen.id_estado = tn.id_estado\
  where tv.id_estado in (6,8,10) and tn.id_estado > 0 ORDER BY tv.id_vacaciones desc', 
    function (error, results, fields) {
      if (error){
        return res.status(401).json({message:'error en conección a datos '+error});
      } 
      return res.status(200).json(results);
  });
};


exports.vacaciones = [
  [
    check('id_vacaciones').notEmpty().isInt({ min: 1 })
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) { return res.status(422).json({ errors: errors.array() }); }
    
    let empleados = await query('select tv.id_vacaciones,tv.cantidaddias,tc.id_empleado,tc.id_contrato,year(fecha_inicio) as ano, tc.id_departamento,  \
    get_employeedata(tc.id_empleado,\'SALARY\') as mensual, get_employeedata(tc.id_empleado,\'SALARYQUIN\') as salario_quin,get_employeedata(tc.id_empleado,\'SALARYHORA\') as hora,\
    get_vacationdata(tv.id_empleado,\'MONTOADELANTADO\') as vacadelantado\
    from tbl_vacaciones tv inner join tbl_catalogo_estado tce on tce.id_estado = tv.id_estado \
    LEFT join tbl_contratos tc on tv.id_contrato =tc.id_contrato where tv.id_estado in (6,8) and id_vacaciones=?', [req.body.id_vacaciones]);
    let useid = getUserId(req);
    let sql = 'INSERT INTO tbl_nomina (id_estado, ano,id_codigoplanilla, carga_marcacion,creado_por) VALUES(7,?,53,?,?)';
    let nomina = [empleados[0].ano, false, useid];
    
    let rs = [];
    try {
      rs = await query(sql, nomina);
      await query('update tbl_vacaciones set id_nomina = ? where id_vacaciones= ?', [rs.insertId,parseInt(req.body.id_vacaciones)]);
    } catch (e) {
      return res.status(401).json({ message: 'error en conexión a datos ', error: e });
    }

    let id_nomina = rs.insertId;

    try {
      
      let descuentofijo = await query('select * from tbl_descuento_fijos where id_tipo_descuento in (2,4,11) and id_estado = 1');

      for (const empleado of empleados) {
        let sqldetalle = 'INSERT INTO tbl_detalle_planilla(id_nomina,id_tipo_descuento,id_empleado,id_codigoplanilla,id_planilla,monto) VALUES (?,?,?,?,?,?)';
        
        /*
        * Crea Planill para colaborador
        */
        let montoacalcular=0;
        if(empleado.cantidaddias===30){
          montoacalcular= empleado.mensual;
        }else{
          montoacalcular= empleado.salario_quin;
        }

        let planilladata = [empleado.mensual, empleado.salario_quin, empleado.id_empleado, id_nomina,53, empleado.id_contrato, empleado.hora];
        let planilla = await query('INSERT INTO tbl_planillas(salario_mensual_pactado,salario_quincenal_neto,\
           id_empleado, id_nomina, id_codigoplanilla,id_contrato,salario_hora) VALUES (?,?,?,?,?,?,?)', planilladata);
        let id_planilla = planilla.insertId;

        /*
        * Insertar creditos para colaborador
        */
        let datosdetalle = [id_nomina, 12, empleado.id_empleado, 53, id_planilla, empleado.salario_quin];
        await query(sqldetalle, datosdetalle);
       /*
        * carga vacaciones adelantadas
        */
        datosdetalle = [id_nomina, 18, empleado.id_empleado, 53, id_planilla,empleado.vacadelantado];
        await query(sqldetalle, datosdetalle);
        montoacalcular = montoacalcular-empleado.vacadelantado;
        /*
        * Insertar todos los descuentos fijos
        */
        for (const descuento of descuentofijo) {
          let monto = 0;
          let datosdetalle = [];

          let operacion = descuento.operacion.replace(/{salario}/gi, montoacalcular)
            .replace(/{mensula}/gi, empleado.mensual)
            .replace(/{deduccion}/gi, descuento.monto);
          
          let validacion = descuento.validacion.replace(/{salario}/gi, montoacalcular)
            .replace(/{mensula}/gi, empleado.mensual)
            .replace(/{deduccion}/gi, descuento.monto);
          datosdetalle = [id_nomina, descuento.id_tipo_descuento, empleado.id_empleado, 53, id_planilla];
          if (validacion === '') {
            monto = eval(operacion);
            datosdetalle.push(monto);
            await query(sqldetalle, datosdetalle);
          } else {
            if (eval(validacion)) {
              monto = eval(operacion);
              if(descuento.id_tipo_descuento===11 && empleado.cantidaddias===30){
                monto=monto*2;
              }
              datosdetalle.push(monto);
              await query(sqldetalle, datosdetalle);
            }
          }
        }

        /*
        * Insertar todos los descuentos directos
        */
        let directos = await query('SELECT id_descuento_directo, montototal, monto_letra_quincenal, montoactual, montoactual-monto_letra_quincenal as last FROM tbl_descuento_directo WHERE id_empleado = ? and id_estado=6', [empleado.id_empleado]);
        sqldetalle = 'INSERT INTO tbl_detalle_planilla(id_descuento_directo,id_nomina,id_tipo_descuento,id_empleado,id_codigoplanilla,id_planilla,monto) VALUES (?,?,?,?,?,?,?)';

        if(empleado.cantidaddias===15){
          empleado.mensual =empleado.salario_quin;
        }

        for (const directo of directos) {
          let datosdetalle = [];
          if (directo.last <= 0) {
            datosdetalle = [directo.id_descuento_directo, id_nomina, 1, empleado.id_empleado, 53, id_planilla, directo.montoactual];
          } else {
            datosdetalle = [directo.id_descuento_directo, id_nomina, 1, empleado.id_empleado, 53, id_planilla, directo.monto_letra_quincenal];
          }
          await query(sqldetalle, datosdetalle);
        }
      }
    } catch (e) {
      return res.status(401).json({ message: 'error en conexión a datos ', error: e });
    }
    insertlog('Planilla Vacaciones','Agrega',id_nomina, getUserId(req));
    return res.status(200).json(rs);
  }
];





