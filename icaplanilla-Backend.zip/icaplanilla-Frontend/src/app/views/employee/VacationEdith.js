import React, { Component, useState } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';
import moment from 'moment';
import { confirmAlert } from 'react-confirm-alert';

import 'react-confirm-alert/src/react-confirm-alert.css';
import DatePicker from "react-datepicker/es";


export class VacationEdith extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id_empleado: 0,
      listacontratos: [],
      cantidaddias: 15
    }
    this.update = this.update.bind(this);
  }

  componentDidMount() {
    let { id_empleado } = this.props.location.state;
    this.setState({ id_empleado: id_empleado });
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let id = this.props.match.params.id;
      let { id_empleado } = this.props.location.state;
      let constactlist = await RequestService.get('employee/constractlist/' + id_empleado, null);
      let vacationdata = await RequestService.get('vacation/' + id, null);
      this.setState({ listacontratos: constactlist.data });

      this.setState({cantidaddias: vacationdata.data[0].cantidaddias,
      contrato: vacationdata.data[0].contrato,
      estado: vacationdata.data[0].estado,
      fecha_inicio: Utils.improveDate(vacationdata.data[0].fecha_inicio),
      fecha_retorno: Utils.improveDate(vacationdata.data[0].fecha_retorno),
      id_contrato: vacationdata.data[0].id_contrato,
      id_empleado: vacationdata.data[0].id_empleado,
      id_estado: vacationdata.data[0].id_estado,
      id_vacaciones: vacationdata.data[0].id_vacaciones,
      pagado: vacationdata.data[0].pagado});

      this.setState({ issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async update(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('fecha_inicio', moment(this.state.fecha_inicio).format("YYYY-MM-DD"));
        data.append('fecha_retorno', moment(this.state.fecha_retorno).format("YYYY-MM-DD"));
        data.append('cantidaddias', this.state.cantidaddias);
        data.append('id_contrato', this.state.id_contrato);
        data.append('id_empleado', this.state.id_empleado);
        await RequestService.put('vacation/' + this.props.match.params.id, data);
        toastr.success('Vacación Actualizada');
        this.setState({ issubmitting: false });
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }

  listacontrato() {
    let data = this.state.listacontratos.map((value, index) => {
      return <option value={value.id_contrato}>{value.descripcion}</option>
    });
    return data;
  }

  async noaproveCommit(accion) {
    confirmAlert({
      title: 'Actualizar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let data = new FormData();
              data.append('accion', accion);
              let rs = await RequestService.put('vacation/' + this.props.match.params.id + '/approve', data);
              console.log(rs);
              toastr.success('Actualizacion realizada');
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser actualizados.', 'Intente de nuevo');
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }

  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Editar Entrada de Vacaciones</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to={'/employee/' + this.state.id_empleado}
                  role="button">Vacaciones
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Editar</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <form className="forms-sample">
                  <Form.Group>
                    <label htmlFor="fecha_inicio">Fecha de inicio:</label>
                    <br/>
                    {this.state.id_estado === 7 ? <DatePicker
                        dateFormat="dd/MM/yyyy"
                        selected={this.state.fecha_inicio}
                        onChange={async (date) => {
                          await this.setState({ fecha_inicio: date });

                        }}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_inicio')}
                        size="lg"
                    /> : <div>{moment(this.state.fecha_inicio).format("DD-MM-YYYY")}</div>}
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="fecha_retorno">Fecha de retorno:</label>
                    <br/>
                    {this.state.id_estado === 7 ?
                        <DatePicker
                            dateFormat="dd/MM/yyyy"
                            selected={this.state.fecha_retorno}
                            onChange={async (date) => {
                              await this.setState({ fecha_retorno: date });

                            }}
                            className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_retorno')}
                            size="lg"
                        />: <div>{moment(this.state.fecha_retorno).format("DD-MM-YYYY")}</div>}
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="departamento">Contrato:</label>
                    {this.state.id_estado === 7 ? <select
                      value={this.state.id_contrato}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'id_contrato')}
                      onChange={(val) => {
                        this.setState({ id_contrato: val.target.value });
                      }}
                      size="lg"
                      id="departamento">
                      {this.listacontrato()}
                    </select> : <div>{this.state.contrato}</div>}
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="cantidaddias">Cantidad de días:</label>

                    <select value={this.state.cantidaddias}
                      className={"form-control " + Utils.loaderrors(this.state.errors, 'cantidaddias')}
                            disabled={this.state.id_estado !== 7}
                      onChange={(val) => {
                        this.setState({ cantidaddias: val.target.value });
                      }}
                      id="cantidaddias">
                      <option value={15}>15 Días</option>
                      <option value={30}>30 Días</option>
                    </select>

                  </Form.Group>

                  {this.state.id_estado === 7 ?
                    <button type="button"
                      className="btn btn-success btn-lg"
                      style={{ margin: '5px' }}
                      onClick={this.update}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button> : null}

                  {this.state.id_estado === 7 ?
                    <button type="button"
                      className="btn btn-warning btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(true) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Aprobar"}</button> : null}

                  {this.state.id_estado === 7 ?
                    <button type="button"
                      className="btn btn-warning btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(false) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "No Aprobar"}</button> : null}

                  {this.state.id_estado === 6 ?
                    <button type="button"
                      className="btn btn-warning btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(true) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Finalizar"}</button> : null}


                  {this.state.id_estado === 11 ?
                    <button type="button"
                      className="btn btn-warning btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(false) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "No Finalizar"}</button> : null}

                  {this.state.id_estado === 11 ?
                    <button type="button"
                      className="btn btn-danger btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(true) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Finalizar"}</button> : null}
                  <Link to={'/employee/' + this.state.id_empleado} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default VacationEdith;
