import { Form } from 'react-bootstrap';
import React, { Component } from 'react';
const SearchBar = (props) => {
    let input;
    const handleClick = () => {
      props.onSearch(input.value);
    };
    return (
        <div>
          <Form.Group>
            <Form.Control type="text" ref={n => input = n}
                          placeholder="Buscar"
                          size="lg"
                          onChange={() => {
                            props.onSearch(input.value);
                          }}
            />
          </Form.Group>
        </div>
    );
  };


  export default SearchBar;