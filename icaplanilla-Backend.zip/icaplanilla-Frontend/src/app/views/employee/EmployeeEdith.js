import React, { Component } from "react";
import { Form } from "react-bootstrap";
import { Link } from 'react-router-dom';
import Utils from "../../../services/Utils"
import RequestService from '../../../services/RequestService';
import toastr from "toastr";
import moment from "moment";
import DatePicker from "react-datepicker/es";

class EmployeeEdith extends Component {

  constructor(props) {
    super(props);
    this.state = {
      num_colaborador: '',
      nombre: '',
      apellido: '',
      genero: 'M',
      cedula: '',
      seguro_social: '',
      correo: '',
      id_estado: 1,
      id_horario: 0,
      fecha_nacimiento: new Date(),
      telefono: '',
      apellido_casada: '',
      issubmitting: false
    }
    this.createemployee = this.createemployee.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.location !== this.props.location) {
      this.setState({ prevPath: this.props.location });
    }
  }

  componentDidMount() {
    let { prevPath } = this.props.location.state;
    this.setState({ prevPath: prevPath });
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let id = this.props.match.params.id;
      let employeedata = await RequestService.get('employee/' + id, null);
      console.log(employeedata.data);

      this.setState({
        apellido:employeedata.data[0].apellido,
      apellido_casada: employeedata.data[0].apellido_casada,
      cedula:employeedata.data[0].cedula,
      correo:employeedata.data[0].correo,
      estado: employeedata.data[0].estado,
      fecha_nacimiento: Utils.improveDate(employeedata.data[0].fecha_nacimiento),
      genero: employeedata.data[0].genero,
      id_empleado:employeedata.data[0].id_empleado,
      id_estado: employeedata.data[0].id_estado,
      nombre:employeedata.data[0].nombre,
      num_colaborador: employeedata.data[0].num_colaborador,
      seguro_social: employeedata.data[0].seguro_social,
      telefono: employeedata.data[0].telefono});

      this.setState({ issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async createemployee(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();

        data.append('num_colaborador', this.state.num_colaborador);
        data.append('nombre', this.state.nombre);
        data.append('apellido', this.state.apellido);
        data.append('genero', this.state.genero);
        data.append('cedula', this.state.cedula);
        data.append('seguro_social', this.state.seguro_social);
        data.append('correo', this.state.correo);
        data.append('id_estado', this.state.id_estado);
        data.append('fecha_nacimiento', moment(this.state.fecha_nacimiento).format("YYYY-MM-DD"));
        data.append('telefono', this.state.telefono);
        data.append('apellido_casada', this.state.apellido_casada);

        await RequestService.put('employee/' + this.props.match.params.id, data);
        toastr.success('Empleado Creado');
        this.setState({ issubmitting: false });
        this.props.history.push(this.state.prevPath);
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }

  render() {
    return (
      <div>
        <div className="page-header">
          <h1 className="page-title"> Editar Colaborador</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Editar</li>
            </ol>
          </nav>
        </div>
        <form className="forms-sample">
          {Utils.loading(this.state.issubmitting)}
          <div className=" grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="mb-5">
                  <h1 className="page-title"><strong>Información General</strong></h1>
                </div>
                <div className="row">
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="num_colaborador">Número de Colaborador:</label>
                      <Form.Control type="Number"
                        value={this.state.num_colaborador}
                        className={Utils.loaderrors(this.state.errors, 'num_colaborador')}
                        id="num_colaborador"
                        onChange={(val) => {
                          this.setState({ num_colaborador: val.target.value });
                        }}
                        placeholder="00000" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="nombre">Nombre:</label>
                      <Form.Control type="text"
                        value={this.state.nombre}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'nombre')}
                        onChange={(val) => {
                          this.setState({ nombre: val.target.value });
                        }}
                        id="nombre" placeholder="Nombre" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="apellido">Apellido:</label>
                      <Form.Control type="text"
                        value={this.state.apellido}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'apellido')}
                        onChange={(val) => {
                          this.setState({ apellido: val.target.value });
                        }}
                        id="apellido" placeholder="Apellido" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="apellido_casada">Apellido de Casada:</label>
                      <Form.Control type="text"
                        value={this.state.apellido_casada}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'apellido_casada')}
                        onChange={(val) => {
                          this.setState({ apellido_casada: val.target.value });
                        }}
                        id="apellido_casada" placeholder="Apellido de Casada" size="lg" />
                    </Form.Group>
                  </div>
                  {/* division */}

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="genero">Género:</label>
                      <select
                        value={this.state.genero}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'genero')}
                        onChange={(val) => {
                          this.setState({ genero: val.target.value });
                        }}
                        size="lg"
                        id="genero">
                        <option value={'M'}>Masculino</option>
                        <option value={'F'}>Femenino</option>
                      </select>
                    </Form.Group>
                  </div>

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="fecha_nacimiento">Fecha de Nacimiento:</label>
                      <br/>
                      <DatePicker
                          dateFormat="dd/MM/yyyy"
                          selected={this.state.fecha_nacimiento}
                          onChange={(date) => {
                            this.setState({ fecha_nacimiento: date });
                          }}
                          className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_nacimiento')}
                          size="lg"
                      />
                    </Form.Group>
                  </div>

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="cedula">Cédula:</label>
                      <Form.Control type="text"
                        value={this.state.cedula}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'cedula')}
                        onChange={(val) => {
                          this.setState({ cedula: val.target.value });
                        }}
                        id="cedula" placeholder="Cédula" size="lg" />
                    </Form.Group>
                  </div>

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="seguro_social">Seguro Social:</label>
                      <Form.Control type="text"
                        value={this.state.seguro_social}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'seguro_social')}
                        onChange={(val) => {
                          this.setState({ seguro_social: val.target.value });
                        }}
                        id="seguro_social" placeholder="Seguro Social" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="id_estado">Estado:</label>
                      <select
                        value={this.state.id_estado}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_estado')}
                        onChange={(val) => { this.setState({ id_estado: val.target.value }); }}
                        size="lg"
                        id="id_estado">
                        <option value={1}>Activo</option>
                        <option value={2}>Inactivo</option>
                        <option value={13}>Suspendido(a)</option>
                        <option value={3}>Licencia</option>
                      </select>
                    </Form.Group>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className=" grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="mb-5">
                  <h1 className="page-title"><strong>Información de Contacto</strong></h1>
                </div>
                <div className="row">
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="telefono">Teléfono:</label>
                      <Form.Control type="text"
                        value={this.state.telefono}
                        className={Utils.loaderrors(this.state.errors, 'telefono')}
                        onChange={(val) => {
                          this.setState({ telefono: val.target.value });
                        }}
                        id="telefono" placeholder="Telefono" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="correo">Correo:</label>
                      <Form.Control type="email"
                        value={this.state.correo}
                        className={Utils.loaderrors(this.state.errors, 'correo')}
                        onChange={(val) => {
                          this.setState({ correo: val.target.value });
                        }}
                        id="correo" placeholder="Correo" size="lg" />
                    </Form.Group>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <button type="button"
            className="btn btn-success btn-lg"
            style={{ margin: '5px' }}
            onClick={this.createemployee}
          >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button>
          <Link to={this.state.prevPath} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
        </form>
        {/* LO QUE IMPORTA ES LO QUE ESTA ARRIBA DE ESTE COMENTARIO, LO DE MAS ESTA SOLO PARA GUIA */}

        {/* FIN */}
      </div>
    );
  }
}

export default EmployeeEdith;
