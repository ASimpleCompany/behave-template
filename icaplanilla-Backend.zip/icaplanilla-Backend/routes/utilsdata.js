const express = require('express');
const {} = require('../controllers/utilsdata');

const router = express.Router();
router.route('/pendding').get(table);

module.exports = router;
