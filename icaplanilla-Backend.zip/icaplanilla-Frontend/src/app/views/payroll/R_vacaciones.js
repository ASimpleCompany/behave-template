import React, { Component } from "react";
import { Form } from "react-bootstrap";
import { Link } from "react-router-dom";
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider from "react-bootstrap-table2-toolkit";
import "react-confirm-alert/src/react-confirm-alert.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";

const SearchBar = (props) => {
  let input;
  return (
    <div>
      <Form.Group>
        <Form.Control
          type="text"
          ref={(n) => (input = n)}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};

export default class R_planillas extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nominadata: [],
      listapayroll: [],
      departmentdata: [],
      listaano: [],
      issubmitting: true,
      show: false,
      ano: 0,
      id_departamento: 0,
      id_codigoplanilla: 0,
      carga_marcacion: false,
      marcacion_inicio: "",
      marcacion_fin: "",
    };
  }

  columns = [
    {
      dataField: 'estado_nomina', text: 'Estado Vacación', sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(row.id_estado, row.estado);
      },
      headerStyle: (colum, colIndex) => {return { width: '130px', textAlign: 'center' }}

    },
    {
      dataField: 'estado_nomina', text: 'Estado Pago', sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(row.id_estado_nomina, row.estado_nomina);
      }
    },
    {dataField: "nombre",text: "Colaborador",sort: true,      headerStyle: (colum, colIndex) => {return { width: '200px', textAlign: 'center' };}},
    {dataField: "cantidaddias",text: "Cant. de Días",sort: true},
    {dataField: "fecha_inicio",text: "Inicio",sort: true},
    {dataField: "fecha_retorno",text: "Retorno",sort: true},
    {dataField: 'monto_nomina', text: 'Monto', align: 'right', sort: true, formatter: (cell, row) => { return parseFloat(cell).toFixed(2); } },
    {dataField: 'total_pagar', text: 'Total a Pagar', align: 'right', sort: true, formatter: (cell, row) => { return parseFloat(cell).toFixed(2); } },
    {
      dataField: "id_vacaciones",
      text: "Detalle",
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            {row.id_estado_nomina === 7 || row.id_estado_nomina ===6?
            <Link
                to={"/payroll/reports/vacaciones/detalle/" + row.id_nomina}
                className="btn btn-success p-1 m-1"
            >
              <i className="fa fa-eye" />
            </Link>:null}

            {row.id_estado_nomina === 0 ? <button
                onClick={() => this.adddata(cell)}
                className="btn btn-success p-1 m-1"
            >
              <i className="fa fa-mail-forward" />
            </button> : null}
          </div>
        );
      },
    },
  ];

  tableoptions = {
    paginationPosition: "bottom",
  };

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let nominadata = await RequestService.get('payroll/vacations', null);
      this.setState({ nominadata: nominadata.data });
      this.setState({ issubmitting: false});
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Reportes de Vacaciones </h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link to="/payroll" role="button">
                  Planillas
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                Reportes {">"} Vacaciones
              </li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id_vacaciones"
                  data={this.state.nominadata}
                  columns={this.columns}
                  search
                  loading={true}
                >
                  {(props) => (
                    <div className={"row"}>
                      <div className="col-lg-4">
                        <SearchBar
                          {...props.searchProps}
                          className="form-control"
                        />
                      </div>
                      <hr />
                      <BootstrapTable
                        noDataIndication={
                          "No se encontraron registros para mostrar."
                        }
                        pagination={paginationFactory({
                          hideSizePerPage: true,
                          pageListRenderer: false,
                        })}
                        {...props.baseProps}
                      />
                    </div>
                  )}
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
