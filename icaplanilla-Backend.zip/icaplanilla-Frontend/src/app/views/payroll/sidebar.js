import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import { Collapse } from "react-bootstrap";
import { Dropdown } from "react-bootstrap";
import Cookies from "universal-cookie";
const cookies = new Cookies();

class Sidebar extends Component {
  state = {};

  toggleMenuState(menuState) {
    if (this.state[menuState]) {
      this.setState({ [menuState]: false });
    } else if (Object.keys(this.state).length === 0) {
      this.setState({ [menuState]: true });
    } else {
      Object.keys(this.state).forEach((i) => {
        this.setState({ [i]: false });
      });
      this.setState({ [menuState]: true });
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }
  }

  onRouteChanged() {
    document.querySelector("#sidebar").classList.remove("active");
    Object.keys(this.state).forEach((i) => {
      this.setState({ [i]: false });
    });

    const dropdownPaths = [
      { path: "/basic-ui", state: "basicUiMenuOpen" },
      { path: "/form-elements", state: "formElementsMenuOpen" },
      { path: "/tables", state: "tablesMenuOpen" },
      { path: "/icons", state: "iconsMenuOpen" },
      { path: "/charts", state: "chartsMenuOpen" },
      { path: "/user-pages", state: "userPagesMenuOpen" },
    ];

    dropdownPaths.forEach((obj) => {
      if (this.isPathActive(obj.path)) {
        this.setState({ [obj.state]: true });
      }
    });
  }

  render() {
    return (

      <nav className="sidebar sidebar-offcanvas" id="sidebar">

        <ul className="nav">
          <li className="nav-item nav-profile not-navigation-link">
            <div className="nav-link">
              
            <br></br>
              <br></br>
              
              <Dropdown>

                <Dropdown.Toggle className="nav-link user-switch-dropdown-toggler p-0 toggle-arrow-hide bg-transparent border-0 w-100">
                  <div className="d-flex justify-content-between align-items-start">
                    <div className="profile-image">
                      <img
                        src={require("../../../assets/images/face-clipart.png")}
                        alt="profile"
                      />
                    </div>

                    <div className="text-left ml-3">
                      <p className="profile-name text-capitalize">
                        {cookies.get("nombre") + " " + cookies.get("apellido")}
                      </p>
                      <small className="designation text-muted text-small text-capitalize">
                        {cookies.get("descrol")}
                      </small>
                      <span className="status-indicator online"/>
                    </div>
                  </div>
                </Dropdown.Toggle>
              </Dropdown>

            </div>
          </li>

          <li
            className={
              this.isPathActive("/tables") ? "nav-item active" : "nav-item"
            }
          >
            <Link className="nav-link" to="/payroll">
              <i className="fa fa-home menu-icon"></i>
              <span className="menu-title">Inicio</span>
            </Link>
          </li>

          <li
            className={
              this.isPathActive("/basic-ui") ? "nav-item active" : "nav-item"
            }
          >
            <div
              className={
                this.state.basicUiMenuOpen
                  ? "nav-link menu-expanded"
                  : "nav-link"
              }
              onClick={() => this.toggleMenuState("basicUiMenuOpen")}
              data-toggle="collapse"
            >
              <i className="mdi mdi-note-multiple-outline menu-icon"></i>
              <span className="menu-title">Gestión de Planillas</span>
              <i className="menu-arrow"></i>
            </div>

            <Collapse in={this.state.basicUiMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/buttons")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/first/planillas"
                  >
                    Administrar Planillas
                  </Link>
                </li>
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/buttons")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/second/Dtercermes"
                  >
                    Décimo Tercer Mes
                  </Link>
                </li>
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/typography")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/third/vacaciones"
                  >
                    Vacaciones
                  </Link>
                </li>
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/typography")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/fourth/liquidaciones"
                  >
                    Liquidaciones
                  </Link>
                </li>
              </ul>
            </Collapse>
          </li>

          <li
            className={
              this.isPathActive("/reportes") ? "nav-item active" : "nav-item"
            }
          >
            <div
              className={
                this.state.reportes ? "nav-link menu-expanded" : "nav-link"
              }
              onClick={() => this.toggleMenuState("reportes")}
              data-toggle="collapse"
            >
              <i className="mdi mdi-clipboard-text menu-icon"></i>
              <span className="menu-title">Reportes</span>
              <i className="menu-arrow"></i>
            </div>

            <Collapse in={this.state.reportes}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/dropdowns")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/reports/planilla03"
                  >
                    Planilla 03
                  </Link>
                </li>

                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/buttons")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/reports/planillas"
                  >
                    Planillas
                  </Link>
                </li>
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/buttons")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/reports/Dtercermes"
                  >
                    Décimo Tercer Mes
                  </Link>
                </li>
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/typography")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/reports/vacaciones"
                  >
                    Vacaciones
                  </Link>
                </li>
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/typography")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/reports/r_liquidacion"
                  >
                    Liquidaciones
                  </Link>
                </li>
              </ul>
            </Collapse>
          </li>

          <li
            className={
              this.isPathActive("/reportes") ? "nav-item active" : "nav-item"
            }
          >
            <div
              className={
                this.state.descuentos ? "nav-link menu-expanded" : "nav-link"
              }
              onClick={() => this.toggleMenuState("descuentos")}
              data-toggle="collapse"
            >
              <i className="fa fa-percent menu-icon"></i>
              <span className="menu-title">Descuentos</span>
              <i className="menu-arrow"></i>
            </div>

            <Collapse in={this.state.descuentos}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item">
                  {" "}
                  <Link
                    className={
                      this.isPathActive("/basic-ui/typography")
                        ? "nav-link active"
                        : "nav-link"
                    }
                    to="/payroll/descuento/descuentosF"
                  >
                    Descuentos Fijos
                  </Link>
                </li>
              </ul>
            </Collapse>
          </li>

          <li
            className={
              this.isPathActive("/tables") ? "nav-item active" : "nav-item"
            }
          >
            <Link className="nav-link" to="/payroll/Attedance">
              <i className="mdi mdi-calendar-clock menu-icon"></i>
              <span className="menu-title">Marcaciones</span>
            </Link>
          </li>

          <li
            className={
              this.isPathActive("/icons") ? "nav-item active" : "nav-item"
            }
          >
          </li>
        </ul>
      </nav>
    );
  }

  isPathActive(path) {
    return this.props.location.pathname === path;
  }

  componentDidMount() {
    this.onRouteChanged();
    // add className 'hover-open' to sidebar navitem while hover in sidebar-icon-only menu
    const body = document.querySelector("body");
    document.querySelectorAll(".sidebar .nav-item").forEach((el) => {
      el.addEventListener("mouseover", function () {
        if (body.classList.contains("sidebar-icon-only")) {
          el.classList.add("hover-open");
        }
      });
      el.addEventListener("mouseout", function () {
        if (body.classList.contains("sidebar-icon-only")) {
          el.classList.remove("hover-open");
        }
      });
    });
  }
}

export default withRouter(Sidebar);
