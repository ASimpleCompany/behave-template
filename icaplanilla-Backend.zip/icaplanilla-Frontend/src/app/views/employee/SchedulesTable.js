import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import { Link } from "react-router-dom";
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';

import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';

const SearchBar = (props) => {
  let input;
  const handleClick = () => {
    props.onSearch(input.value);
  };
  return (
    <div>
      <Form.Group>
        <Form.Control
          type="text"
          ref={(n) => (input = n)}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};

class ScheduleTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userdata: [],
      issubmitting: true,
    };
  }

  columns = [
    {
      dataField: "descripcion",
      text: "Nombre",
      sort: true,
      headerStyle: (colum, colIndex) => {return { width: '500px', textAlign: 'center' };}
    },
    {
      dataField: "total_horas_diarias",
      text: "Total de Horas",
      sort: true,
    },
    {
      dataField: "id_horario",
      text: "Detalle",
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            <Link
              style={{ "marginLeft": "10px" }}
              to={"/employee/schedule/" + cell}
              className="btn btn-success"
            >
              <i className="fa fa-edit"></i>
            </Link>
            <button
              style={{ "marginLeft": "10px" }}
              onClick={() => this.delete(cell)}
              className="btn btn-danger"
            >
              <i className="fa fa-eraser"></i>
            </button>
          </div>
        );
      },
    },
  ];

  tableoptions = {
    paginationPosition: "bottom",
  };

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get("schedule/", null);
      this.setState({ userdata: mydata.data, issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      console.log(e);
      toastr.error(
        "Los datos no pudieron ser consultados.",
        "Intente de nuevo"
      );
    }
  }

  async getone(id) {
    try {
      this.setState({ issubmitting: true });
      let mydata = await RequestService.get("schedule/" + id, null);
      console.log(mydata);
      this.setState({
        descripcion: mydata.data[0].descripcion,
        typefunction: "Actualizar",
        id_departamento: mydata.data[0].id_departamento,
        issubmitting: false,
        show: true,
      });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error(
        "Los datos no pudieron ser consultados.",
        "Intente de nuevo"
      );
    }
  }

  async adddata() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append("descripcion", this.state.descripcion);
      await RequestService.post("schedule/", form);
      toastr.success("Departamento Creado");
      this.setState({ descripcion: "" });
      this.getdata();
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error(
        "Los datos no pudieron ser consultados.",
        "Intente de nuevo"
      );
    }
  }

  async updatedata() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append("descripcion", this.state.descripcion);
      await RequestService.put("schedule/" + this.state.id_departamento, form);
      toastr.success("Departamento Actualizado");
      this.setState({ descripcion: "" });
      this.getdata();
    } catch (e) {
      toastr.error(
        "Los datos no pudieron ser consultados.",
        "Intente de nuevo"
      );
      this.setState({ issubmitting: false });
    }
  }

  delete(deleteid) {
    confirmAlert({
      title: "Eliminar",
      message: "¿Seguro desea eliminar?",
      buttons: [
        {
          label: "Si",
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              await RequestService.delete("schedule/" + deleteid, null);
              toastr.success("Horario eliminado");
              await this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                "Los datos no pudieron ser eliminados.",
                "Intente de nuevo"
              );
            }
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  }

  render() {
    const selectRow = {
      mode: "checkbox",
      bgColor: "pink",
      className: "my-selection-custom",
    };

    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Lista de Horarios </h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Horarios</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id_departamento"
                  data={this.state.userdata}
                  columns={this.columns}
                  search
                  loading={true}
                >
                  {(props) => (
                    <div className={"row"}>
                      <div className="col-lg-8">
                        <Link
                          to={"/employee/schedule/new"}
                          type="button"
                          className="btn btn-success"
                          style={{ height: "45px", padding: "14px" }}
                        >
                          Agregar{" "}
                        </Link>
                      </div>
                      <div className="col-lg-4">
                        <SearchBar
                          {...props.searchProps}
                          className="form-control"
                        />
                      </div>
                      <hr />
                      <BootstrapTable
                        noDataIndication={"No se encontraron registros para mostrar."}
                        pagination={paginationFactory({
                          hideSizePerPage: true,
                          pageListRenderer: false,
                        })}
                        {...props.baseProps}
                      />
                    </div>
                  )}
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ScheduleTable;
