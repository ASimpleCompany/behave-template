import React, { Component } from 'react';
import { Button, Form, Modal } from 'react-bootstrap';
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import { Link } from "react-router-dom";
import toastr from "toastr";
import BootstrapTable from 'react-bootstrap-table-next';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';

class DecimoEmployeeDetalle extends Component {
  constructor(props) {
    super(props);
    this.state = {
      planilladata: [],
      listadescuentos: [],
      salario_mensual_pactado: 0,
      salario_quincenal_neto: 0,
      total_descuentos: 0,
      total_ingresos: 0,
      carga_marcacion: true,
      issubmitting: true,
      id_tipo_descuento: 0,
      id_planilla: 0,
      show: false,
      showdetail: false,
      debitos: [],
      creditos: []
    };

    this.modalclose = this.modalclose.bind(this);
    this.handleShow = this.handleShow.bind(this);
    this.delete = this.delete.bind(this);
    this.adddata = this.adddata.bind(this);
    this.update = this.update.bind(this);

  }

  columnscrdr = [
    {
      dataField: "descripcion",
      text: "Descripcion",
      sort: true,
      footer: 'Totales',
      editable: false
    },
    {
      dataField: "monto",
      text: "Monto",
      sort: true,
      align: 'right',
      formatter: (cell, row) => { return parseFloat(cell).toFixed(2); },
      footerAlign: (column, colIndex) => 'right',
      footer: columnData => columnData.reduce((acc, item) => parseFloat(acc) + parseFloat(item), 0).toFixed(2),
    },
    {
      dataField: "id_descuento_realizado",
      text: "Editar",
      sort: true,
      footer: 'Detalle',
      headerStyle: (colum, colIndex) => {
        return { width: '100px', textAlign: 'center' };
      },
      formatter: (cell, row) => {
        return (
          <div>
            {this.state.id_estado === 7 && !Utils.legaldiscounts.includes(parseInt(row.id_tipo_descuento)) ?
                <div><button type="button" onClick={() => this.handleShow(row.id_descuento_realizado)} className="btn btn-success p-1 m-1"><i className="fa fa-edit" /></button>
                  <button type="button" onClick={() => this.delete(cell)} className="btn btn-danger p-1 m-1"> <i className="fa fa-eraser" /></button></div>
                : null}
          </div>
        );
      },
    },
  ]

  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      let id = this.props.match.params.id;
      this.setState({ issubmitting: true });
      let planilla = await RequestService.get('payroll/detailpayroll/' + id, null);
      let datosdetalle = await RequestService.get('payroll/employee/' + id, null);
      let nomina = await RequestService.get('payroll/nomina/' + planilla.data[0].id_nomina, null);

      if (this.state.listadescuentos.length === 0) {
        let listadescuentos = await RequestService.get('detailpayroll/list', null);
        this.setState({ listadescuentos: listadescuentos.data });
      }
      let dr = [], cr = [];
      planilla.data.forEach(element => {
        if (element.crdr === 'CR') {
          cr.push(element);
        } else {
          dr.push(element);
        }
      });

      this.setState(nomina.data[0]);
      this.setState(datosdetalle.data[0]);
      this.setState({ detalle_planilla: planilla.data, debitos: dr, creditos: cr });
      this.setState({ issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async adddata() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append("monto", this.state.monto);
      form.append("id_tipo_descuento", this.state.id_tipo_descuento);
      form.append("id_empleado", this.state.id_empleado);
      form.append("id_codigoplanilla", this.state.id_codigoplanilla);
      form.append("id_planilla", this.state.id_planilla);
      form.append("id_nomina", this.state.id_nomina);
      if (this.state.id_descuento_realizado === 0) {
        await RequestService.post("detailpayroll/", form);
      } else {
        await RequestService.put("detailpayroll/" + this.state.id_descuento_realizado, form);
      }
      toastr.success("Detalle actualizado");
      this.setState({ id_tipo_descuento: 0, monto: 0, id_descuento_realizado: 0, show: false });
      this.getdata();
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error(
        "Los datos no pudieron ser consultados.",
        "Intente de nuevo"
      );
    }
  }

  async update() {
    try {
      this.setState({ issubmitting: true });
      let form = new FormData();
      form.append("comentario", this.state.observaciones);
      form.append("tabla", 'p');
      await RequestService.put("payroll/comment/" + this.state.id_planilla, form);
      toastr.success("Comentario Guardado");
      this.setState({ descripcion: "" });
      this.getdata();
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error(
        "Los datos no pudieron ser actualizados.",
        "Intente de nuevo"
      );
    }
  }

  async delete(id) {
    confirmAlert({
      title: 'Eliminar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let form = new FormData();
              await RequestService.delete("detailpayroll/" + id, form);
              toastr.success("Eliminado");
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                "Los datos no pudieron ser consultados.",
                "Intente de nuevo"
              );
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }

  lista() {
    let data = this.state.listadescuentos.map((value, index) => {
      return <option value={value.id_tipo_descuento}>{value.crdr + '-' + value.descripcion}</option>
    });
    data.unshift(<option value={0}>--------</option>);
    return data;
  }


  modalclose() {
    this.setState({ show: false });
  }

  async handleShow(id = 0) {
    if (id !== 0) {
      try {
        this.setState({ issubmitting: true });
        let planilla = await RequestService.get('detailpayroll/' + id, null);
        this.setState(planilla.data[0]);
        this.setState({ issubmitting: false });
      } catch (e) {
        this.setState({ issubmitting: false });
        toastr.error('Los datos no pudieron ser consultados.');
      }
    }
    this.setState({ show: true, id_descuento_realizado: id });
  }


  render() {

    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Detalle Por Colaborador</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link to="/payroll" role="button">Planillas</Link></li>
              <li className="breadcrumb-item">
                <Link to="/payroll/first/planillas" role="button">Generar Planillas</Link></li>
              <li className="breadcrumb-item">
                <Link to={'/payroll/planillas/' + this.state.id_nomina} role="button">Detalle de Planilla</Link></li>
              <li className="breadcrumb-item active" aria-current="page">Editar</li>
            </ol>
          </nav>
        </div>


        <Modal show={this.state.show} onHide={this.modalclose}>
          <Modal.Header closeButton>
            <Modal.Title>Descuentos/Ingresos:</Modal.Title>
          </Modal.Header>
          <Modal.Body className={'row'}>
            <div className={'col-lg-12'}>
              <Form.Group>
                <label htmlFor="id_ocupacion">Opciones:</label>
                <select
                  value={this.state.id_tipo_descuento}
                  className={"form-control " + Utils.loaderrors(this.state.errors, 'id_tipo_descuento')}
                  onChange={(val) => {
                    this.setState({ id_tipo_descuento: val.target.value });
                  }}
                  disabled={this.state.id_estado !== 7}
                  size="lg"
                  id="ocupacion">
                  {this.lista()}
                </select>
              </Form.Group>
            </div>
            <div className={'col-lg-12'}>
              <Form.Group>
                <label htmlFor="marcacion_fin">Monto:</label>
                {this.state.id_estado === 7 ? <Form.Control type="number"
                  value={this.state.monto}
                  className={"form-control " + Utils.loaderrors(this.state.errors, 'monto')}
                  onChange={(val) => {
                    this.setState({ monto: val.target.value });
                  }}
                  id="monto" placeholder="Monto" size="lg" /> : <div>{this.state.monto}</div>}
              </Form.Group>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.modalclose}>
              Cerrar
              </Button>
            <Button variant="primary" onClick={this.adddata}>
              Guardar
              </Button>
          </Modal.Footer>
        </Modal>

        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="row">
                  <div className="col-lg-12">
                    <div className="row">
                      <div className="col">
                        <h2>Colaborador: {this.state.nombre} </h2>
                      </div>
                      <div className="col-lg-2">
                        <button type="button" onClick={() => this.props.history.goBack()} className="btn btn-secondary mr-10">Regresar</button>
                      </div>
                    </div>
                  </div>
                </div>
                <hr />
                <div className="row">
                  <div className={'col-lg-3'}>
                    <Form.Group>
                      <div htmlFor="marcacion_fin">Salario Mensual Pactado:</div>
                      <h4><strong>${parseFloat(this.state.salario_mensual_pactado).toFixed(2)}</strong></h4>
                    </Form.Group>
                  </div>
                  <div className={'col-lg-2'}>
                    <Form.Group>
                      <div htmlFor="marcacion_fin">Esta Quincena:</div>
                      <h4><strong>${parseFloat(this.state.salario_quincenal_neto).toFixed(2)}</strong></h4>
                    </Form.Group>
                  </div>

                  <div className={'col-lg-2'}>
                    <Form.Group>
                      <div htmlFor="marcacion_fin">Total Deducciones:</div>
                      <h4><strong>${parseFloat(this.state.total_descuentos).toFixed(2)}</strong></h4>
                    </Form.Group>
                  </div>
                  <div className={'col-lg-2'}>
                    <Form.Group>
                      <div htmlFor="marcacion_fin">Total a Pagar:</div>
                      <h4><strong>${parseFloat(this.state.neto_a_pagar).toFixed(2)}</strong></h4>
                    </Form.Group>
                  </div>
                  <div className={'col-lg-6'}>
                    <Form.Group>
                      <label htmlFor="observaciones">Comentario:</label>
                      <textarea name={'observaciones'}
                        rows="4"
                        disabled={this.state.id_estado !== 7}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'observaciones')}
                        value={this.state.observaciones}
                        onChange={(val) => {
                          this.setState({ observaciones: val.target.value });
                        }} />
                    </Form.Group>
                    {this.state.id_estado === 7 ? <button type="button" onClick={() => {
                      this.update()
                    }} className="btn btn-primary mb-2 "> Guardar </button> : null}
                  </div>
                </div>
                <hr />

                <div className="row">
                  <div className={'col-lg-12'}>
                    {/* <button type="button" onClick={()=> {
                        this.handleShow()
                      }} className="btn btn-success mb-2">Agregar Descuentos</button> */}
                  </div>

                  <div className={'col-lg-6 stretch-card'}>
                    <div className="card">
                      <div className="card-body">
                        <h4>Ingresos</h4>
                        <BootstrapTable
                          noDataIndication={"No se encontraron registros para mostrar."}
                          keyField="id_descuento_realizado"
                          data={this.state.creditos}
                          columns={this.columnscrdr}
                          loading={true}
                        />
                      </div>
                    </div>
                  </div>
                  <div className={'col-lg-6'}>
                    <div className="card">
                      <div className="card-body">
                        <h4>Deducciones</h4>
                        <BootstrapTable
                            noDataIndication={"No se encontraron registros para mostrar."}
                            keyField="id_descuento_realizado"
                            data={this.state.debitos}
                            columns={this.columnscrdr}
                            loading={true}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default DecimoEmployeeDetalle;
