import {observable,computed,action } from "mobx"
import jwt_decode from "jwt-decode";
import Cookies from 'universal-cookie';

const cookies = new Cookies();

class User {
    @observable userlogin ={
        name:'',
        apellido:'',
        rolid:0,
        roldes:''
    };

    @computed get gettoken(){
        return cookies.get('access');
    }

    @computed get getroll(){
        let rol = cookies.get('id_rol');
        return parseInt(rol);
    }

    @computed get isloged(){
        try{
            let returnme=false;
            let decoded = jwt_decode(cookies.get('access'));
            if (decoded){
                returnme = true;
            }
            if (Date.now() <= decoded.exp * 2000) {
                returnme=true;
            }
            return returnme;
        }catch(e){
            return false;
        }
    }

    @action async set_userdata  (data) {
        this.userlogin=data;
    }

    @action async login  (datalog) {
        cookies.set('access', JSON.stringify(datalog.data.access), { path: '/',expires: new Date(Date.now()+(2592000*5))});
        cookies.set('refresh', JSON.stringify(datalog.data.refresh), { path: '/',expires: new Date(Date.now()+(2592000*5))});
        let decoded = jwt_decode(cookies.get('access'));
        cookies.set('nombre', decoded.nombre);
        cookies.set('apellido', decoded.apellido);
        cookies.set('descrol', decoded.descrol);
        cookies.set('id_rol', decoded.id_rol);
        this.userlogin=datalog;
    }

    @action async logout  () {
        await cookies.remove('access');
        await cookies.remove('refresh');
        await cookies.remove('nombre');
        await cookies.remove('apellido');
        await cookies.remove('descrol');
        await cookies.remove('id_rol');
    }
    
}

export default new User();
