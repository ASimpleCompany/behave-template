import React, { Component } from 'react';
import { Button, Form, Modal } from 'react-bootstrap';
import { Link } from "react-router-dom";
import RequestService from "../../../services/RequestService";
import Utils from "../../../services/Utils";
import toastr from "toastr";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import 'react-confirm-alert/src/react-confirm-alert.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import moment from "moment";
import { confirmAlert } from "react-confirm-alert";

const SearchBar = (props) => {
  let input;
  return (
    <div>
      <Form.Group>
        <Form.Control
          type="text"
          ref={(n) => (input = n)}
          placeholder="Buscar"
          size="lg"
          onChange={() => {
            props.onSearch(input.value);
          }}
        />
      </Form.Group>
    </div>
  );
};

class Liquidaciones extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nominadata: [],
      listapayroll: [],
      departmentdata: [],
      listaano: [],
      issubmitting: true,
      show: false,
      ano: 0,
      id_departamento: 0,
      id_codigoplanilla: 0,
      carga_marcacion: false,
      marcacion_inicio: '',
      marcacion_fin: ''
    };
    this.delete = this.delete.bind(this);
  }

  columns = [
    {dataField: 'estadonomina', text: 'Estado Pago', sort: true,formatter: (cell, row) => {return Utils.showstatus(row.idestadonomina, row.estadonomina);}},
    {
      dataField: "nombre",
      text: "Planilla",
      sort: true,
      headerStyle: (colum, colIndex) => {
        return { width: '250px', textAlign: 'center' };
      }
    },
    {dataField: "departamento",text: "Departamento", sort: true, },
    {dataField: "fecha_inicio_labores",text: "Fecha de Inicio",sort: true},
    {dataField: "fecha_culmina",text: "Fecha Culmina",sort: true},
    {dataField: "finaliza",text: "Tipo",sort: true,
    headerStyle: (colum, colIndex) => {
      return { width: '250px', textAlign: 'center' };
    }},
    {dataField: "id_contrato",text: "Detalle",sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            <Link
              style={{ "marginLeft": "10px" }}
              to={"/payroll/fourth/liquidaciones/" + cell}
              className="btn btn-success"
            >
              <i className="fa fa-edit" />
            </Link>
            {row.id_estado === 7 ? <button
              style={{ "marginLeft": "10px" }}
              onClick={() => this.delete(cell)}
              className="btn btn-danger"
            >
              <i className="fa fa-eraser" />
            </button> : null}
          </div>
        );
      },
    },
  ];


  componentDidMount() {
    this.getdata();
  }

  async getdata() {
    try {
      let listaano = [{ 'ano': moment().year() }, { 'ano': moment().year() - 1 }];
      this.setState({ issubmitting: true });
      let nominadata = await RequestService.get('payroll/end', null);
      console.log(nominadata);
      this.setState({ nominadata: nominadata.data });
      this.setState({ ano: moment().year(), listaano: listaano, issubmitting: false});
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.');
    }
  }

  async delete(id) {
    confirmAlert({
      title: 'Eliminar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let form = new FormData();
              await RequestService.delete("payroll/nomina/" + id, form);
              toastr.success("Eliminado");
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error(
                "Los datos no pudieron ser consultados.",
                "Intente de nuevo"
              );
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }


  render() {

    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Liquidaciones</h1>
          <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/payroll"
                  role="button">Planillas
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Gestión de Planillas {'>'} Liquidaciones</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <ToolkitProvider
                  keyField="id_codigoplanilla"
                  data={this.state.nominadata}
                  columns={this.columns}
                  search
                  loading={true}
                >
                  {(props) => (
                    <div className={"row"}>
                      <div className="col-lg-8">
                      </div>
                      <div className="col-lg-4">
                        <SearchBar
                          {...props.searchProps}
                          className="form-control"
                        />
                      </div>
                      <hr />
                      <BootstrapTable
                        noDataIndication={"No se encontraron registros para mostrar."}
                        pagination={paginationFactory({
                          hideSizePerPage: true,
                          pageListRenderer: false,
                        })}
                        {...props.baseProps}
                      />
                    </div>
                  )}
                </ToolkitProvider>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Liquidaciones;
