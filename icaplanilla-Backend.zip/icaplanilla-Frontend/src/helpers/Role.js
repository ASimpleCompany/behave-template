export const Role = {
    Admin: {
     permisos: [ 'Recurso-humano', 'Planilla' , 'Administracion']
    },
    Gestores: {
     functionality: ['Recurso-humano', 'Planilla']
    },
    Viewer: {
     functionality: [  '' , 'Planilla']
    }
}
let user = {
    Admin: 1,
    Gestor: 2,
    Viewer: 3
}

let functionalitys  = [ 
    {  recursoHumano: [ 'Colaboradores', 'Horarios', 'Departamentos'] },
    {  planilla: [  'Planillas' , 'Reportes', 'Descuentos' , 'Marcaciones' , 'Configuracion']},
    {  Adminitracion: [  'Usuarios' , 'Actividades Usuario' ]  }

]

function( user) {

}
