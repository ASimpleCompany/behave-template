import React, { Component } from 'react';
import { Link,/*useParams*/ } from "react-router-dom";
import RequestService from '../../../services/RequestService';
import toastr from "toastr";
import { observer } from "mobx-react";

@observer
class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate : new Date(),
      gotdata:false,
      actions: [ 
        {  title: 'Colaboradores' , descripcion: 'Agregar Colaboradores', icon: 'fa fa-address-book text-primary icon-md',  link:'/employee/table' },
        {  title: 'Horarios' , descripcion: 'Modificar Horarios', icon: 'fa fa-clock-o text-primary icon-md align-self-center',  link:'/employee/schedule/table' },
        {  title: 'Departamentos' , descripcion: 'Agregar Departamentos', icon: 'fa fa-th-large text-primary icon-md', link:'/employee/department/table' } 
      ]
    } 
  }

  componentDidMount(){
    this.getdata();
  }

  async getdata(){
    try{
      let mydata = await RequestService.get('employee/stats',null);
      let totales= mydata.data[0];
      this.setState(totales);
      this.setState({gotdata:true});
    }catch(e){
      toastr.error('Los datos no pudieron ser consultados.','Intente nuevamente');
    }
  }

  render() {
    const { actions } = this.state
    return (
      <div>  

        {/* Title */}
        <div className="row">
          <h2 className="p-3">Recursos Humanos</h2>
        </div>
        
        {/*KPI'S*/}
        <div className="row">
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="fa fa-group text-danger icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Colaboradores</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                      { this.state.gotdata ? this.state.totalemp:<i className="fa fa-spin fa-circle-o-notch"></i> }
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="fa fa-handshake-o text-warning icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Contratos</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        { this.state.gotdata ? this.state.totalcontra:<i className="fa fa-spin fa-circle-o-notch"></i> }
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="fa fa-list-alt text-success icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Horarios Creados</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        { this.state.gotdata ? this.state.tothorarios:<i className="fa fa-spin fa-circle-o-notch"></i> }
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
            <div className="card card-statistics">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="fa fa-building text-info icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <p className="mb-0 text-right text-dark">Total de Departamentos</p>
                    <div className="fluid-container">
                      <h3 className="font-weight-medium text-right mb-0 text-dark">
                        { this.state.gotdata ? this.state.totdeptos:<i className="fa fa-spin fa-circle-o-notch"></i> }
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>  

         {/*Main Functions*/}
         <div className="row">
          <h2 className="mx-auto p-4">¿Qué desea hacer hoy?</h2>
        </div>
         <div className="row">
          {actions.map((action) =>
            <Link className="col-md-4 grid-margin stretch-card streched-link text-decoration-none" to={action.link} role="button">
            <div className="card card-statistics">
              <div className="card-body py-5">
                <div className="d-flex flex-row justify-content-center align-items">
                  <i className={action.icon} ></i>
                  <div className="ml-3">
                       <h5 className="mb-0 text-right text-dark">{action.descripcion}</h5>
                  </div>
                </div>
              </div>
            </div>
            </Link> 
             )
          }
          </div>
      </div> 
    );
  }
}

export default Dashboard;