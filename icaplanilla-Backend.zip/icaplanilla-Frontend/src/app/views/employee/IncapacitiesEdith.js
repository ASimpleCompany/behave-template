import React, { Component,useState } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';
import moment from 'moment';

import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css';
import DatePicker from "react-datepicker/es";

export class IncapacitiesEdith extends Component {

  constructor(props) {
    super(props);
    this.state={
      id_empleado:0,
      id_contrato:0,
      listacontratos:[],
      listapayroll:[],
      listaano:[],
      fecha_incapacidad:'',
      fecha_culmina:'',
      codigo_incapacidad:'',
      descripcion:'',
      id_codigoplanilla:0,
      ano:0
    }
    this.update = this.update.bind(this);
  }

  componentDidMount(){
    let {id_empleado}=this.props.location.state;
    this.setState({id_empleado:id_empleado});
    this.getdata(id_empleado)
  }

  async getdata(id){
    try{
      let listaano=[{'ano':moment().year()},{'ano':moment().year()-1}];
      let idinca=this.props.match.params.id;
      this.setState({issubmitting:true});

      let constactlist = await RequestService.get('employee/constractlist/'+id,null);
      let availablepayroll = await RequestService.get('payroll/available/1',null);
      let dataincapacity = await RequestService.get('incapacities/'+idinca,null);

      await this.setState({
        ano: dataincapacity.data[0].ano,
        cantidad_empleado: dataincapacity.data[0].cantidad_empleado,
        cantidad_empleador: dataincapacity.data[0].cantidad_empleador,
        codigo_incapacidad: dataincapacity.data[0].codigo_incapacidad,
        descripcion: dataincapacity.data[0].descripcion,
        disponibles: dataincapacity.data[0].disponibles,
        estado: dataincapacity.data[0].estado,
        fecha_culmina: Utils.improveDate(dataincapacity.data[0].fecha_culmina),
        fecha_incapacidad: Utils.improveDate(dataincapacity.data[0].fecha_incapacidad),
        id_contrato: dataincapacity.data[0].id_contrato,
        id_empleado: dataincapacity.data[0].id_empleado,
        id_estado: dataincapacity.data[0].id_estado,
        id_incapacidad: dataincapacity.data[0].id_incapacidad
      });
      this.setState({id_contrato:constactlist.data[0].id_contrato,id_codigoplanilla:availablepayroll.data[0].id_codigoplanilla});
      this.setState({ano:moment().year(),listaano:listaano,listacontratos:constactlist.data,issubmitting:false,listapayroll:availablepayroll.data});

      this.getdatedif();
    }catch(e){
      
      this.setState({issubmitting:false});
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }
  
  
  getdatedif(){
    try{
      let a = moment(this.state.fecha_incapacidad);
      let b = moment(this.state.fecha_culmina);
      let cantidaddias=b.diff(a, 'days')+1;
      if (cantidaddias===0){
        cantidaddias=1;
      }else if ( cantidaddias<=0 ){
        cantidaddias=0;
      }
      this.setState({cantidaddias:cantidaddias });
    }catch(e){
      this.setState({cantidaddias:0 });
    }
  }

  async update(e){
    e.preventDefault()
    try{
      if(this.state.issubmitting){
        toastr.warning('La información se esta procesando.');
      }else{
        this.setState({issubmitting:true});
        let data= new FormData();
        let idinca=this.props.match.params.id;
        data.append('id_empleado',this.state.id_empleado);
        data.append('id_contrato',this.state.id_contrato);
        data.append('fecha_incapacidad', moment(this.state.fecha_incapacidad).format("YYYY-MM-DD"));
        data.append('fecha_culmina', moment(this.state.fecha_culmina).format("YYYY-MM-DD"));
        data.append('codigo_incapacidad',this.state.codigo_incapacidad);
        data.append('descripcion',this.state.descripcion);
        data.append('id_codigoplanilla',this.state.id_codigoplanilla);
        data.append('ano',this.state.ano);
        await RequestService.put('incapacities/'+idinca,data);
        toastr.success('Incapacidad Actualizada');
        this.setState({issubmitting:false});
       // this.props.history.push('/employee/'+this.state.id_empleado);
      }
    }catch(e){
      let rs = Utils.logerrors(e);
      console.log(e);
      this.setState({issubmitting:false,errors:rs});
    }
  }


  listacontrato() {
    let data = this.state.listacontratos.map((value, index) => {
      return <option value={value.id_contrato}>{value.descripcion}</option>
    });
    return data;
  }


  listaanos() {
    let data = this.state.listaano.map((value, index) => {
      return <option value={value.ano}>{value.ano}</option>
    });
    return data;
  }

  listapayroll() {
    let data = this.state.listapayroll.map((value, index) => {
      if(parseInt(this.state.ano)===parseInt(value.ano)){
        return <option value={value.id_codigoplanilla}>{value.descripcion}</option>
      }
    });
    return data;
  }

  async noaproveCommit(accion){
    confirmAlert({
      title: 'Actualizar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () =>{ 
            try{
              this.setState({issubmitting:true});
              let data = new FormData();
              data.append('accion',accion);
              let rs = await RequestService.put('incapacities/'+this.props.match.params.id+'/approve',data);
              console.log(rs);
              toastr.success('Actualizacion realizada');
              let {id_empleado}=this.props.location.state;
              this.getdata(id_empleado);
            }catch(e){
              this.setState({issubmitting:false});
              toastr.error('Los datos no pudieron ser actualizados.', 'Intente de nuevo');
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }


  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Editar Incapacidad</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
            <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to={'/employee/' + this.state.id_empleado}
                  role="button">Incapacidades
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Editar</li>
            </ol>
          </nav>        
        </div>
        <form className="forms-sample">
        <div className="row">
        {Utils.loading(this.state.issubmitting)}
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">

                  <Form.Group>
                    <label htmlFor="fecha_incapacidad">Fecha inicio de incapacidad:</label>
                    <br/>
                    <DatePicker
                        dateFormat="dd/MM/yyyy"
                        selected={this.state.fecha_incapacidad}
                        onChange={async (date) => {
                          await this.setState({ fecha_incapacidad: date });
                          this.getdatedif();
                        }}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_incapacidad')}
                        size="lg"
                    />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="fecha_culmina">Ultimo día de incapacidad:</label>
                    <br/>
                    <DatePicker
                        dateFormat="dd/MM/yyyy"
                        selected={this.state.fecha_culmina}
                        onChange={async (date) => {
                          await this.setState({ fecha_culmina: date });
                          this.getdatedif();
                        }}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_culmina')}
                        size="lg"
                    />
                  </Form.Group>
                  
                  <Form.Group>
                    <label htmlFor="cantidaddias">Cantidad de días:</label>
                    <Form.Control type="number"
                    value={this.state.cantidaddias}
                    disabled
                    className={"form-control " +Utils.loaderrors(this.state.errors,'cantidaddias')}

                    onChange={(val)=>{
                      this.setState({cantidaddias:val.target.value});
                    }}
                    id="cantidaddias" placeholder="00" />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="cantidaddias">Días pagados por empleador:</label>
                    <Form.Control type="number" className="form-control" 
                    
                    value={this.state.cantidad_empleador}
                    disabled
                    id="cantidad_empleador" placeholder="00" />
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="disponibles">Cantidad días disponible de colaborador:</label>
                    <Form.Control type="number" className="form-control" 
                    value={this.state.disponibles}
                    disabled
                    id="disponibles" placeholder="0" />
                  </Form.Group>
                  
                  {this.state.id_estado===7?
                  <button type="button" 
                          className="btn btn-success btn-lg" 
                          style={{margin:'5px'}}
                          onClick={this.update}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i>: "Guardar"}</button>:null} 

                 {this.state.id_estado===7?
                  <button type="button" 
                          className="btn btn-warning btn-lg" 
                          style={{margin:'5px'}}
                          onClick={()=>{this.noaproveCommit(true)}}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i>: "Aprobar"}</button>: null} 

                {this.state.id_estado===7?
                  <button type="button" 
                          className="btn btn-warning btn-lg" 
                          style={{margin:'5px'}}
                          onClick={()=>{this.noaproveCommit(false)}}
                  >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i>: "No Aprobar"}</button>: null} 

                  <Link to={'/employee/'+this.state.id_empleado} className="btn btn-secondary btn-lg" style={{margin:'5px'}}>Cancelar</Link>
                
              </div>
            </div>
          </div> 
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <Form.Group>
                  <label htmlFor="descripcion">Descripción</label>
                  <textarea className="form-control" id="descripcion" rows="4"
                   value={this.state.descripcion}
                   disabled={this.state.id_estado!==7}
                   className={"form-control " + Utils.loaderrors(this.state.errors,'descripcion')}
                   onChange={(val)=>{
                     this.setState({descripcion:val.target.value});
                   }}
                  ></textarea>
                </Form.Group>
                <Form.Group>
                    <label htmlFor="codigo_incapacidad">Código o número de incapacidad:</label>
                    <Form.Control type="text"
                    value={this.state.codigo_incapacidad}
                    disabled={this.state.id_estado!==7}
                    className={"form-control " + Utils.loaderrors(this.state.errors,'codigo_incapacidad')}
                    onChange={(val)=>{
                      this.setState({codigo_incapacidad:val.target.value});
                    }}
                    id="codigo_incapacidad" placeholder="" size="lg"/>
                </Form.Group>
                <Form.Group>
                    <label htmlFor="departamento">Contrato:</label>
                    <select
                      value={this.state.id_contrato}
                      disabled={this.state.id_estado!==7}
                      className={"form-control " + Utils.loaderrors(this.state.errors,'id_contrato')}
                      onChange={(val)=>{  
                        this.setState({id_contrato:val.target.value});
                      }}
                      size="lg"
                      id="departamento">
                      {this.listacontrato()}
                    </select>
                </Form.Group>
                <Form.Group>
                    <label htmlFor="ano">Año de incapacidad:</label>
                    <select
                      value={this.state.ano}
                      disabled={this.state.id_estado!==7}
                      className={"form-control " + Utils.loaderrors(this.state.errors,'ano')}
                      onChange={(val)=>{  
                        this.setState({ano:val.target.value});
                      }}
                      size="lg"
                      id="ano">
                      {this.listaanos()}
                    </select>
                </Form.Group>
                <Form.Group>
                  <label htmlFor="id_codigoplanilla">Correspondiente la planilla:</label>
                  <select
                    value={this.state.id_codigoplanilla}
                    disabled={this.state.id_estado!==7}
                    className={"form-control " + Utils.loaderrors(this.state.errors,'id_codigoplanilla')}
                    onChange={(val)=>{  
                      this.setState({id_codigoplanilla:val.target.value});
                    }}
                    size="lg"
                    id="id_codigoplanilla">
                    {this.listapayroll()}
                  </select>
                </Form.Group>
              </div>
            </div>
          </div>
          
        </div>
        </form>
      </div>
    )
  }
}

export default IncapacitiesEdith;
