import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import User from "../mobx/user";
import "./App.scss";
import AppRoutes from "./AppRoutes";
import Navbar from "./shared/Navbar";
import Sidebar from "./shared/Sidebar";
import Sidebarpayroll from "./views/payroll/sidebar";
import Footer from "./shared/Footer";
import Cookies from 'universal-cookie';
import RequestService from "../services/RequestService";
const cookies = new Cookies();

class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      userdata: '',
      sidebar: '',
      navbar: ''
    }
  }


  componentDidMount() {
    this.onRouteChanged();
    let current_path = window.location.href.endsWith('/login');
    if (!current_path) {
      this.getUserRole();
    }
  }


  async getUserRole() {

    try {

      let role = cookies.get('id_rol');
      let mydata = await RequestService.get('user/roles/' + role);
      this.setState({ userdata: mydata.data });
      this.setState({ sidebar: [mydata.data.sidebars[0]] });
      this.setState({ navbar: mydata.data.nav });

    } catch (e) {

      let current_path = window.location.href.endsWith('/login');
      if (!current_path) {
        User.logout();
        window.location.replace("/login");
      }

    }

  }

  componentDidUpdate(prevProps, data) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }
  }

  sidebar() {

    let otromenu = this.state.navbar ? this.state.navbar : [];
    let sidebarComponent = <Sidebar menu={otromenu} />;
    let path = window.location.pathname.split("/");
    if (path[1] === 'admin') {
      let sidemenu = this.state.sidebar[0].administracion
      sidebarComponent = <Sidebar menu={sidemenu} />;
    } else if (path[1] === 'employee') {
      let sidemenu = this.state.sidebar[0].recursohumano
      sidebarComponent = <Sidebar menu={sidemenu} />;
    } else if (path[1] === 'payroll') {
      sidebarComponent = <Sidebarpayroll />;
    }
    else if (this.state.isFullPageLayout) {
      sidebarComponent = "";
    }
    return sidebarComponent;
  }

  onRouteChanged() {
    window.scrollTo(0, 0);
    const fullPageLayoutRoutes = [
      "/login",
      "/login-2",
      "/register-1",
      "/register-2",
      "/lockscreen",
      "/error-404",
      "/error-500",
      "/landing-page",
    ];

    for (let i = 0; i < fullPageLayoutRoutes.length; i++) {
      if (this.props.location.pathname === fullPageLayoutRoutes[i]) {
        this.setState({
          isFullPageLayout: true,
        });
        document
          .querySelector(".page-body-wrapper")
          .classList.add("full-page-wrapper");
        break;
      } else {
        this.setState({
          isFullPageLayout: false,
        });
        document
          .querySelector(".page-body-wrapper")
          .classList.remove("full-page-wrapper");
      }
    }
  }

  render() {

    let navbarComponent = !this.state.isFullPageLayout ? <Navbar menu={this.state.navbar} /> : "";
    let footerComponent = !this.state.isFullPageLayout ? <Footer /> : "";
    return (
      <div className="container-scroller">
        {this.state.navbar !== '' ? navbarComponent : ''}
        <div className="container-fluid page-body-wrapper">
          {this.state.sidebar.length > 0 ? this.sidebar() : ''}
          <div className="main-panel">
            <div className="content-wrapper">
              <AppRoutes />
            </div>
            {footerComponent}
          </div>
        </div>
      </div>
    );
  }

}

export default withRouter(App);
