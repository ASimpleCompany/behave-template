import React, { Component } from "react";
import { Form } from "react-bootstrap";
import { Link } from 'react-router-dom';
import Utils from "../../../services/Utils"
import RequestService from '../../../services/RequestService';
import toastr from "toastr";
import DatePicker from "react-datepicker/es";
import moment from "moment";

export class ContractNew extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id_departamento: 0,
      id_ocupacion: 0,
      id_tipocontrato: 8,
      id_horario: 0,
      fecha_inicio_labores: new Date(),
      fecha_fin_labores: new Date(),
      departmentdata: [],
      horarios: [],
      ocupationdata: [],
      issubmitting: false,
      id_empleado: 0
    }
    this.createemployee = this.createemployee.bind(this);
    this.updatesalariohora=this.updatesalariohora.bind(this);
  }


  componentDidMount() {
    this.setState({ id_empleado: this.props.location.state.id_empleado });
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });

      let active = await RequestService.get('employee/activecontract/' + this.props.location.state.id_empleado, null);
      if (active.data[0].total === 0) {
        let mydepartment = await RequestService.get('department/', null);
        let myocupacion = await RequestService.get('ocupation/', null);
        let horarios = await RequestService.get('schedule/list/', null);
        this.setState({ id_departamento: mydepartment.data[0].id_departamento, id_ocupacion: myocupacion.data[0].id_ocupacion, id_horario: horarios.data[0].id_horario });
        this.setState({ departmentdata: mydepartment.data, ocupationdata: myocupacion.data, horarios: horarios.data, issubmitting: false });
      } else {
        toastr.warning('Colaborador cuenta con un contrato vigente');
        this.props.history.push('/employee/' + this.state.id_empleado);
      }
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.');
    }
  }

  async createemployee(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();

        data.append('id_empleado', this.state.id_empleado);

        data.append('fecha_inicio_labores', moment(this.state.fecha_inicio_labores).format("YYYY-MM-DD"));
        data.append('fecha_fin_labores', moment(this.state.fecha_fin_labores).format("YYYY-MM-DD"));
        data.append('id_tipocontrato', this.state.id_tipocontrato);

        data.append('ocupacion', this.state.id_ocupacion);
        data.append('departamento', this.state.id_departamento);

        data.append('id_horario', this.state.id_horario);

        data.append('monto_mensual', this.state.monto_mensual);
        data.append('monto_quincenal', this.state.monto_quincenal);
        data.append('monto_hora', this.state.monto_hora);

        await RequestService.post('contract/', data);
        toastr.success('Empleado Creado');
        this.setState({ issubmitting: false });
        this.props.history.push("/employee/" + this.state.id_empleado);
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }

  listadepartment() {
    return this.state.departmentdata.map((value, index) => {
      return <option value={value.id_departamento}>{value.descripcion}</option>
    });
  }

  listhorarios() {
    let data = this.state.horarios.map((value, index) => {
      return <option value={value.id_horario}>{value.descripcion}</option>
    });
    return data;
  }

  listocupation() {
    let data = this.state.ocupationdata.map((value, index) => {
      if (parseInt(this.state.id_departamento) === parseInt(value.id_departamento)) {
        return <option value={value.id_ocupacion}>{value.descripcion}</option>
      }
      return null;
    });
    data.unshift(<option value={0}>--------</option>);
    return data;
  }


  updatesalariohora(){
    try{
      //let montohora = (this.state.monto_mensual/4.3333)/this.state.hora_semana;
      let montoquin = this.state.monto_mensual/2;
      //this.setState({monto_hora:montohora.toFixed(5), monto_quincenal:montoquin});
      this.setState({monto_quincenal:montoquin});
    }catch(e){
      this.setState({monto_hora:0,monto_quincenal:0});
    }
  }

  handleChange = (date, type) => {
    console.log(`this is da current date ${date}`);
    if (type === "inicio") {
      this.setState({
        startDate: date,
      });
    } else {
      this.setState({
        endDate: date,
      });
    }
  };

  render() {
    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Agregar Contrato</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to={'/employee/' + this.state.id_empleado}
                  role="button">Contratos
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Agregar</li>
            </ol>
          </nav>
        </div>
        <form className="forms-sample">
          {Utils.loading(this.state.issubmitting)}

          <div className=" grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="mb-5">
                  <h1 className="page-title"><strong>Detalle del Contrato</strong></h1>
                </div>
                <div className="row">
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="id_tipocontrato">Tipo de contrato:</label>
                      <select
                        value={this.state.id_tipocontrato}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_tipocontrato')}
                        onChange={(val) => {
                          this.setState({ id_tipocontrato: val.target.value });
                        }}
                        size="lg"
                        id="id_tipocontrato">
                        <option value={8}>Indefinido</option>
                        <option value={9}>Definido</option>
                      </select>
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="fecha_inicio_labores">Fecha de Inicio:</label>
                      <br/>
                      <DatePicker
                          dateFormat="dd-MM-yyyy"
                          selected={this.state.fecha_inicio_labores}
                          onChange={(date) => {
                            this.setState({ fecha_inicio_labores: date });
                          }}
                          className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_inicio_labores')}
                          size="lg"
                      />
                    </Form.Group>
                  </div>
                  {this.state.id_tipocontrato == 9 ? <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="fecha_fin_labores">Fecha de Finaliza:</label>
                      <br/>
                      <DatePicker
                          dateFormat="dd/MM/yyyy"
                          selected={this.state.fecha_fin_labores}
                          onChange={(date) => {
                            this.setState({ fecha_fin_labores: date });
                          }}
                          className={"form-control " + Utils.loaderrors(this.state.errors, 'fecha_fin_labores')}
                          size="lg"
                      />
                    </Form.Group>
                  </div> : null}

                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="departamento">Departamento:</label>
                      <select
                        value={this.state.id_departamento}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_departamento')}
                        onChange={(val) => {
                          console.log(val.target.value);
                          this.setState({ id_departamento: val.target.value });
                        }}
                        size="lg"
                        id="departamento">
                        {this.listadepartment()}
                      </select>
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin">
                    <Form.Group>
                      <label htmlFor="id_ocupacion">Ocupación:</label>
                      <select
                        value={this.state.id_ocupacion}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_ocupacion')}
                        onChange={(val) => {
                          console.log(val.target.value);
                          this.setState({ id_ocupacion: val.target.value });
                        }}
                        size="lg"
                        id="ocupacion">
                        {this.listocupation()}
                      </select>
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin">
                    <Form.Group>
                      <label htmlFor="id_horario">Horario:</label>
                      <select
                        value={this.state.id_horario}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'id_horario')}
                        onChange={(val) => {
                          console.log(val.target.value);
                          this.setState({ id_horario: val.target.value });
                        }}
                        size="lg"
                        id="id_horario">
                        {this.listhorarios()}
                      </select>
                    </Form.Group>
                  </div>

                  <div className="col-4 grid-margin">
                    <Form.Group>
                        <label htmlFor="hora_semana">Horas Por Semana:</label>
                        <Form.Control type="text"
                        value={this.state.hora_semana}
                        className={"form-control "+Utils.loaderrors(this.state.errors, 'hora_semana')}
                        onChange={async (val) => {
                          await this.setState({ hora_semana: val.target.value });
                          this.updatesalariohora();
                        }}
                        id="hora_semana" placeholder="hora_semana" size="lg" />
                    </Form.Group>
                  </div>

                  


                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="monto_mensual">Salario Mensual:</label>
                      <Form.Control type="number"
                        value={this.state.monto_mensual}
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'monto_mensual')}
                        onChange={ async (val) => {
                          await this.setState({ monto_mensual: val.target.value });
                          /*this.updatesalariohora();*/
                        }}
                        id="monto_mensual" placeholder="0000.00" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4 grid-margin ">
                    <Form.Group>
                      <label htmlFor="monto_quincenal">Salario Quincenal:</label>
                      <Form.Control type="number"
                        value={this.state.monto_quincenal}
                        //disabled
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'monto_quincenal')}
                        onChange={(val) => {
                          this.setState({ monto_quincenal: val.target.value });
                        }}
                        id="monto_quincenal" placeholder="0000.00" size="lg" />
                    </Form.Group>
                  </div>
                  <div className="col-4">
                    <Form.Group>
                      <label htmlFor="monto_hora">Salario por Hora:</label>
                      <Form.Control type="number"
                        value={this.state.monto_hora}
                        //disabled
                        className={"form-control " + Utils.loaderrors(this.state.errors, 'monto_hora')}
                        onChange={(val) => {
                          this.setState({ monto_hora: val.target.value });
                        }}
                        id="monto_hora" placeholder="0000.00" size="lg" />
                    </Form.Group>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button type="button"
            className="btn btn-success btn-lg"
            style={{ margin: '5px' }}
            onClick={this.createemployee}
          >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button>
          <Link to={'/employee/' + this.state.id_empleado} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
        </form>
      </div>
    );
  }
}

export default ContractNew;
