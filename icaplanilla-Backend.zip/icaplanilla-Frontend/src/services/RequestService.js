import axios from 'axios';
import Cookies from 'universal-cookie';
const cookies = new Cookies();

class RequestService{
  url='http://localhost:5000/api/v1/';

  axiosinstance= axios.create({
    baseURL: this.url,
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + cookies.get('access')
    }
  });

  axiosinstanceFile = axios.create({
    baseURL: this.url,
    headers: {
      'Content-Type': 'multipart/form-data',
      'Authorization': 'Bearer ' + cookies.get('access')
    }
  });

  userLogin = async (username, password)=>{
      return await this.axiosinstance.post('auth/login', { username, password });
  }

  uploadFile = async (file , dayStart , dayEnd)=>{
    return await this.axiosinstanceFile.post('upload/attendance/',{ file , dayStart , dayEnd} );
  }

  get = async (endpoint, data)=>{
    this.axiosinstance.defaults.headers.get['Authorization'] = 'Bearer ' +cookies.get('access');
    return await this.axiosinstance.get(endpoint);
  }

  post = async (endpoint, data)=>{
    this.axiosinstance.defaults.headers.get['Authorization'] = 'Bearer ' +cookies.get('access');
    return await this.axiosinstance.post(endpoint, data);
  }

  put = async (endpoint, data)=>{
    this.axiosinstance.defaults.headers.get['Authorization'] = 'Bearer ' +cookies.get('access');
    return await this.axiosinstance.put(endpoint, data);
  }

  delete = async (endpoint, data)=>{
    this.axiosinstance.defaults.headers.get['Authorization'] = 'Bearer ' +cookies.get('access');
    return await this.axiosinstance.delete(endpoint, data);
  }

}

export default new RequestService();
