import React, { Component } from 'react';
import { Tabs, Tab, Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import Cookies from 'universal-cookie';
import SearchBar from '../../commons/SearchBar';

const cookies = new Cookies();


export class EmployeeDetail extends Component {

  constructor(props) {

    super(props);
    var current_tab;

    if (this.props.match.params.tab) {
      current_tab = this.props.match.params.tab;
      cookies.set('tabname', current_tab);
    } else if (typeof (cookies.get('tabname')) != 'undefined') {
      current_tab = cookies.get('tabname');
    } else {
      current_tab = 'generales';
    }

    this.state = {
      num_colaborador: '', nombre: '', apellido: '', genero: '',
      cedula: '', seguro_social: '', correo: '', estado: 0, id_departamento: 0,
      id_ocupacion: 0, fecha_nacimiento: '', telefono: '', apellido_casada: '',
      tipocon: '', salario: '', antiguedad: '', incapacidades: 0,vacationsadvance:[],
      departmentdata: [], ocupationdata: [], contracts: [], incapacity: [], compromiso: [], vacations: [],absents: [],
      issubmitting: false, key: current_tab
    }
  }

  columnscontrato = [
    {
      dataField: 'estado', text: 'Estado', sort: true,
      formatter: (cell, row) => {return Utils.showstatus(row.id_estado, row.estado);}
    },
    { dataField: 'fecha_creacion', text: 'Fecha de Creación', sort: true },
    { dataField: 'fecha_inicio_labores', text: 'Inicio de Labores', sort: true },
    { dataField: 'fecha_fin_labores', text: 'Fin de Labores', sort: true },
    { dataField: 'horas',text: 'Horas por Semana',sort: true},
    { dataField: 'tipocontrato', text: 'Tipo de Contrato', sort: true, },
    { dataField: 'salary', text: 'Salario', align: 'right', sort: true, formatter: (cell, row) => { return cell.toFixed(2); } },
    { dataField: 'id_contrato', text: 'Detalle', sort: true,
      formatter: (cell, row) => {
        return <div>
          <Link to={{ pathname: '/employee/contract/' + cell, state: { id_empleado: this.props.match.params.id } }} className="btn btn-success"><i className="fa fa-edit"></i></Link>
        </div>
      }
    }];


  columnsincapacity = [
    {
      dataField: 'estado', text: 'Estado', sort: true,
      formatter: (cell, row) => {
        return Utils.showstatus(row.id_estado, row.estado);
      }
    },
    { dataField: 'fecha_incapacidad', text: 'Fecha de Incapacidad', sort: true },
    { dataField: 'fecha_culmina', text: 'Fecha de Retorno', sort: true },
    { dataField: 'ano', text: 'Año', sort: true },
    { dataField: 'codigo_incapacidad', text: 'Número de Incapacidad', sort: true },
    { dataField: 'fecha_creacion', text: 'Fecha de Creación', sort: true },
    {
      dataField: 'id_incapacidad', text: 'Detalle', sort: true,
      formatter: (cell, row) => {
        return <div>
          <Link to={{ pathname: '/employee/incapacities/' + cell, state: { id_empleado: this.props.match.params.id } }} className="btn btn-success"><i className="fa fa-edit"/></Link>
        </div>
      }
    }];


  columnscompromiso = [
    { dataField: 'id_estado', text: 'Estado', sort: true, formatter: (cell, row) => { return Utils.showstatus(cell, row.estado); } },
    { dataField: 'descripcion', text: 'Descripción', sort: true },
    { dataField: 'montototal', text: 'Monto', align: 'right', sort: true, formatter: (cell, row) => { return '$' + cell.toFixed(2); } },
    { dataField: 'monto_letra_quincenal', text: 'Monto Quincenal', align: 'right', sort: true, formatter: (cell, row) => { return '$' + cell.toFixed(2); } },
    { dataField: 'montoactual', text: 'Monto Actual', align: 'right', sort: true, formatter: (cell, row) => { return '$' + cell.toFixed(2); } },
    { dataField: 'fecha_creacion', text: 'Fecha de Creación', sort: true },
    { dataField: 'cuotaspagadas', text: 'Cuotas pagadas', sort: true },
    {
      dataField: 'id_descuento_directo', text: 'Detalle', sort: true,
      formatter: (cell, row) => {
        return <div>
          <Link to={{ pathname: '/employee/commit/' + cell, state: { id_empleado: this.props.match.params.id } }} className="btn btn-success"><i className="fa fa-edit"/></Link>
          {row.id_estado === 7 ? <button style={{ 'marginLeft': '5px' }} onClick={() => this.deletecommitment(cell)} className="btn btn-danger"><i className="fa fa-eraser"/></button> : null}
        </div>
      }
    }];


  columnsvacation = [
    { dataField: 'id_estado', text: 'Estado', sort: true, formatter: (cell, row) => { return Utils.showstatus(cell, row.estado); } },
    { dataField: 'contrato', text: 'Contrato', sort: true },
    { dataField: 'fecha_inicio', text: 'Fecha Inicio', sort: true },
    { dataField: 'fecha_retorno', text: 'Fecha Retorno', sort: true },
    { dataField: 'cantidaddias', text: 'Cantidad de Días', sort: true },
    { dataField: 'id_vacaciones', text: 'Editar',
      formatter: (cell, row) => {
        return <div>
          {row.id_estado === 7 || row.id_estado === 6 ? <Link to={{ pathname: '/employee/vacation/' + cell, state: { id_empleado: this.props.match.params.id } }} className="btn btn-success"><i className="fa fa-edit"/></Link> : null}
          {row.id_estado === 7 ? <button style={{ 'marginLeft': '5px' }} onClick={() => this.deletevacacion(cell)} className="btn btn-danger"><i className="fa fa-eraser"/></button> : null}
        </div>
      }
    }];


  columnsvacationAdvance = [
    { dataField: 'id_estado', text: 'Estado', sort: true, formatter: (cell, row) => { return Utils.showstatus(cell, row.estado); } },
//  { dataField: 'contrato', text: 'Contrato', sort: true, headerStyle: (colum, colIndex) => {return { width: '250px', textAlign: 'center' };} },
    { dataField: 'fecha_inicio', text: 'Fecha Inicio', sort: true },
    { dataField: 'fecha_retorno', text: 'Fecha Retorno', sort: true },
    { dataField: 'cantidaddias', text: 'Cantidad de Días', sort: true },
    { dataField: 'diashabiles', text: 'Días Habiles', sort: true },
    { dataField: 'totalhoras', text: 'Cantidad Horas', sort: true },
    { dataField: 'salarioxhora', text: 'Salario x Hora', sort: true },
    { dataField: 'cobrado', text: '¿Cobrado?', sort: true, formatter: (cell, row) => { 
        return  Utils.showstatus(cell?6:10,cell?'Si':'No');; 
      } },
    { dataField: 'id_vacaciones', text: 'Editar',
      formatter: (cell, row) => {
        return <div>
          {row.id_estado === 7 || row.id_estado === 6 ? <Link to={{ pathname: '/employee/vacationadvance/' + cell, state: { id_empleado: this.props.match.params.id } }} className="btn btn-success"><i className="fa fa-edit"/></Link> : null}
          {row.id_estado === 7 ? <button style={{ 'marginLeft': '5px' }} onClick={() => this.deletevacacionadelantada(cell)} className="btn btn-danger"><i className="fa fa-eraser"/></button> : null}
        </div>
      }
    }];


  columnsAusent = [
      { dataField: 'id_estado', text: 'Estado', sort: true, formatter: (cell, row) => { return Utils.showstatus(cell, row.estado);}},
      { dataField: 'fecha_marcacion', text: 'Fecha Ausencia', sort: true },
      { dataField: 'fecha_inicio', text: 'Fecha Tardanza', sort: true },
      { dataField: 'cantidadAusencias', text: 'Cantidad de Ausencias', sort: true },
      { dataField: 'id_vacaciones', text: 'Editar',
        formatter: (cell, row) => {
          return <div>
            {row.id_estado === 7 || row.id_estado === 6 ? <Link to={{ pathname: '/employee/vacation/' + cell, state: { id_empleado: this.props.match.params.id } }} className="btn btn-success"><i className="fa fa-edit"/></Link> : null}
            {row.id_estado === 7 ? <button style={{ 'marginLeft': '5px' }} onClick={() => this.deletevacacion(cell)} className="btn btn-danger"><i className="fa fa-eraser"/></button> : null}
          </div>
        }
      }];


  componentDidMount() {
    this.getdata();
    if (this.props.match.params.id && this.props.match.params.tab === '') {
      this.setState({ key: cookies.get('tabname') });
    }
  }

  async getdata() {
    try {
      let id = this.props.match.params.id;
      this.setState({ issubmitting: true });
      let employeedata = await RequestService.get('employee/' + id, null);
      let contracts = await RequestService.get('employee/' + id + '/contracts', null);
      let incapacity = await RequestService.get('employee/' + id + '/incapacity', null);
      let commitments = await RequestService.get('commitment/' + id + '/employee', null);
      let vacations = await RequestService.get('vacation/' + id + '/employee', null);
      let vacationsadvance = await RequestService.get('vacationadvance/' + id + '/employee', null);
      let absents =  await RequestService.get('absent/'+ id  + '/employee' , null );
      this.setState(employeedata.data[0])
      this.setState({
        contracts: contracts.data,
        incapacity: incapacity.data,
        compromiso: commitments.data,
        vacations: vacations.data,
        vacationsadvance: vacationsadvance.data,
        absents: absents.data,
        issubmitting: false
      });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async deletecommitment(id) {
    try {
      this.setState({ issubmitting: true });
      await RequestService.delete('commitment/' + id, null);
      let commitments = await RequestService.get('commitment/' + this.state.id_empleado + '/employee', null);
      this.setState({ compromiso: commitments.data, issubmitting: false });
      toastr.success('Compromiso eliminado');
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async deletevacacion(id) {
    try {
      this.setState({ issubmitting: true });
      await RequestService.delete('vacation/' + id, null);
      let vacations = await RequestService.get('vacation/' + this.state.id_empleado + '/employee', null);
      this.setState({ vacations: vacations.data, issubmitting: false });
      toastr.success('Vacación eliminada');
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  async deletevacacionadelantada(id) {
    try {
      this.setState({ issubmitting: true });
      await RequestService.delete('vacationadvance/' + id, null);
      let vacationsadvance = await RequestService.get('vacationadvance/' + this.state.id_empleado + '/employee', null);
      this.setState({ vacationsadvance: vacationsadvance.data, issubmitting: false });
      toastr.success('Vacación Adelantada eliminada');
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.', 'Intente de nuevo');
    }
  }

  departamento(){
    let result='';
    if (this.state.departamento==='2'){result= Utils.showstatus(10, 'LIQUIDADO');
    }else if(this.state.departamento==='8'){result= Utils.showstatus(3, 'NO APROBADO');
    }else if(this.state.departamento==='7'){result= Utils.showstatus(7, 'POR APROBADO');
    }else{result=this.state.departamento;}
    return result;
  }

  render() {
    return (
      <div>
        <div className="page-header">
          <h3><strong>Detalle del Colaborador:</strong> {this.state.nombre + ' ' + this.state.apellido}</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
            <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Detalle Colaborador</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-md-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <Tabs
                  id="controlled-tab-example"
                  activeKey={this.state.key}
                  onSelect={(k) => {
                    this.setState({ key: k })
                    cookies.set('tabname', k);
                  }}
                >
                  <Tab id="generales" eventKey="generales" title="Generales">
                    <div className="row" style={{ marginTop: '2%' }}>
                      <div className="col-md-12 grid-margin">
                        <div className="row">
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
                            <div className="card card-statistics">
                              <div className="card-body" className="card-body employeestarts">
                                <div className="clearfix">
                                  <div className="float-left">
                                    <i className="mdi mdi-cube text-danger icon-lg"/>
                                  </div>
                                  <div className="float-right">
                                    <p className="mb-0 text-right text-dark">Salario Actual</p>
                                    <div className="fluid-container">
                                      <h3 className="font-weight-medium text-right mb-0 text-dark">${this.state.salario}</h3>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
                            <div className="card card-statistics">
                              <div className="card-body employeestarts">
                                <div className="clearfix">
                                  <div className="float-left">
                                    <i className="mdi mdi-account-box-multiple text-info icon-lg"/>
                                  </div>
                                  <div className="float-right">
                                    <p className="mb-0 text-right text-dark">Incapacidades Acumuladas:</p>
                                    <div className="fluid-container">
                                      <h3 className="font-weight-medium text-right mb-0 text-dark">{this.state.incapacidades}</h3>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
                            <div className="card card-statistics">
                              <div className="card-body employeestarts">
                                <div className="clearfix">
                                  <div className="float-left">
                                    <i className="mdi mdi-account-box-multiple text-info icon-lg"/>
                                  </div>
                                  <div className="float-right">
                                    <p className="mb-0 text-right text-dark">Vacaciones Acumuladas:</p>
                                    <div className="fluid-container">
                                      <h3 className="font-weight-medium text-right mb-0 text-dark">{this.state.vacaciones}</h3>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
                            <div className="card card-statistics">
                              <div className="card-body employeestarts">
                                <div className="clearfix">
                                  <div className="float-left">
                                    <i className="mdi mdi-account-box-multiple text-info icon-lg"/>
                                  </div>
                                  <div className="float-right">
                                    <p className="mb-0 text-right text-dark">Vacaciones Adelantadas:</p>
                                    <div className="fluid-container">
                                      <h3 className="font-weight-medium text-right mb-0 text-dark">{this.state.vacadelantadas}</h3>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
                            <div className="card card-statistics">
                              <div className="card-body employeestarts" >
                                <div className="clearfix">
                                  <div className="float-left">
                                    <i className="mdi mdi-receipt text-warning icon-lg"/>
                                  </div>
                                  <div className="float-right">
                                    <p className="mb-0 text-right text-dark">Antigüedad:</p>
                                    <div className="fluid-container">
                                      <h6 className="font-weight-medium text-right mb-0 text-dark">{this.state.antiguedad}</h6>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 grid-margin stretch-card">
                            <div className="card card-statistics">
                              <div className="card-body employeestarts">
                                <div className="clearfix">
                                  <div className="float-left">
                                    <i className="mdi mdi-poll-box text-success icon-lg"/>
                                  </div>
                                  <div className="float-right">
                                    <p className="mb-0 text-right text-dark">Tipo de Contracto Activo:</p>
                                    <div className="fluid-container">
                                      <h3 className="font-weight-medium text-right mb-0 text-dark">{this.state.tipocon}</h3>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-md-6">
                        <div style={{ padding: '0.5rem', backgroundColor: 'rgba(192,192,192,0.12)', borderRadius: '5px' }}>
                          <h4 className="row justify-content-center p-4"><strong>Información General</strong></h4>
                          <div className="row">
                            <div className="col-md-4 font-weight-bold text-right">Estado:</div> <div className="col-md-8">{this.state.estado}</div>
                            <hr /><div className="col-md-4 font-weight-bold text-right">Número de Colaborador:</div> <div className="col-md-8">{this.state.num_colaborador}</div>
                            <hr /><div className="col-md-4 font-weight-bold text-right">Cédula:</div>           <div className="col-md-8">{this.state.cedula}</div>
                            <hr /><div className="col-md-4 font-weight-bold text-right">Seguro Social:</div>    <div className="col-md-8">{this.state.seguro_social}</div>
                            <hr /><div className="col-md-4 font-weight-bold text-right">Género:</div>           <div className="col-md-8">{this.state.genero === "M" ? 'Masculino' : 'Femenino'}</div>
                            <hr /><div className="col-md-4 font-weight-bold text-right">Fecha de Nacimiento:</div> <div className="col-md-8">{this.state.fecha_nacimiento}</div>
                            <hr /><div className="col-md-4 font-weight-bold text-right">Departmento:</div>      <div className="col-md-8">{this.departamento()}</div>
                            <hr /><div className="col-md-4 font-weight-bold text-right">Ocupación:</div>        <div className="col-md-8">{this.state.ocupacion}</div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div style={{ padding: '0.5rem', backgroundColor: 'rgba(192,192,192,0.12)', borderRadius: '5px' }}>
                          <h4 className="row justify-content-center p-4"><strong>Información de Contacto</strong></h4>
                          <div className="row">
                            <div className="col-md-4 font-weight-bold text-right">Correo:</div> <div className="col-md-8">{this.state.correo}</div>
                            <hr /><div className="col-md-4 font-weight-bold text-right">Teléfono:</div>           <div className="col-md-8">{this.state.telefono}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Tab>

                  <Tab id="contratos" eventKey="contratos" title="Contratos">
                    <br />
                    <ToolkitProvider
                      keyField="id_contrato"
                      data={this.state.contracts}
                      columns={this.columnscontrato}
                      search
                    >
                      {
                        props => (
                          <div className={"row"}>
                            <div className="col-lg-8">
                              <Link to={{ pathname: "/employee/contract/new", state: { id_empleado: this.props.match.params.id } }} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar</Link>
                            </div>
                            <div className="col-lg-4">
                              <SearchBar {...props.searchProps} className="form-control" />
                            </div>
                            <hr />
                            <BootstrapTable
                              noDataIndication={"Colaborador sin contratos."}
                              pagination={paginationFactory({ hideSizePerPage: true })}
                              {...props.baseProps}
                            />
                          </div>
                        )
                      }
                    </ToolkitProvider>
                  </Tab>

                  <Tab id="incapacidades" eventKey="incapacidades" title="Incapacidades">
                    <br />
                    <ToolkitProvider
                      keyField="id_incapacidad"
                      data={this.state.incapacity}
                      columns={this.columnsincapacity}
                      search
                    >
                      {
                        props => (
                          <div className={"row"}>
                            <div className="col-lg-8">
                              <Link to={{ pathname: "/employee/incapacities/new", state: { id_empleado: this.props.match.params.id } }} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar</Link>
                            </div>
                            <div className="col-lg-4">
                              <SearchBar {...props.searchProps} className="form-control" />
                            </div>
                            <hr />
                            <BootstrapTable
                              noDataIndication={"No hay incapacidades."}
                              pagination={paginationFactory({ hideSizePerPage: true })}
                              {...props.baseProps}
                            />
                          </div>
                        )
                      }
                    </ToolkitProvider>
                  </Tab>

                  <Tab id="compromisos" eventKey="compromisos" title="Compromisos">
                    <br />
                    <ToolkitProvider
                      keyField="id_contrato"
                      data={this.state.compromiso}
                      columns={this.columnscompromiso}
                      search
                    >
                      {
                        props => (
                          <div className={"row"}>
                            <div className="col-lg-8">
                              <Link to={{ pathname: "/employee/commit/new", state: { id_empleado: this.props.match.params.id } }} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar</Link>
                            </div>
                            <div className="col-lg-4">
                              <SearchBar {...props.searchProps} className="form-control" />
                            </div>
                            <hr />
                            <BootstrapTable
                              noDataIndication={"Colaborador no tiene compromisos adquiridos."}
                              pagination={paginationFactory({ hideSizePerPage: true })}
                              {...props.baseProps}
                            />
                          </div>
                        )
                      }
                    </ToolkitProvider>
                  </Tab>

                  <Tab id="vacaciones" eventKey="vacaciones" title="Vacaciones">
                    <br />
                    <ToolkitProvider
                      keyField="id_contrato"
                      data={this.state.vacations}
                      columns={this.columnsvacation}
                      search
                    >
                      {
                        props => (
                          <div className={"row"}>
                            <div className="col-lg-8">
                              <Link to={{ pathname: "/employee/vacation/new", state: { id_empleado: this.props.match.params.id } }} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar</Link>
                            </div>
                            <div className="col-lg-4">
                              <SearchBar {...props.searchProps} className="form-control" />
                            </div>
                            <hr />
                            <BootstrapTable
                              noDataIndication={"Colaborador sin vacaciones"}
                              pagination={paginationFactory({ hideSizePerPage: true })}
                              {...props.baseProps}
                            />
                          </div>
                        )
                      }
                    </ToolkitProvider>
                  </Tab>
                  
                  <Tab id="vacacionesadelantadas" eventKey="vacacionesadelantadas" title="Vacaciones Adelantadas">
                    <br />
                    <ToolkitProvider
                      keyField="id_contrato"
                      data={this.state.vacationsadvance}
                      columns={this.columnsvacationAdvance}
                      search
                    >
                      {
                        props => (
                          <div className={"row"}>
                            <div className="col-lg-8">
                              <Link to={{ pathname: "/employee/vacationadvance/new", state: { id_empleado: this.props.match.params.id } }} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar</Link>
                            </div>
                            <div className="col-lg-4">
                              <SearchBar {...props.searchProps} className="form-control" />
                            </div>
                            <hr />
                            <BootstrapTable
                              noDataIndication={"Colaborador sin vacaciones adelantadas"}
                              pagination={paginationFactory({ hideSizePerPage: true })}
                              {...props.baseProps}
                            />
                          </div>
                        )
                      }
                    </ToolkitProvider>
                  </Tab>

                  <Tab id="ausencia_tardanzas" eventKey="ausencia_tardanzas" title="Ausentismo">
                    <br />
                    <ToolkitProvider
                      keyField="id_contrato"
                      data={this.state.absents}
                      columns={this.columnsAusent}
                      search
                    >
                      {
                        props => (
                          <div className={"row"}>
                            <div className="col-lg-8">
                              <Link to={{ pathname: "/employee/vacation/new", state: { id_empleado: this.props.match.params.id } }} type="button" className="btn btn-success" style={{ height: '45px', padding: '14px' }}>Agregar</Link>
                            </div>
                            <div className="col-lg-4">
                              <SearchBar {...props.searchProps} className="form-control" />
                            </div>
                            <hr />
                            <BootstrapTable
                              noDataIndication={"Colaborador sin vacaciones"}
                              pagination={paginationFactory({ hideSizePerPage: true })}
                              {...props.baseProps}
                            />
                          </div>
                        )
                      }
                    </ToolkitProvider>
                  </Tab>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default EmployeeDetail;
