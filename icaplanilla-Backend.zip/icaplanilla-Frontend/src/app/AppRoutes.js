import React, { Component, Suspense, lazy } from "react";
import { Switch, Route, Redirect } from "react-router-dom";
import Spinner from "../app/shared/Spinner";
import { AuthRoute, UnauthRoute } from "react-router-auth";
import User from "../mobx/user";

const Dashboard = lazy(() => import("./views/Dashboard"));
const Error404 = lazy(() => import("./views/public/Error404"));
const Login = lazy(() => import("./views/public/Login"));
const BlankPage = lazy(() => import("./commons/BlankPage"));
const Attedance = lazy(() => import("./views/payroll/AttedanceTable"));

const EmployeeTable = lazy(() => import("./views/employee/EmployeeTable"));
const EmployeeTableInactive = lazy(() => import("./views/employee/InactiveEmployeeTable"));
const EmployeeTableEnded = lazy(() => import("./views/employee/EndedEmployeeTable"));

const EmployeeEdith = lazy(() => import("./views/employee/EmployeeEdith"));
const Employeedetail = lazy(() => import("./views/employee/EmployeeDetail"));
const RegisterForm = lazy(() => import("./views/employee/RegisterForm"));
const EmployeeNewContract = lazy(() => import("./views/employee/ContractNew"));
const ContractEdith = lazy(() => import("./views/employee/ContractEdith"));
const Dashboardemployee = lazy(() => import("./views/employee/Dashboard"));
const DepartmentsTable = lazy(() => import("./views/employee/Departmentstable"));
const OcupationTable = lazy(() => import("./views/employee/OcupationsTable"));
const ScheduleTable = lazy(() => import("./views/employee/SchedulesTable"));
const ScheduleNew = lazy(() => import("./views/employee/ScheduleNew"));
const ScheduleForm = lazy(() => import("./views/employee/ScheduleForm"));
const CommitmentsNew = lazy(() => import("./views/employee/CommitmentNew"));
const CommitmentsEdith = lazy(() => import("./views/employee/CommitmentEdith"));
const IncapacitiesNew = lazy(() => import("./views/employee/IncapacitiesNew"));
const IncapacitiesEdith = lazy(() => import("./views/employee/IncapacitiesEdith"));
const VacationNew = lazy(() => import("./views/employee/VacationNew"));
const VacationEdith = lazy(() => import("./views/employee/VacationEdith"));

const VacationNewAdvance = lazy(() => import("./views/employee/VacationNewAdvance"));
const VacationEdithAdvance = lazy(() => import("./views/employee/VacationEdithAdvance"));

//admin links
const Dashboardadmin = lazy(() => import("./views/admin/Dashboard"));
const Usertable = lazy(() => import("./views/admin/Userstable"));
const UserForm = lazy(() => import("./views/admin/Userform"));
const UserNew = lazy(() => import("./views/admin/UserNew"));
const UserActivities = lazy(() => import("./views/admin/UserstableAct"));

//payroll links
const Dashboardpayroll = lazy(() => import("./views/payroll/Dashboard"));
const Planillas = lazy(() => import("./views/payroll/Planillas"));
const PlanillasDetalleDecimo = lazy(() => import("./views/payroll/PlanillasDetalleDecimo"));
const DecimoEmployeeDetalle = lazy(() => import("./views/payroll/DecimoEmployeeDetalle"));
const PlanillasDetalle = lazy(() => import("./views/payroll/PlanillasDetalle"));
const PlanillasEmployeeDetalle = lazy(() => import("./views/payroll/PlanillasEmployeeDetalle"));
const dtm = lazy(() => import("./views/payroll/DtercerMes"));
const vacaciones = lazy(() => import("./views/payroll/PlanillaVacaciones"));
const vacacionesDetalle = lazy(() => import("./views/payroll/PlanillasVacacionesDetalle"));
const liquidaciones = lazy(() => import("./views/payroll/Liquidaciones"));
const PlanillasDetalleFinaliza = lazy(() => import("./views/payroll/PlanillasDetalleFinaliza"));
const planilla03 = lazy(() => import("./views/payroll/Planilla03"));

//reportes
const r_liquidacion = lazy(() => import("./views/payroll/R_liquidacion"));
const r_vacaciones = lazy(() => import("./views/payroll/R_vacaciones"));
const r_vacacionesDetalle = lazy(() => import("./views/payroll/R_vacacionesDetalle"));
const r_planillas = lazy(() => import("./views/payroll/R_planillas"));
const r_planillasDetalle = lazy(() => import("./views/payroll/R_planillasDetalle"));
const r_dtm = lazy(() => import("./views/payroll/R_dtm"));
const descuentosF = lazy(() => import("./views/payroll/DescuentosF"));
const marcaciones = lazy(() => import("./views/payroll/Marcaciones"));
const settings = lazy(() => import("./views/payroll/Settings"));

class AppRoutes extends Component {

  render() {
    return (
      <Suspense fallback={<Spinner />}>
        <Switch>
          <AuthRoute exact path="/"                           component={Dashboard} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee"                   component={Dashboardemployee} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/table"             component={EmployeeTable} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/table/inactive"    component={EmployeeTableInactive} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/table/ended"       component={EmployeeTableEnded} redirectTo="/login" authenticated={User.isloged} />
          
          <AuthRoute exact path="/employee/contract/new"      component={EmployeeNewContract} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/edit/:id"          component={EmployeeEdith} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/contract/:id"      component={ContractEdith} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/department/table"  component={DepartmentsTable} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/department/:id"    component={OcupationTable} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/commit/new"        component={CommitmentsNew} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/commit/:id"        component={CommitmentsEdith} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/vacation/new"      component={VacationNew} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/vacation/:id"      component={VacationEdith} redirectTo="/login" authenticated={User.isloged} />

          <AuthRoute exact path="/employee/vacationadvance/new"      component={VacationNewAdvance} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/vacationadvance/:id"      component={VacationEdithAdvance} redirectTo="/login" authenticated={User.isloged} />

          <AuthRoute exact path="/employee/incapacities/new"  component={IncapacitiesNew} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/incapacities/:id"  component={IncapacitiesEdith} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/schedule/table"    component={ScheduleTable} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/schedule/new"      component={ScheduleNew} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/schedule/:id"      component={ScheduleForm} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/RegisterForm/new"  component={RegisterForm} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/employee/:id?/:tab?"        component={Employeedetail} redirectTo="/login" authenticated={User.isloged} />
          
          <AuthRoute exact path="/admin"                    component={Dashboardadmin} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/admin/table"              component={Usertable} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/admin/user/new"           component={UserNew} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/admin/user/:id"           component={UserForm} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/admin/activities"         component={UserActivities} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll"                  component={Dashboardpayroll} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/blank-page"               component={BlankPage} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/Attedance"        component={Attedance} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/first/planillas"  component={Planillas} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/planillas/:id"    component={PlanillasDetalle} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/employee/:id"     component={PlanillasEmployeeDetalle} redirectTo="/login" authenticated={User.isloged} />

          <AuthRoute exact path="/payroll/second/Dtercermes"  component={dtm} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/decimo/:id"         component={PlanillasDetalleDecimo} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/decimo/:id/detail"  component={DecimoEmployeeDetalle} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/third/vacaciones"   component={vacaciones} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/third/vacaciones/:id"     component={vacacionesDetalle} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/fourth/liquidaciones/:id" component={PlanillasDetalleFinaliza} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/fourth/liquidaciones"     component={liquidaciones} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/reports/planilla03"       component={planilla03} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/reports/planillas"        component={r_planillas} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/reports/planillas/detalle/:id" component={r_planillasDetalle} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/reports/Dtercermes"       component={r_dtm} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/reports/vacaciones"       component={r_vacaciones} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/reports/vacaciones/detalle/:id" component={r_vacacionesDetalle} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/reports/r_liquidacion"    component={r_liquidacion} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/descuento/descuentosF"    component={descuentosF} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/marcacion"                component={marcaciones} redirectTo="/login" authenticated={User.isloged} />
          <AuthRoute exact path="/payroll/settings"                 component={settings} redirectTo="/login" authenticated={User.isloged} />

          <UnauthRoute path="/login" component={Login} redirectTo="/login" authenticated={User.isloged} />
          <Route path="/error-404" component={Error404} />
          <Redirect to="/error-404" />
        </Switch>
      </Suspense>
    );
  }
}

export default AppRoutes;
