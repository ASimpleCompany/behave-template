const db = require('../config/db');
const { getUserId, validateAdminiostrative } = require('../helpers/utils')
const util = require('util');
const query = util.promisify(db.query).bind(db);


exports.inpuestosfijos = async (id_codigoplanilla,descuentofijo,empleado,id_planilla,id_nomina, extra=0) => {
    let sqldetalle = 'INSERT INTO tbl_detalle_planilla(id_nomina,id_tipo_descuento,id_empleado,id_codigoplanilla,id_planilla,monto) VALUES (?,?,?,?,?,?)';
    //let totalplanilla=await query('select get_planilladata(?,\'CR\') as creditos',[id_planilla]);
    await query('delete from tbl_detalle_planilla where id_planilla=? and id_tipo_descuento in (2,4,11)',[id_planilla]);
    for (const descuento of descuentofijo) {
      let monto = 0;
      let datosdetalle = [];
      let operacion = descuento.operacion.replace(/{salario}/gi,empleado.salario_quin)
        .replace(/{deduccion}/gi, descuento.monto)
        .replace(/{mensula}/gi, empleado.salario_quin*2);
      let validacion = descuento.validacion.replace(/{salario}/gi, empleado.salario_quin)
        .replace(/{mensula}/gi,  empleado.salario_quin*2)
        .replace(/{deduccion}/gi, descuento.monto);
      datosdetalle = [id_nomina, descuento.id_tipo_descuento,empleado.id_empleado, id_codigoplanilla, id_planilla];

      if (validacion === '') {
        monto = eval(operacion);
        datosdetalle.push(monto);
        await query(sqldetalle, datosdetalle);
      } else {
      if (eval(validacion)) {
        monto = eval(operacion);
        datosdetalle.push(monto);
        await query(sqldetalle, datosdetalle);
      }
    }
  }
}



exports.creadecimo = async (decimo,empleado,descuentofijo,idcodigoplanilla,id_nomina)=>{
  let sqldetalle = 'INSERT INTO tbl_detalle_planilla(id_nomina,id_tipo_descuento,id_empleado,id_codigoplanilla,id_planilla,monto) VALUES (?,?,?,?,?,?)';
  /*
  * Crea Planill para colaborador
  */
  let operaciondecimo = eval(decimo[0].operacion.replace(/{mensual}/gi, empleado.mensual).replace(/{deduccion}/gi, decimo[0].monto));

  let planilladata = [empleado.mensual,empleado.salario, operaciondecimo, empleado.id_empleado, id_nomina, 
    idcodigoplanilla,empleado.id_contrato,empleado.hora];
  let planilla = await query('INSERT INTO tbl_planillas(total_ingresos,salario_mensual_pactado,salario_quincenal_neto, id_empleado, \
    id_nomina, id_codigoplanilla,id_contrato,salario_hora) VALUES (?,?,?,?,?,?,?,?)', planilladata);
  let id_planilla = planilla.insertId;
  
  /*
  * Insertar creditos para colaborador
  */
  let datosdetalle = [parseInt(id_nomina), 13, empleado.id_empleado, idcodigoplanilla, id_planilla, operaciondecimo];
  await query(sqldetalle, datosdetalle);
  
  /*
  * Insertar todos los descuentos fijos
  */
  for (const descuento of descuentofijo) {
    let monto = 0;
    let datosdetalle = [];
    if(descuento.id_tipo_descuento===11){
      empleado.mensual=empleado.salario
    }else{
      empleado.mensual=operaciondecimo;
    }

    let operacion = descuento.operacion.replace(/{salario}/gi, empleado.mensual)
      .replace(/{mensula}/gi, empleado.mensual)
      .replace(/{deduccion}/gi, descuento.monto);
    
    let validacion = descuento.validacion.replace(/{salario}/gi, empleado.mensual)
      .replace(/{mensula}/gi, empleado.mensual)
      .replace(/{deduccion}/gi, descuento.monto);
    datosdetalle = [id_nomina, descuento.id_tipo_descuento, empleado.id_empleado, idcodigoplanilla, id_planilla];
    if (validacion === '') {
      monto = eval(operacion);
      datosdetalle.push(monto);
      await query(sqldetalle, datosdetalle);
    } else {
      if (eval(validacion)) {
        monto = eval(operacion);
        if(descuento.id_tipo_descuento===11){
          monto=(monto*2)/3;
        }
        datosdetalle.push(monto);
        await query(sqldetalle, datosdetalle);
      }
    }
  }
}





exports.selectlastpyroll = async (decimo,empleado,descuentofijo,idcodigoplanilla,id_nomina)=>{

  let planilla = await query('');
  
  
  
}
