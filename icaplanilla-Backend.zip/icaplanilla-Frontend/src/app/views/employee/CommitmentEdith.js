import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import toastr from "toastr";
import RequestService from '../../../services/RequestService';
import Utils from "../../../services/Utils"
import { Link } from 'react-router-dom';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';

export class CommitmentNew extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id: 0,
      descripcion: '',
      montototal: '',
      monto_letra_quincenal: '',
      id_empleado: 0
    }
    this.update = this.update.bind(this);
    this.getdata = this.getdata.bind(this);
    this.noaproveCommit = this.noaproveCommit.bind(this);

  }

  componentDidMount() {
    let { id_empleado } = this.props.location.state;
    this.setState({ id_empleado: id_empleado });
    this.getdata();
  }

  async getdata() {
    try {
      this.setState({ issubmitting: true });
      let id = this.props.match.params.id;
      let employeedata = await RequestService.get('commitment/' + id, null);
      this.setState(employeedata.data[0]);
      this.setState({ issubmitting: false });
    } catch (e) {
      this.setState({ issubmitting: false });
      toastr.error('Los datos no pudieron ser consultados.');
    }
  }

  async update(e) {
    e.preventDefault()
    try {
      if (this.state.issubmitting) {
        toastr.warning('La información se esta procesando.');
      } else {
        this.setState({ issubmitting: true });
        let data = new FormData();
        data.append('descripcion', this.state.descripcion);
        data.append('montototal', this.state.montototal);
        data.append('monto_letra_quincenal', this.state.monto_letra_quincenal);
        data.append('id_empleado', this.state.id_empleado);
        await RequestService.put('commitment/' + this.state.id_descuento_directo, data);
        toastr.success('Compromiso actualizado');
        this.setState({ issubmitting: false });
        //this.props.history.push('/employee/'+this.state.id_empleado);
      }
    } catch (e) {
      let rs = Utils.logerrors(e);
      this.setState({ issubmitting: false, errors: rs });
    }
  }

  async noaproveCommit(accion) {
    confirmAlert({
      title: 'Actualizar',
      message: '¿Seguro desea realizar esta acción?',
      buttons: [
        {
          label: 'Si',
          onClick: async () => {
            try {
              this.setState({ issubmitting: true });
              let data = new FormData();
              data.append('accion', accion);
              let rs = await RequestService.put('commitment/' + this.props.match.params.id + '/approve', data);
              console.log(rs);
              toastr.success('Actualizacion realizada');
              this.getdata();
            } catch (e) {
              this.setState({ issubmitting: false });
              toastr.error('Los datos no pudieron ser actualizados.');
            }
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
  }



  handleChange = date => {
    this.setState({
      startDate: date
    });
  };

  cantidadcuotas() {
    try {
      let rs = this.state.montototal / this.state.monto_letra_quincenal;
      this.setState({ cantidadcuotas: rs });
    } catch (e) {
      this.setState({ cantidadcuotas: 0 });
    }

  }

  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Editar Compromiso</h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link
                  to="/employee/"
                  role="button">Recursos Humanos
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to="/employee/table"
                  role="button">Colaboradores
                </Link>
              </li>
              <li className="breadcrumb-item">
                <Link
                  to={'/employee/' + this.state.id_empleado}
                  role="button">Compromisos
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Editar</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          {Utils.loading(this.state.issubmitting)}
          <div className="col-md-6 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <form className="forms-sample">

                  <Form.Group>
                    <label htmlFor="descripcion">Descripción:</label>
                    {this.state.id_estado === 7 ? <Form.Control type="text"
                      value={this.state.descripcion}
                      className={Utils.loaderrors(this.state.errors, 'descripcion')}
                      id="descripcion"
                      onChange={(val) => {
                        this.setState({ descripcion: val.target.value });
                      }}
                      placeholder="Descripción" size="lg" /> : <div>{this.state.descripcion}</div>}
                  </Form.Group>
                  <Form.Group>
                    <label htmlFor="montototal">Monto Total de Compromiso:</label>
                    {this.state.id_estado === 7 || this.state.id_estado === 6 ? <Form.Control type="number"
                      value={this.state.montototal}
                      className={"form-control "+Utils.loaderrors(this.state.errors, 'montototal')}
                      onChange={(val) => {
                        this.setState({ montototal: val.target.value });

                      }}
                      id="montototal" placeholder="0000.00" /> : <div>{this.state.montototal}</div>}
                  </Form.Group>

                  <Form.Group>
                    <label htmlFor="monto_letra_quincenal">Monto quincenal a deducir:</label>
                    {this.state.id_estado === 7 || this.state.id_estado === 6 ? <Form.Control type="text"
                      value={this.state.monto_letra_quincenal}
                      className={"form-control "+Utils.loaderrors(this.state.errors, 'monto_letra_quincenal')}
                      onChange={(val) => {
                        if (val.target.value > this.state.montototal) {
                          this.setState({ monto_letra_quincenal: 0 });
                          toastr.warning('Monto quincenal no puede ser mayor a monto de compromiso.', 'Intente de nuevo');
                        } else {
                          this.setState({ monto_letra_quincenal: val.target.value });
                        }
                      }}
                      id="monto_letra_quincenal" placeholder="0000.00" /> : <div>{this.state.monto_letra_quincenal}</div>}
                  </Form.Group>

                  {this.state.id_estado === 7 || this.state.id_estado === 6 ?
                    <button type="button"
                      className="btn btn-success btn-lg"
                      style={{ margin: '5px' }}
                      onClick={this.update}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Guardar"}</button> : null}

                  {this.state.id_estado === 7 ?
                    <button type="button"
                      className="btn btn-warning btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(true) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Aprobar"}</button> : null}

                  {this.state.id_estado === 7 ?
                    <button type="button"
                      className="btn btn-warning btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(false) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "No Aprobar"}</button> : null}

                  {this.state.id_estado === 6 ?
                    <button type="button"
                      className="btn btn-warning btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(true) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Finalizar"}</button> : null}


                  {this.state.id_estado === 11 ?
                    <button type="button"
                      className="btn btn-warning btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(false) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Aprobar No Finalizar"}</button> : null}

                  {this.state.id_estado === 11 ?
                    <button type="button"
                      className="btn btn-danger btn-lg"
                      style={{ margin: '5px' }}
                      onClick={() => { this.noaproveCommit(true) }}
                    >{this.state.issubmitting ? <i className="fa fa-spin fa-circle-o-notch"></i> : "Aprobar Finalizar"}</button> : null}

                  <Link to={'/employee/' + this.state.id_empleado} className="btn btn-secondary btn-lg" style={{ margin: '5px' }}>Cancelar</Link>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default CommitmentNew;
